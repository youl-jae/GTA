/* eslint-disable no-undef */
module.exports = {
  env: {
    browser: true,
    es6: true,
  },
  extends: [
    "eslint:recommended",
    "plugin:vue/essential",
    "plugin:prettier/recommended",
  ],
  globals: {
    Atomics: "readonly",
    SharedArrayBuffer: "readonly",
  },
  parserOptions: {
    parser: "babel-eslint",
    ecmaVersion: 2018,
    sourceType: "module",
  },
  plugins: ["vue"],
  rules: {
    "prettier/prettier": [
      "error",
      {
        printWidth: 80,
        semi: true,
        quoteProps: "consistent",
        trailingComma: "all",
        bracketSpacing: true,
        bracketSameLine: true,
        arrowParens: "avoid",
      },
    ],
  },
};
