import UserStore from "@/store/modules/userStore";
import Vue from "vue";
import Vuex from "vuex";
import createPersistedState from "vuex-persistedstate";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    ADMIN_ID: "gta.app",
    ADMIN_EMAIL: "gta.app@samsung.com",
    GTA_LINK: "http://g2.gta.samsungds.net/#/",
    TOTAL_POWER_ID_LIST: [15, 16, 18, 40],
    SOC_POWER_ID: 19,
    ANTUTU_TESTCASE_LIST: [
      "Coastline2",
      "Seasons",
      "Terracotta",
      "Coastline",
      "Refinery",
      "Terracotta-Vulkan",
      "Coastline-Vulkan",
      "Refinery-OpenGLES3.1+AEP",
      "Swordsman-Vulkan",
    ],
  },
  getters: {
    statusColor: state => status => {
      if (status === "Request") {
        return "primary";
      } else if (status === "Approve") {
        return "success";
      } else if (status === "Reject") {
        return "danger";
      } else if (status === "In progress") {
        return "warning";
      } else if (status === "Complete") {
        return "secondary";
      } else {
        return "secondary";
      }
    },
  },
  mutations: {},
  actions: {},
  modules: {
    userStore: UserStore,
  },
  plugins: [
    createPersistedState({
      paths: ["userStore"],
    }),
  ],
});
