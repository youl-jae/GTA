import router from "@/router";

const userStore = {
  state: {
    userId: "",
    knoxId: "",
    userName: "",
    roles: [],
    token: "",
  },
  getters: {
    isLogin(state) {
      return state.token ? true : false;
    },
    isAdmin(state) {
      return state.roles.includes("ADMIN");
    },
    isBenchmarkKpiManager(state) {
      return ["ADMIN", "BENCHMARK_KPI"].some(role =>
        state.roles.includes(role),
      );
    },
    isGameKpiManager(state) {
      return ["ADMIN", "GAME_KPI"].some(role => state.roles.includes(role));
    },
    isGameCompatibilityManager(state) {
      return ["ADMIN", "GAME_COMPATIBILITY"].some(role =>
        state.roles.includes(role),
      );
    },
    isPPAEngineer(state) {
      return ["ADMIN", "PPA_Engineer"].some(role => state.roles.includes(role));
    },
  },
  mutations: {
    login(state, payload) {
      state.userId = payload.userId;
      state.knoxId = payload.knoxId;
      state.userName = payload.userName;
      state.roles = payload.roles;
      state.token = payload.token;
    },
    logout(state) {
      state.userId = null;
      state.knoxId = null;
      state.userName = null;
      state.roles = [];
      state.token = null;
    },
    checkLogin(state) {
      if (!state.token) {
        router.push({
          name: "Login",
        });
      }
    },
  },
};

export default userStore;
