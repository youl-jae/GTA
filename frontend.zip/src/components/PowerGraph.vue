<template>
  <div v-if="powerData">
    <highcharts
      constructor-type="stockChart"
      :options="chartOptions"></highcharts>
  </div>
</template>

<script>
import { Chart } from "highcharts-vue";
import Highcharts from "highcharts";
import exportingInit from "highcharts/modules/exporting";
import stockInit from "highcharts/modules/stock";

stockInit(Highcharts);
exportingInit(Highcharts);

export default {
  components: {
    highcharts: Chart,
  },
  props: {
    testitem: {},
  },
  data() {
    return {
      powerData: false,
      chartOptions: {
        colors: [
          "#C23531",
          "#2F4554",
          "#61A0A8",
          "#D48265",
          "#91C7AE",
          "#CA8622",
          "#749F83",
          "#BDA29A",
          "#6E7074",
          "#C4CCD3",
          "#C4CCD3",
          "#4BABDE",
          "#FFDE76",
          "#E43C59",
        ],
        chart: {
          type: "line",
          zoomType: "x",
          height: 900,
          spacing: [20, 30, 20, 20],
        },
        rangeSelector: {
          buttons: [
            {
              type: "all",
              text: "All",
            },
          ],
          buttonPosition: {
            align: "right",
            x: -15,
            y: -38,
          },
          inputEnabled: false,
        },
        legend: {
          enabled: true,
          y: -35,
          verticalAlign: "top",
        },
        credits: {
          enabled: false,
        },
        tooltip: {
          enabled: true,
          crosshairs: true,
          shared: true,
          // split: false,
          headerFormat: "<span>{point.x}</span><br/>",
          borderColor: "rgb(100, 100, 100)",
        },
        navigator: {
          height: 15,
          xAxis: {
            labels: {
              enabled: false,
            },
          },
        },
        xAxis: {
          labels: {
            format: "{value}",
          },
          lineColor: "rgb(200, 200, 200)",
          lineWidth: 2,
        },
        yAxis: [
          {
            title: {
              text: "CPU Power",
            },
            min: 0,
            opposite: false,
            showFirstLabel: true,
            showLastLabel: true,
            height: "19%",
            top: "0%",
            tickInterval: 1,
            lineColor: "rgb(200, 200, 200)",
            lineWidth: 2,
          },
          {
            title: {
              text: "GPU Power",
            },
            min: 0,
            opposite: false,
            showFirstLabel: true,
            showLastLabel: true,
            height: "19%",
            top: "27%",
            offset: 0,
            tickInterval: 1,
            lineColor: "rgb(200, 200, 200)",
            lineWidth: 2,
          },
          {
            title: {
              text: "ETC Power",
            },
            min: 0,
            opposite: false,
            showFirstLabel: true,
            showLastLabel: true,
            height: "19%",
            top: "54%",
            offset: 0,
            tickInterval: 1,
            lineColor: "rgb(200, 200, 200)",
            lineWidth: 2,
          },
          {
            title: {
              text: "DRAM Power",
            },
            min: 0,
            opposite: false,
            showFirstLabel: true,
            showLastLabel: true,
            height: "19%",
            top: "81%",
            offset: 0,
            tickInterval: 1,
            lineColor: "rgb(200, 200, 200)",
            lineWidth: 2,
          },
        ],
        series: [],
      },
    };
  },
  created() {
    // this.$http.get(`/api/powers/${this.testitem}`)
    this.$http
      .get(`/api/powers/1`)
      .then(res => {
        this.powerData = true;

        for (const power of res.data) {
          var yAxis = 0;

          if (power.data.type == "CPU") {
            yAxis = 0;
          } else if (power.data.type == "GPU") {
            yAxis = 1;
          } else if (power.data.type == "ETC") {
            yAxis = 2;
          } else if (power.data.type == "DRAM") {
            yAxis = 3;
          }

          if (power.data.name != "G3D_OUT") {
            this.chartOptions.series.push({
              name: power.data.name,
              data: power.values,
              yAxis: yAxis,
            });
          }
        }
      })
      .catch(err => {
        console.log(err);
      });
  },
};
</script>
