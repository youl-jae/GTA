<template>
  <div>
    <highcharts
      constructor-type="stockChart"
      :options="chartOptions"></highcharts>
  </div>
</template>

<script>
import { Chart } from "highcharts-vue";
import Highcharts from "highcharts";
import exportingInit from "highcharts/modules/exporting";
import stockInit from "highcharts/modules/stock";

stockInit(Highcharts);
exportingInit(Highcharts);

export default {
  components: {
    highcharts: Chart,
  },
  props: {
    title: {
      type: String,
    },
    series: {
      type: Array,
    },
    tickInterval: {},
    pointInterval: {},
  },
  data() {
    return {
      chartOptions: {
        colors: [
          "#C23531",
          "#2F4554",
          "#61A0A8",
          "#D48265",
          "#91C7AE",
          "#CA8622",
          "#749F83",
          "#BDA29A",
          "#6E7074",
          "#C4CCD3",
          "#C4CCD3",
          "#4BABDE",
          "#FFDE76",
          "#E43C59",
        ],
        chart: {
          type: "line",
          zoomType: "x",
          height: 250,
        },
        rangeSelector: {
          buttons: [
            {
              type: "second",
              count: 1,
              text: "1s",
              title: "View 1 second",
            },
            {
              type: "second",
              count: 30,
              text: "30s",
              title: "View 30 second",
            },
            {
              type: "minute",
              count: 1,
              text: "1m",
              title: "View 1 minute",
            },
            {
              type: "minute",
              count: 5,
              text: "5m",
              title: "View 5 minute",
            },
            {
              type: "minute",
              count: 10,
              text: "10m",
              title: "View 10 minute",
            },
            {
              type: "all",
              text: "All",
              title: "View all",
            },
          ],
          buttonPosition: {
            align: "right",
          },
          enabled: false,
          inputEnabled: false,
        },
        legend: {
          enabled: true,
          verticalAlign: "top",
        },
        credits: {
          enabled: false,
        },
        tooltip: {
          enabled: true,
          crosshairs: true,
          shared: true,
          split: false,
          xDateFormat: "%H:%M:%S",
          borderColor: "rgb(100, 100, 100)",
        },
        navigator: {
          height: 20,
          margin: 10,
        },
        plotOptions: {
          line: {
            lineWidth: 1,
            shadow: false,
            animation: false,
            pointInterval: this.pointInterval ?? 100,
          },
        },
        xAxis: {
          lineWidth: 1,
          lineColor: "#e6e6e6",
          showFirstLabel: false,
          dateTimeLabelFormats: {
            second: "%M:%S",
            minute: "%M:%S",
            hour: "%H:%M:%S",
            day: "%M:%S",
            week: "%M:%S",
            month: "%M:%S",
            year: "%M:%S",
          },
        },
        yAxis: [
          {
            title: {
              text: this.title,
            },
            min: 0,
            opposite: false,
            showFirstLabel: true,
            showLastLabel: true,
            tickInterval: this.tickInterval,
          },
        ],
        series: this.series,
      },
    };
  },
};
</script>
