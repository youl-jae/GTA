<template>
  <div class="score-slider text-center">
    <b-form-input
      type="range"
      v-model="score"
      min="-3"
      max="3"
      step="1"
      class="compact-range"></b-form-input>

    <div class="slider-labels">
      <small class="neg3">-3</small>
      <small class="neg2">-2</small>
      <small class="neg1">-1</small>
      <small class="neutral">0</small>
      <small class="pos1">+1</small>
      <small class="pos2">+2</small>
      <small class="pos3">+3</small>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return { score: 0 };
  },
};
</script>

<style scoped>
.score-slider {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 220px;
  margin: auto;
}

.compact-range {
  width: 100%;
  height: 4px;
  border-radius: 3px;
  appearance: none;
  background: #dcdcdc;
  outline: none;
  cursor: pointer;
}

.compact-range::-webkit-slider-thumb {
  appearance: none;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: #205081;
  cursor: pointer;
}

.compact-range::-moz-range-thumb {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: #205081;
  border: none;
}

.slider-labels {
  width: 100%;
  display: flex;
  justify-content: space-between;
  margin-top: 4px;
  position: relative;
  padding: 0 6px;
}

.slider-labels small {
  font-size: 0.75rem;
  font-weight: bold;
}

.neg3,
.neg2,
.neg1 {
  color: #dc3545;
}

.neutral {
  color: #6c757d;
}

.pos1,
.pos2,
.pos3 {
  color: #0d6efd;
}
</style>
