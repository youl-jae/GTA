<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title" v-if="Object.keys(lerp_fps).length > 0">
        {{ name }}
        (<span v-for="(value, key, index) in lerp_fps" :key="key">
          {{ key }}: {{ value }}
          <template v-if="index < Object.keys(lerp_fps).length - 1"
            >,
          </template> </span
        >)
      </span>
      <span class="sub-title" v-else>
        {{ name }}
      </span>
      <div class="sub-title-btn-group">
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="AI Agent"
          @click="showModalfunc">
          <font-awesome-icon icon="robot" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Calculate diff"
          @click="calculateDiff">
          <font-awesome-icon icon="exchange-alt" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Create chart"
          @click="createChart">
          <font-awesome-icon icon="chart-line" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          :title="deleteMessage"
          @click="clickDeleteBtn">
          <font-awesome-icon icon="trash-alt" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Copy"
          @click="copyToClipboard">
          <font-awesome-icon icon="copy" />
        </b-button>
      </div>
    </div>
    <div style="overflow-x: auto; margin-bottom: 1rem">
      <table
        :id="`${groupIndex}-score-table`"
        class="table table-sm table-bordered test-table"
        style="margin-bottom: 0rem">
        <thead>
          <tr>
            <th style="width: 27px" class="col-checkbox"></th>
            <th style="width: 193px">Test ID</th>
            <th
              v-for="(test, index) in testData"
              :key="index + 'td' + groupIndex"
              :style="testData.length > 10 ? 'width: 149px;' : 'width: auto;'">
              <!-- class="test-name" @click="showNameEditModal(index, test.name)" -->
              <div class="test-id-column" v-if="index != scoreData.count">
                <span class="click-btn col-checkbox" @click="prevColumn(index)"
                  >◀</span
                >
                <b-form-checkbox
                  size="sm"
                  style="font-size: 12px"
                  class="col-checkbox"
                  v-model="selectedTests"
                  :value="index"
                  @change="removeDiffColumn"
                  >{{ test.name }}</b-form-checkbox
                >
                <span class="test-id" style="display: none">{{
                  test.name
                }}</span>
                <span class="click-btn col-checkbox" @click="nextColumn(index)"
                  >▶</span
                >
              </div>
            </th>
          </tr>
          <tr
            v-for="(column, index) in infoColumns"
            :key="index + 'info' + groupIndex"
            v-show="
              testData.filter(x => x[column.field]).length || column.required
            ">
            <th class="col-checkbox"></th>
            <th>{{ column.text }}</th>
            <th v-for="(test, index) in testData" :key="index">
              <router-link
                v-if="column.field === 'title' && test.id"
                :to="{
                  name: 'TestScore',
                  params: { id: test.id },
                }"
                >{{ test.title }}
              </router-link>
              <span v-else>{{ test[column.field] }}</span>
            </th>
          </tr>
          <tr
            v-for="(column, index) in scoreHeadColumns"
            :key="index + 'shc' + groupIndex"
            v-show="scoreData.items?.filter(x => x[column.field]).length"
            class="score-head">
            <th class="col-checkbox"></th>
            <th>{{ column.text }}</th>
            <td
              v-for="(item, index) in scoreData.items"
              :key="index + 'sdi' + groupIndex"
              style="text-align: center">
              <a :href="item[column.field]" target="_blank">{{
                item[column.field]
              }}</a>
            </td>
          </tr>
        </thead>
        <tbody style="text-align: right">
          <tr
            v-for="(railName, rIndex) in uniquePowerRails"
            :key="'p' + rIndex">
            <th class="col-checkbox">
              <b-form-checkbox
                size="sm"
                v-model="checkedRows"
                :value="'power ' + railName"></b-form-checkbox>
            </th>
            <th>{{ railName }}</th>
            <td
              v-for="(item, cIndex) in scoreData.items"
              :key="'pval' + cIndex">
              {{ getPowerValue(item.powers, railName) ?? "-" }}
            </td>
          </tr>
          <tr
            v-for="(column, index) in scoreBodyColumns"
            :key="index + 'sbc' + groupIndex"
            v-show="
              scoreData.items.map(x => x[column.field]).filter(x => x).length >
              0
            ">
            <th class="col-checkbox">
              <b-form-checkbox
                size="sm"
                v-model="checkedRows"
                :value="column.field"></b-form-checkbox>
            </th>
            <th>{{ column.text }}</th>
            <td
              v-for="(score, index) in scoreData.items"
              :key="index + 'sds' + groupIndex"
              style="text-align: right">
              {{ score[column.field] }}
            </td>
          </tr>
          <tr
            v-for="(column, index) in efficiencyBodyColumns"
            :key="'eff-' + index"
            v-show="
              scoreData.items.some(item => item.efficiency?.[column.field])
            ">
            <th class="col-checkbox">
              <b-form-checkbox
                size="sm"
                v-model="checkedRows"
                :value="'efficiency ' + column.text"></b-form-checkbox>
            </th>
            <th class="ppa-columns">{{ column.text }}</th>
            <td
              v-for="(item, cIndex) in scoreData.items"
              :key="'eff-val-' + index + '-' + cIndex">
              {{ item.efficiency?.[column.field] ?? "-" }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <compare-graph ref="compareGraph" v-show="visibleGraph"></compare-graph>
    <ai-agent
      v-if="visibleAi"
      ref="refAiAgent"
      :comparisonId="selectedAITests"
      :patchesInfo="patchesInfo">
    </ai-agent>

    <b-modal
      id="aiModal"
      v-model="showModal"
      title="Run AI Analysis"
      @ok="runAiAgent"
      ok-title="Run"
      cancel-title="Cancel"
      centered
      size="xl">
      <b-form>
        <b-form-group label="Patches Info" label-for="patchesInfoInput">
          <b-form-textarea
            id="patchesInfoInput"
            v-model="patchesInfo"
            rows="5"
            placeholder="Enter patches description or notes..." />
        </b-form-group>

        <b-form-group label="Patches File" label-for="fileInput">
          <b-form-file
            id="fileInput"
            v-model="selectedFiles"
            browse-text="Select files"
            placeholder="Select files..."
            multiple>
          </b-form-file>
        </b-form-group>

        <div
          v-if="selectedFiles && selectedFiles.length"
          class="mt-2 text-info">
          <div v-for="(file, index) in selectedFiles" :key="index">
            {{ index + 1 }}. {{ file.name }}
          </div>
        </div>
      </b-form>
    </b-modal>
  </div>
</template>

<script>
import AiAgent from "@/components/AiAgent.vue";
import CompareGraph from "@/components/CompareGraph.vue";
//options api, composition api
export default {
  name: "ScoreTable",
  components: {
    CompareGraph,
    AiAgent,
  },
  props: {
    group: Object,
    groupIndex: Number,
    comparisonId: Number,
    ticketId: Number,
  },
  data() {
    return {
      name: "",
      testIdList: "",
      testData: [],
      scoreData: {
        count: 0,
        items: [],
      },
      lerp_fps: {},
      lerp_target: 4500,
      show_lerp: false,
      checkedRows: [],
      selectedTests: [],
      infoColumns: [
        {
          field: "date",
          text: "Date",
          required: true,
        },
        {
          field: "title",
          text: "Title",
          required: true,
        },
        {
          field: "project",
          text: "Project",
          required: true,
        },
        {
          field: "app",
          text: "App",
          required: true,
        },
        {
          field: "testcase",
          text: "Testcase",
          required: false,
        },
        {
          field: "chipId",
          text: "Chip",
          required: true,
        },
        {
          field: "tester",
          text: "Tester",
          required: true,
        },
        {
          field: "condition_name",
          text: "Condition Name",
          required: true,
        },
      ],
      scoreHeadColumns: [
        {
          field: "gamebench_url",
          text: "Gamebench",
        },
        {
          field: "quickperf_url",
          text: "Quickperf",
        },
        {
          field: "amigo_log",
          text: "AMIGO Log",
          link: `${this.$store.state.GTA_LINK}log/`,
        },
        {
          field: "power_rawdata",
          text: "Power Rawdata",
          link: `${this.$store.state.GTA_LINK}log/power/`,
        },
        {
          field: "showfreq_log",
          text: "SOC Dumper Log",
          link: `${this.$store.state.GTA_LINK}log/showfreq/`,
        },
      ],
      scoreBodyColumns: [
        {
          field: "median_fps",
          text: "Median FPS",
        },
        {
          field: "average_fps",
          text: "Average FPS",
        },
        {
          field: "stability",
          text: "Stability",
        },
        {
          field: "stdev",
          text: "STDEV",
        },
        {
          field: "final_temp",
          text: "Average TMU (℃)",
        },
        {
          field: "totalScore",
          text: "FPS or Scores",
        },
        {
          field: "powerPerFps",
          text: "Power/FPS",
        },
        {
          field: "fpsPerPower",
          text: "FPS/Power (↑)",
        },
      ],
      efficiencyBodyColumns: [
        { field: "g3d0_voltage", text: "G3D0 Voltage (V)" },
        { field: "g3d1_voltage", text: "G3D1 Voltage (V)" },
        { field: "temperature", text: "G3D remote max Temp" },
        { field: "g3d0_leakage", text: "G3D0 Plkg (mW)" },
        { field: "g3d1_leakage", text: "G3D1 Plkg (mW)" },
        { field: "dyn_e_per_fr_075v", text: "G3D Dyn E/fr @ 0.75V" },
        { field: "dram_total_bw", text: "DRAM traffic (MB/fr)" },
        { field: "cpu_total_bw", text: "CPU traffic (MB/fr)" },
        { field: "gpu_total_bw", text: "GPU traffic (MB/fr)" },
      ],
      visibleGraph: false,
      visibleAi: false,
      selectedAITests: [],
      showModal: false,
      patchesInfo: "",
      selectedFiles: null,
    };
  },
  computed: {
    deleteMessage() {
      return this.$route.name === "TicketInfo"
        ? "Delete test result"
        : "Delete in group";
    },
    uniquePowerRails() {
      const rails = new Set();
      this.scoreData.items.forEach(item => {
        item.powers.forEach(p => rails.add(p.rail_name));
      });
      return Array.from(rails);
    },
  },
  async created() {
    this.name = this.group.name;
    this.testIdList = this.group.testIdList;

    var testData = await this.$http.get(
      `/api/tests?id=${this.testIdList}&order=id`,
    );
    var scoreData = await this.$http.get(
      `/api/testitems/avg?id=${this.testIdList}`,
    );

    this.testData = testData.data.result;
    this.scoreData = scoreData.data;

    for (let i = 0; i < this.testData.length; i++) {
      this.testData[i].name = this.testData[i].id;
      this.testData[i].date = this.testData[i].date?.substring(0, 10);
    }

    const dynamicColumns = new Set();

    this.scoreData.items.forEach(item => {
      item.score = item.score == 1;
      item.power = item.power == 1;

      if (item.amigo_log) {
        item.amigo_log = `${this.$store.state.GTA_LINK}log/${item.id}`;
      }
      if (item.power_rawdata) {
        item.power_rawdata = `${this.$store.state.GTA_LINK}log/power/${item.id}`;
      }
      if (item.showfreq_log) {
        item.showfreq_log = `${this.$store.state.GTA_LINK}log/showfreq/${item.id}`;
      }

      if (item.scores.length > 1) {
        item.scores.forEach(score => {
          const scoreName = score.name?.toString() ?? "";
          const scoreValue = score.fpsOrScores ?? score.average_fps;
          if (scoreName && scoreValue !== null && scoreValue !== undefined) {
            dynamicColumns.add(scoreName);
          }
        });
      }
    });

    this.scoreBodyColumns = [
      ...this.scoreBodyColumns,
      ...Array.from(dynamicColumns).map(name => ({
        field: name,
        text: name,
      })),
    ];

    if (this.testData[0]["app"].includes("GPUReplay")) {
      // GPU Replay Summary
      try {
        const response = await this.$http.get(
          `/api/gpureplay/gpureplay?id=${this.testIdList}`,
        );
        this.$set(this.lerp_fps, "Total frame/W", response.data.replaySummary);
      } catch (error) {
        console.warn(`⚠️ GPUReplay Summary failed`, error);
      }
    } else if (this.scoreData.count >= 2) {
      const SoC_Powers = this.scoreData.items.map(item => item.totalPower);
      const arr = [...SoC_Powers];
      const arr_base = [...SoC_Powers];

      const targets = [
        { value: 2500, label: "2.5W" },
        { value: 4300, label: "4.3W" },
        { value: 4500, label: "4.5W" },
        { value: 5000, label: "5.0W" },
      ];

      for (const { value: target, label } of targets) {
        const [low, high] = this.findApproximation(arr, target);
        if (low !== undefined && high !== undefined) {
          const lowindex = arr_base.indexOf(low);
          const highindex = arr_base.indexOf(high);
          const low_test_id = this.testIdList[lowindex];
          const high_test_id = this.testIdList[highindex];

          try {
            const response = await this.$http.get(
              `/api/interpolation/avg?target=${target}&id=${low_test_id},${high_test_id}`,
            );
            this.$set(
              this.lerp_fps,
              label,
              response.data.iscore[0].fpsOrScores,
            );
          } catch (error) {
            console.warn(`⚠️ ${label} interpolation failed`, error);
          }
        }
      }
    }
  },
  methods: {
    calculateDiff() {
      if (this.selectedTests.length !== 2) {
        alert("Please select 2 tests.");
        return;
      }

      const testCount = this.scoreData.count;
      const a = this.selectedTests[0];
      const b = this.selectedTests[1];

      const itemA = this.scoreData.items[a];
      const itemB = this.scoreData.items[b];

      if (this.testData.length === testCount) {
        this.testData.push({
          title: `${this.testData[b].name} / ${this.testData[a].name}`,
        });
      }

      const diffItem = {
        __isDiff: true,
        id: `diff_${b}_${a}`,
      };

      for (const column of this.scoreBodyColumns) {
        const valueA = itemA[column.field];
        const valueB = itemB[column.field];
        if (
          typeof valueA === "number" &&
          typeof valueB === "number" &&
          valueA !== 0
        ) {
          const diff = (valueB / valueA - 1) * 100;
          diffItem[column.field] = `${diff.toFixed(1)}%`;
        } else {
          diffItem[column.field] = null;
        }
      }

      diffItem.powers = [];

      for (let i = 0; i < itemA.powers.length; i++) {
        const railA = itemA.powers[i];
        const railB = itemB.powers.find(r => r.rail_id === railA.rail_id);

        if (
          railA &&
          railB &&
          typeof railA.value === "number" &&
          typeof railB.value === "number"
        ) {
          const diff = (railB.value / railA.value - 1) * 100;
          diffItem.powers.push({
            rail_id: railA.rail_id,
            rail_name: railA.rail_name,
            order: railA.order,
            value: `${diff.toFixed(1)}%`,
          });
        } else {
          diffItem.powers.push({
            rail_id: railA.rail_id,
            rail_name: railA.rail_name,
            order: railA.order,
            value: null,
          });
        }
      }

      for (const column of this.scoreHeadColumns) {
        if (column.link && itemA[column.field] && itemB[column.field]) {
          diffItem[column.field] = `${column.link}${itemB.id},${itemA.id}`;
        }
      }

      this.scoreData.items = this.scoreData.items.slice(0, testCount);

      this.scoreData.items.push(diffItem);
    },
    createChart() {
      if (this.checkedRows.length <= 0) {
        alert("Please select more items.");
        return;
      }

      this.visibleGraph = true;

      const power = this.checkedRows.some(name => name.startsWith("power "));
      const fps = this.checkedRows.some(name => !name.startsWith("power "));

      var series = [];

      for (const rowName of this.checkedRows) {
        if (rowName.startsWith("power ")) {
          const powerName = rowName.replace(/^power /, "");
          const data = this.scoreData.items.map(scoreItem => {
            const powerObj = scoreItem.powers?.find(
              p => p.rail_name === powerName,
            );
            return powerObj ? powerObj.value : null;
          });
          series.push({
            name: powerName,
            data,
            yAxis: 0,
          });
        } else {
          const data = this.scoreData.items.map(
            scoreItem => scoreItem[rowName],
          );
          series.push({
            name: rowName,
            data,
            yAxis: 1,
          });
        }
      }

      this.$refs.compareGraph.setData(
        power,
        fps,
        this.name,
        this.testData.map(x => x.name),
        series,
      );
    },
    clickDeleteBtn() {
      if (this.selectedTests.length === 0) {
        alert("Please select tests.");
        return;
      }

      if (confirm("Do you want to delete these tests?") == false) {
        return;
      }

      const deleteId = this.selectedTests.map(x => this.testData[x].id);

      if (this.$route.name === "TicketInfo") {
        this.testId = this.testData
          .filter(x => deleteId.includes(x.id))
          .map(x => x.id);

        this.$http
          .delete(`/api/tickets/${this.ticketId}/${this.testId}`)
          .then(() => {
            window.location.reload();
          })
          .catch(err => {
            alert(err.message);
          });
      } else if (this.$route.name === "TestScoreComparisonById") {
        if (this.selectedTests.length === this.testData.length) {
          alert("Can not delete all tests.");
          return;
        }

        this.testId = this.testData
          .filter(x => deleteId.includes(x.id))
          .map(x => x.id);

        this.$http
          .delete(`/api/comparisons/${this.comparisonId}/${this.testId}`)
          .then(() => {
            window.location.reload();
          })
          .catch(err => {
            alert(err);
          });
      } else if (this.$route.name === "TestScoreComparison") {
        this.testId = this.testData
          .filter(x => deleteId.includes(x.id) === false)
          .map(x => x.id)
          .join(",");

        this.$router.push({
          name: "TestScoreComparison",
          query: {
            id: this.testId,
          },
        });
      }
    },
    copyToClipboard() {
      const checkboxColumn = document.getElementsByClassName("col-checkbox");
      const testId = document.getElementsByClassName("test-id");

      for (const column of checkboxColumn) {
        column.style.display = "none";
      }

      for (const id of testId) {
        id.style.display = "";
      }

      let containerNode = document.getElementById(
        `${this.groupIndex}-score-table`,
      );

      var range = document.createRange();
      range.selectNode(containerNode);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);
      document.execCommand("copy");
      window.getSelection().removeAllRanges();

      for (const column of checkboxColumn) {
        column.style.display = "";
      }

      for (const id of testId) {
        id.style.display = "none";
      }
    },
    prevColumn(index) {
      if (index != 0) {
        this.moveColumn(index, index - 1);
      }
    },
    nextColumn(index) {
      if (index != this.testData.length - 1) {
        this.moveColumn(index, index + 1);
      }
    },
    moveColumn(a, b) {
      this.swap(this.testData, a, b);
      this.swap(this.scoreData.items, a, b);
    },
    swap(list, a, b) {
      var temp = list[a];
      list.splice(a, 1);
      list.splice(b, 0, temp);
    },
    removeDiffColumn() {
      if (this.testData.length === this.scoreData.count) {
        return;
      }
      this.testData.splice(this.testData.length - 1, 1);
      this.scoreData.items.splice(this.scoreData.items.length - 1, 1);
    },
    findApproximation(arr, target) {
      const sorted = [...arr].filter(v => v !== null).sort((a, b) => a - b);

      const min = sorted[0];
      const max = sorted[sorted.length - 1];

      if (target < min || target > max) return [];

      for (let i = 0; i < sorted.length - 1; i++) {
        const low = sorted[i];
        const high = sorted[i + 1];
        if (low <= target && target <= high) {
          return [low, high];
        }
      }

      return []; // fallback
    },
    getPowerValue(powers, railName) {
      const rail = powers.find(p => p.rail_name === railName);
      return rail?.value ?? null;
    },
    showModalfunc() {
      if (this.selectedTests.length === 0) {
        if (confirm("Analyze all tests?")) {
          this.showModal = true;
        } else {
          alert("Please select more items.");
        }
        return;
      }
      if (this.selectedTests.length < 2) {
        alert("Please select more items.");
        return;
      }
      this.showModal = true;
    },
    runAiAgent() {
      this.showModal = false;

      this.patchesInfo;
      this.selectedAITests = [];
      if (this.selectedTests.length === 0) {
        for (const item of this.scoreData.items) {
          this.selectedAITests.push(item.test_id);
        }
      } else {
        for (const selectedTest of this.selectedTests) {
          this.selectedAITests.push(this.scoreData.items[selectedTest].test_id);
        }
      }
      this.visibleAi = true;
    },
  },
};
</script>

<style scoped>
.click-btn {
  cursor: pointer;
  color: lightgray;
}

.click-btn:hover {
  cursor: pointer;
  color: gray;
}

th.ppa-columns {
  background-color: #e6f7f5;
}

.test-id-column {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.rotate-button {
  transform: rotate(90deg);
  padding: 0.4rem 0.5rem;
  font-size: 0.875rem;
  margin-left: 0.3rem;
}

.inline-elements {
  display: inline-block;
}
</style>
