<template>
  <div style="width: 100%; margin-right: 10px; max-width: 1000px">
    <chart style="width: 100%" :options="chartOptions"></chart>
    <div class="sub-title-group" style="margin-top: 10px">
      <span class="sub-title">Result</span>
      <div class="sub-title-btn-group">
        <b-button variant="secondary" size="sm" @click="expandAll"
          >Expand All
        </b-button>
        <b-button variant="secondary" size="sm" @click="FoldAll"
          >Fold All
        </b-button>
        <b-button
          style="margin-left: 0.3rem"
          variant="secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="download Excel Data"
          :href="`${this.url}/api/weekly/${this.id[this.index]}/excel`">
          <font-awesome-icon icon="download" />
        </b-button>
      </div>
    </div>
    <ve-table
      :columns="columns"
      :table-data="summaryLocal"
      :border-x="true"
      :border-y="true"
      :sort-option="sortOption"
      :expand-option="expandOption"
      :cell-selection-option="cellSelectionOption"
      row-key-field-name="rowKey" />
  </div>
</template>

<script>
import { Chart } from "highcharts-vue";

const ChildTableComp = {
  name: "ChildTableComp",
  template: `
        <div class="child-table-comp" style="padding: 3%;">
            <span style="font-weight:bold;">Result Table: {{name}}</span>
            <ve-table
              style="width:100%"
              :columns="columns"
              :table-data="datas"
            />
        </div>
    `,
  props: {
    datas: Array,
    columns: Array,
    name: String,
  },
  data() {
    return {};
  },
  created() {},
};

export default {
  name: "topGameResultGraph",
  components: {
    Chart,
  },
  props: {
    pieChartData: Array,
    issueDatas: Array,
    dateTitle: Object,
    summary: Array,
    iscompare: Boolean,
    index: Number,
    gpulibver: Object,
  },
  data() {
    return {
      expandOption: {
        expandedRowKeys: [],
        expandable: ({ row }) => {
          if (row["name"] === "PASS") {
            return false;
          }
        },
        afterExpandRowChange: ({ afterExpandedRowKeys }) => {
          this.changeExpandedRowKeys(afterExpandedRowKeys);
        },
        render: ({ row }) => {
          var result = row.name;
          this.returnExpandtableData(result);
          return (
            <ChildTableComp
              datas={this.expandTableData[result]}
              columns={this.columnsFail}
              name={result}
            />
          );
        },
      },
      expandTableData: [],
      border: "solid 1px black",
      id: [],
      url: "",
      issueType: {
        "Pass": "pass",
        "ANR": "ANR",
        "N/A": "NA",
        "Rendering Error": "RenderingError",
        "CRASH": "CRASH",
        "NOT_INSTALL": "NOT_INSTALL",
        "Not Test": "NotTest",
      },
      date: "",
      sortOption: {
        sortAlways: true,
        sortChange: params => {
          this.sortChange(params);
        },
      },
      filteredtableData: [],
      columns: [
        {
          field: "sf",
          key: "expd",
          type: "expand",
          title: "",
          width: "3px",
          align: "center",
        },
        {
          field: "name",
          key: "c",
          title: "result",
          align: "center",
        },
        {
          field: "y",
          key: "d",
          title: "count",
          align: "center",
          sortBy: "desc",
        },
      ],
      columnsFail: [
        {
          field: "app_name",
          key: "c",
          title: "App Info",
          align: "center",
        },
        {
          field: "result",
          key: "a",
          title: "issue Type",
          align: "center",
          filter: {
            filterList: [
              {
                value: 1,
                label: "ANR",
                selected: false,
              },
              {
                value: 2,
                label: "N/A",
                selected: false,
              },
              {
                value: 3,
                label: "Rendering Error",
                selected: false,
              },
              {
                value: 4,
                label: "CRASH",
                selected: false,
              },
              {
                value: 5,
                label: "NOT_INSTALL",
                selected: false,
              },
              {
                value: 6,
                label: "Not Test",
                selected: false,
              },
              {
                value: 7,
                label: "ETC",
                selected: false,
              },
            ],
            isMultiple: true,
            filterConfirm: filterList => {
              const labels = filterList
                .filter(x => x.selected)
                .map(x => x.label);
              this.searchByProjectField(labels);
            },
          },
        },

        {
          field: "comment",
          key: "d",
          title: "Comment",
          align: "center",
        },
        {
          field: "pixel",
          key: "d1",
          title: "Pixel",
          align: "center",
        },
        {
          field: "lower_android_version",
          key: "d2",
          title: "Lower Android Ver",
          align: "center",
        },
        {
          field: "ged",
          key: "d3",
          title: "in GED",
          align: "center",
        },
        {
          field: "user_binary",
          key: "d4",
          title: "in UserBinary",
          align: "center",
        },
      ],
      chartOptions: {
        chart: {
          type: "pie",
          height: 550,
        },
        title: {
          text: `${this.dateTitle.title}`,
          style: { fontSize: "26px" },
          // text: this.test,
        },
        subtitle: {
          text: `${this.dateTitle.date} / ANGLE: ${this.gpulibver.angle} / SVK: ${this.gpulibver.svk}`,
        },
        tooltip: {
          // pointFormat: "{series.name}: <b>{point.percentage:.1f}%</b>"
          pointFormat: "{series.name}: <b>{point.y}</b>",
        },
        accessibility: {
          point: {
            valueSuffix: "%",
          },
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: "pointer",
            dataLabels: {
              enabled: true,
            },
            showInLegend: true,
          },
        },
        series: [
          {
            name: "Count",
            colorByPoint: true,
            data: this.pieChartData,
          },
        ],
        legend: {},
        exporting: {
          enabled: false,
        },
        credits: {
          enabled: false,
        },
      },
      cellSelectionOption: {
        enable: false,
      },
      summaryLocal: this.summary,
    };
  },
  watch: {
    dateTitle() {
      this.chartOptions.title.text = `${this.dateTitle.title}<br>${this.dateTitle.date}`;
    },
  },
  methods: {
    searchByProjectField(labels) {
      this.issueDatas = this.filteredtableData.filter(
        x => labels.length === 0 || labels.includes(x.result),
      );
    },
    filterReset: () => {
      this.searchByProjectField([]);
    },

    pieData() {
      return this.pieChartData[this.id[0]];
    },
    sortChange(params) {
      this.summaryLocal.sort((a, b) => {
        if (params.y) {
          if (params.y === "asc") {
            return a.y - b.y;
          } else if (params.y === "desc") {
            return b.y - a.y;
          } else {
            return 0;
          }
        }
      });
    },
    returnExpandtableData(resultVal) {
      this.expandTableData[resultVal] = [];
      for (let i in this.issueDatas) {
        if (this.issueDatas[i].result === resultVal) {
          this.expandTableData[resultVal].push(this.issueDatas[i]);
        }
      }
      return true;
    },
    expandAll() {
      this.expandOption.expandedRowKeys = this.summaryLocal.map(x => x.rowKey);
    },
    FoldAll() {
      this.expandOption.expandedRowKeys = [];
    },

    changeExpandedRowKeys(keys) {
      this.expandOption.expandedRowKeys = keys;
    },
  },
  created() {
    this.filteredtableData = this.issueDatas;
    if (this.$route.params.id.length >= 3) {
      this.id = this.$route.params.id.split(",");
    } else {
      this.id = [this.$route.params.id];
    }
    this.url = window.location.origin;
    console.log(this.url);
  },
};
</script>

<style>
/* .flex-container {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
} */

/* .pieChart {
  display: flex;
  /* flex-basis: 70%; */
/* }  */

/* .summaryTable {
  display: flex;
  flex-basis: 70%;
} */
</style>
