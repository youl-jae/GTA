<template>
  <vue-good-table
    @on-page-change="onPageChange"
    @on-per-page-change="onPerPageChange"
    ref="table"
    :key="tableKey"
    :totalRows="totalRecords"
    :columns="columns"
    :rows="rows"
    :select-options="{
      enabled: true,
      selectOnCheckboxOnly: true,
      disableSelectInfo: true,
    }"
    :search-options="{
      enabled: false,
      trigger: 'enter',
      placeholder: 'Filter this table',
      skipDiacritics: true,
    }"
    :pagination-options="{
      enabled: true,
      perPage: 50,
      perPageDropdown: [25, 50, 75, 100],
      mode: 'pages',
      dropdownAllowAll: false,
      setCurrentPage: currentPage,
    }"
    :sort-options="{
      enabled: true,
      initialSortBy: initialSortBy,
    }"
    @on-row-click="onRowClick"
    styleClass="vgt-table condensed benchmark-table">
    <template slot="table-row" slot-scope="props">
      <span v-if="props.column.field == 'is_favorite'" class="favorite">{{
        props.row.is_favorite ? "★" : "☆"
      }}</span>
      <span v-else-if="props.column.field == 'date'">{{
        props.row.date.substring(0, 16)
      }}</span>
      <div v-else-if="props.column.field == 'log'" class="log-field">
        <span v-show="props.row.amigo_log" class="log-icon amigo-icon">A</span>
        <span v-show="props.row.gamebench_url" class="log-icon gamebench-icon"
          >G</span
        >
        <span v-show="props.row.quickperf_url" class="log-icon quickperf-icon"
          >Q</span
        >
      </div>
      <span v-else>{{ props.row[props.column.field] }}</span>
    </template>
  </vue-good-table>
</template>

<script>
import "vue-good-table/dist/vue-good-table.css";
import { VueGoodTable } from "vue-good-table";

export default {
  name: "BenchmarkTable",
  components: {
    VueGoodTable,
  },
  props: {
    totalRecords: Number,
    rows: Array,
  },
  computed: {
    selectedRows() {
      return this.$refs.table.selectedRows;
    },
  },
  data() {
    return {
      isLoading: false,
      columns: [
        {
          label: "",
          field: "app_id",
          hidden: true,
        },
        {
          label: "",
          field: "is_favorite",
          sortable: false,
          tdClass: "text-center",
          width: "1px",
        },
        {
          label: "",
          field: "id",
          sortable: false,
          tdClass: "text-center",
          // hidden: true
        },
        {
          label: "Title",
          field: "title",
          width: "45%",
        },
        {
          label: "Project",
          field: "project",
          tdClass: "text-center",
          width: "6%",
        },
        {
          label: "App",
          field: "app",
          tdClass: "text-center",
        },
        {
          label: "Board",
          field: "board",
          tdClass: "text-center",
          width: "10%",
        },
        {
          label: "FPS",
          field: "fps",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Power",
          field: "power",
          tdClass: "text-center",
          type: "number",
          width: "6%",
        },
        {
          label: "Date",
          field: "date",
          tdClass: "text-center",
          width: "6%",
        },
        {
          label: "Tester",
          field: "tester",
          tdClass: "text-center",
          width: "6%",
        },
        {
          label: "",
          field: "log",
          sortable: false,
          tdClass: "text-center",
          width: "5%",
        },
      ],

      tableKey: 0,
      currentPage: 1,
      initialSortBy: null,
    };
  },
  methods: {
    init() {
      const searchTerm = sessionStorage.getItem("benchmarkSearchTerm");
      var currentPage = sessionStorage.getItem("benchmarkCurrentPage");
      // const selectedRows = JSON.parse(sessionStorage.getItem("benchmarkSelectedRows"));
      const sorts = JSON.parse(sessionStorage.getItem("benchmarkSorts"));

      if (searchTerm) {
        this.$refs.table.globalSearchTerm = searchTerm;
      }

      if (currentPage) {
        currentPage = parseInt(currentPage);

        this.currentPage = currentPage;
        this.$refs.table.changePage(currentPage);
      }

      if (sorts) {
        this.initialSortBy = sorts[0];
        this.$refs.table.changeSort(sorts);
      }
      // if (selectedRows) {
      // for (const row of selectedRows) {
      // this.$set(this.$refs.table.rows[row.originalIndex], 'vgtSelected', true);
      // this.$refs.table.rows[row.originalIndex].vgtSelected = true;
      // }
      // this.$refs.table.selectedRows = selectedRows;
      // console.log(this.$refs.table.selectedRows);
      // }
    },
    saveSessionStorage() {
      sessionStorage.setItem(
        "benchmarkSearchTerm",
        this.$refs.table.searchTerm,
      );
      sessionStorage.setItem(
        "benchmarkCurrentPage",
        this.$refs.table.currentPage,
      );
      sessionStorage.setItem(
        "benchmarkSorts",
        JSON.stringify(this.$refs.table.sorts),
      );
      // sessionStorage.setItem("benchmarkSelectedRows", JSON.stringify(this.$refs.table.selectedRows));
    },
    onRowClick(params) {
      let path = params.event.target;

      if (path.className == "vgt-checkbox-col" || path.nodeName == "INPUT") {
        return;
      } else if (path.innerText == "☆" || path.innerText == "★") {
        this.$http.put(`/api/tests/${params.row.id}/favorite`).then(() => {
          this.rows[params.row.originalIndex].is_favorite =
            !this.rows[params.row.originalIndex].is_favorite;
        });
      } else if (path.className == "log-icon amigo-icon") {
        window.open(
          `http://g2.gta.samsungds.net/#/log/${params.row.testitem_id}`,
        );
        return;
      } else if (path.className == "log-icon gamebench-icon") {
        window.open(params.row.gamebench_url);
        return;
      } else if (path.className == "log-icon quickperf-icon") {
        window.open(params.row.quickperf_url);
        return;
      } else {
        this.saveSessionStorage();

        this.$router.push({
          name: "TestScore",
          params: {
            id: params.row.id,
          },
        });
      }
    },
    resetTable() {
      this.tableKey += 1;
      this.$refs.table.reset();
    },
    onPageChange(params) {
      this.$emit("page-change", params);
    },
    onPerPageChange(params) {
      this.$emit("per-page-change", params);
    },
  },
};
</script>

<style>
/*table.benchmark-table {
  table-layout: fixed;
  white-space: pre-wrap;
  word-wrap: break-word;
}

.vgt-table th.vgt-checkbox-col {
  width: 35px;
  padding: 0em;
}*/
</style>
