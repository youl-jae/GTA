<template>
  <li>
    <router-link v-if="routeName" :to="{ name: routeName, query: routeQuery }">
      {{ text }}
    </router-link>
    <a v-if="href" :href="href" target="_blank">
      {{ text }}
    </a>

    <label
      v-show="subMenu"
      :for="'sm' + text"
      title="Toggle Drop-down"
      class="drop-icon"
      >▾</label
    >
    <input v-show="subMenu" type="checkbox" :id="'sm' + text" />

    <ul v-show="subMenu" class="sub-menu">
      <nav-menu
        v-for="item in subMenu"
        :key="text + '-' + item.text"
        :text="item.text"
        :routeName="item.routeName"
        :routeQuery="item.routeQuery"
        :subMenu="item.subMenu"></nav-menu>
    </ul>
  </li>
</template>

<script>
import NavMenu from "@/components/navigation/NavMenu.vue";

export default {
  name: "NavMenu",
  components: {
    NavMenu,
  },
  props: {
    text: String,
    routeName: String,
    routeQuery: Object,
    subMenu: Array,
    href: String,
  },
};
</script>
