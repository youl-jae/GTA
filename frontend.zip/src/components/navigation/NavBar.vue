<template>
  <nav id="menu">
    <label for="tm" id="toggle-menu"
      >Menu <span class="drop-icon">▾</span></label
    >
    <input type="checkbox" id="tm" />
    <ul class="main-menu clearfix">
      <nav-menu
        v-for="item in menu"
        :key="item.text"
        :text="item.text"
        :routeName="item.routeName"
        :routeQuery="item.routeQuery"
        :subMenu="item.subMenu"
        :href="item.href"></nav-menu>
    </ul>
  </nav>
</template>

<script>
import NavMenu from "@/components/navigation/NavMenu.vue";

export default {
  name: "NavBar",
  components: {
    NavMenu,
  },

  mounted() {
    const roles = this.$store.state.userStore.roles;
    console.log("roles[0]:", roles[0]);
  },

  computed: {
    isAdmin() {
      return this.$store.getters.isBenchmarkKpiManager;
    },
    menu() {
      const baseMenu = [
        {
          text: "TICKET",
          routeName: "TicketList",
          subMenu: [
            { text: "KPI Ticket", routeName: "KpiTicketList" },
            { text: "My Ticket", routeName: "MyTicketList" },
          ],
        },
        {
          text: "GAME",
          routeName: "GameList",
          subMenu: [],
        },
        {
          text: "BENCHMARK",
          routeName: "BenchmarkList",
          subMenu: [],
        },
        {
          text: "CHIP INFO",
          routeName: "ChipInfo",
        },
        {
          text: "SEARCH",
          routeName: "Search",
        },
        {
          text: "LOG PROFILER",
          routeName: "ProfilingAmigoLog",
          subMenu: [
            { text: "AMIGO Log", routeName: "ProfilingAmigoLog" },
            { text: "Soc Dumper Viewer", routeName: "ProfilingShowFreqLog" },
            { text: "Power Viewer", routeName: "ProfilingPower" },
          ],
        },
        {
          text: "ISSUE",
          routeName: "IssueList",
        },
        {
          text: "XCLIPSE PORTAL",
          href: "http://gpu.samsungds.net/",
        },
      ];

      // ✅ ADMIN일 때만 추가
      if (this.isAdmin) {
        baseMenu.push({
          text: "ADMIN PAGE",
          routeName: "AdminPage",
          subMenu: [],
        });
      }

      return baseMenu;
    },
  },
};
</script>

<style>
#menu ul {
  margin: 0;
  padding: 0;
}

#menu .main-menu {
  display: none;
}

#tm:checked + .main-menu {
  display: block;
}

#menu input[type="checkbox"],
#menu ul span.drop-icon {
  display: none;
}

#menu li,
#toggle-menu,
#menu .sub-menu {
  border-style: solid;
  border-color: rgba(0, 0, 0, 0.05);
}

#menu li,
#toggle-menu {
  border-width: 0 0 1px;
}

#menu .sub-menu {
  background-color: #4472C4;
  border-width: 1px 1px 0;
  margin: 0 1em;
}

#menu .sub-menu li:last-child {
  border-width: 0;
}

#menu li,
#toggle-menu,
#menu a {
  position: relative;
  display: block;
  color: white;
  text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.125);
  text-decoration: none;
}

#menu .main-menu a {
  border-style: solid;
  border-width: 0.1ch;
  border-color: #4472C4;
}

#menu .sub-menu a {
  border-style: solid;
  border-width: 0.1ch;
  border-color: #4472C4;
}

#menu,
#toggle-menu {
  background-color: #4472C4;
}

#toggle-menu,
#menu a {
  padding: 0.8em 1.8em;
}

#menu a {
  transition: all 0.125s ease-in-out;
  -webkit-transition: all 0.125s ease-in-out;
}

#menu a:hover {
  background-color: white;
  color: #4472C4;
  border-style: solid;
  border-width: 0.1ch;
  border-color: #4472C4;
}

#menu .sub-menu {
  display: none;
}

#menu input[type="checkbox"]:checked + .sub-menu {
  display: block;
}

#menu .sub-menu a:hover {
  color: #4472C4;
}

#toggle-menu .drop-icon,
#menu li label.drop-icon {
  position: absolute;
  right: 1.5em;
  top: 1.25em;
}

#menu label.drop-icon,
#toggle-menu span.drop-icon {
  width: 1em;
  height: 1em;
  text-align: center;
  text-shadow: 0 0 0 transparent;
  color: rgba(255, 255, 255, 0.75);
}

#menu .drop-icon {
  line-height: 1;
}

@media only screen and (max-width: 64em) and (min-width: 52.01em) {
  #menu li {
    width: 33.333%;
  }

  #menu .sub-menu li {
    width: auto;
  }
}

@media only screen and (min-width: 52em) {
  #menu .main-menu {
    display: block;
  }

  #toggle-menu,
  #menu label.drop-icon {
    display: none;
  }

  #menu ul span.drop-icon {
    display: inline-block;
  }

  #menu li {
    float: left;
    border-width: 0 1px 0 0;
  }

  #menu .sub-menu li {
    float: none;
  }

  #menu .sub-menu {
    border-width: 0;
    margin: 0;
    position: absolute;
    top: 100%;
    left: 0;
    width: 13.5em;
    z-index: 3000;
  }

  #menu .sub-menu,
  #menu input[type="checkbox"]:checked + .sub-menu {
    display: none;
  }

  #menu .sub-menu li {
    border-width: 0 0 1px;
  }

  #menu .sub-menu .sub-menu {
    top: 0;
    left: 100%;
  }

  #menu li:hover > input[type="checkbox"] + .sub-menu {
    display: block;
  }
}

@media (min-width: 1200px) {
  .container,
  .container-lg,
  .container-md,
  .container-sm,
  .container-xl {
    max-width: 1600px;
  }
}
</style>
