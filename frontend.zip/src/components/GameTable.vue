<template>
  <vue-good-table
    @on-page-change="onPageChange"
    @on-per-page-change="onPerPageChange"
    ref="table"
    :key="tableKey"
    :totalRows="totalRecords"
    :columns="columns"
    :rows="rows"
    :select-options="{
      enabled: true,
      selectOnCheckboxOnly: true,
      disableSelectInfo: true,
    }"
    :search-options="{
      enabled: false,
      placeholder: 'Filter this table',
      skipDiacritics: true,
    }"
    :pagination-options="{
      enabled: true,
      perPage: 50,
      perPageDropdown: [25, 50, 75, 100],
      mode: 'pages',
      dropdownAllowAll: false,
      setCurrentPage: currentPage,
    }"
    :sort-options="{
      enabled: true,
      initialSortBy: initialSortBy,
    }"
    @on-row-click="onRowClick"
    styleClass="vgt-table condensed">
    <template slot="table-row" slot-scope="props">
      <span v-if="props.column.field == 'is_favorite'" class="favorite">{{
        props.row.is_favorite ? "★" : "☆"
      }}</span>
      <!-- <span v-else-if="props.column.field == 'title'">{{ props.row.id }} {{ props.row.title }}</span> -->
      <span
        v-else-if="props.column.field == 'length' && props.row.length != null"
        >{{ props.row.length }} min</span
      >
      <span
        v-else-if="
          props.column.field == 'average_fps' && props.row.average_fps != null
        "
        >{{ props.row.average_fps.toFixed(1) }}</span
      >
      <span
        v-else-if="
          props.column.field == 'median_fps' && props.row.median_fps != null
        "
        >{{ props.row.median_fps.toFixed(1) }}</span
      >
      <span
        v-else-if="props.column.field == 'power' && props.row.power != null"
        >{{ props.row.power }}</span
      >
      <span v-else-if="props.column.field == 'date'">{{
        props.row.date.substring(0, 10)
      }}</span>
      <div v-else-if="props.column.field == 'log'" class="log-field">
        <span v-show="props.row.amigo_log" class="log-icon amigo-icon">A</span>
        <span v-show="props.row.gamebench_url" class="log-icon gamebench-icon"
          >G</span
        >
        <span v-show="props.row.quickperf_url" class="log-icon quickperf-icon"
          >Q</span
        >
      </div>
      <span v-else>{{ props.row[props.column.field] }}</span>
    </template>
  </vue-good-table>
</template>

<script>
import "vue-good-table/dist/vue-good-table.css";
import { VueGoodTable } from "vue-good-table";

export default {
  name: "GameTable",
  components: {
    VueGoodTable,
  },
  props: {
    totalRecords: Number,
    rows: Array,
  },
  computed: {
    selectedRows() {
      return this.$refs.table.selectedRows;
    },
  },
  data() {
    return {
      columns: [
        {
          label: "",
          field: "is_favorite",
          sortable: false,
          tdClass: "text-center",
          width: "1px",
        },
        {
          label: "",
          field: "id",
          sortable: false,
          tdClass: "text-center",
          // hidden: true
        },
        {
          label: "Title",
          field: "title",
          width: "45%",
        },
        {
          label: "Project",
          field: "project",
          tdClass: "text-center",
        },
        {
          label: "App",
          field: "app",
          tdClass: "text-center",
          width: "10%",
        },
        {
          label: "Board",
          field: "board",
          tdClass: "text-center",
          width: "10%",
        },
        {
          label: "Length",
          field: "length",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Average FPS",
          field: "average_fps",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Median FPS",
          field: "median_fps",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Power",
          field: "power",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Date",
          field: "date",
          tdClass: "text-center",
          width: "10%",
        },
        {
          label: "Tester",
          field: "tester",
          tdClass: "text-center",
        },
        {
          label: "",
          field: "log",
          sortable: false,
          tdClass: "text-center",
          width: "5%",
        },
      ],
      tableKey: 0,
      currentPage: 1,
      initialSortBy: null,
    };
  },
  methods: {
    init() {
      const searchTerm = sessionStorage.getItem("gameSearchTerm");
      var currentPage = sessionStorage.getItem("gameCurrentPage");
      const sorts = JSON.parse(sessionStorage.getItem("gameSorts"));

      if (searchTerm) {
        this.$refs.table.globalSearchTerm = searchTerm;
      }

      if (currentPage) {
        currentPage = parseInt(currentPage);

        this.currentPage = currentPage;
        this.$refs.table.changePage(currentPage);
      }

      if (sorts) {
        this.initialSortBy = sorts[0];
        this.$refs.table.changeSort(sorts);
      }
    },
    saveSessionStorage() {
      sessionStorage.setItem("gameSearchTerm", this.$refs.table.searchTerm);
      sessionStorage.setItem("gameCurrentPage", this.$refs.table.currentPage);
      sessionStorage.setItem(
        "gameSorts",
        JSON.stringify(this.$refs.table.sorts),
      );
    },
    onRowClick(params) {
      let path = params.event.target;

      if (path.className == "vgt-checkbox-col" || path.nodeName == "INPUT") {
        return;
      } else if (path.innerText == "☆" || path.innerText == "★") {
        this.$http.put(`/api/tests/${params.row.id}/favorite`).then(row => {
          this.rows[params.row.originalIndex].is_favorite =
            !this.rows[params.row.originalIndex].is_favorite;
          console.log(row.data);
        });
      } else if (path.className == "log-icon amigo-icon") {
        window.open(`http://g2.gta.samsungds.net/#/log/${params.row.testitem_id}`);
        return;
      } else if (path.className == "log-icon gamebench-icon") {
        window.open(params.row.gamebench_url);
        return;
      } else if (path.className == "log-icon quickperf-icon") {
        window.open(params.row.quickperf_url);
        return;
      } else {
        this.saveSessionStorage();

        this.$router.push({
          name: "TestScore",
          params: {
            id: params.row.id,
          },
        });
      }
    },
    resetTable() {
      this.tableKey += 1;
      this.$refs.table.reset();
    },
    onPageChange(params) {
      this.$emit("page-change", params);
    },
    onPerPageChange(params) {
      this.$emit("per-page-change", params);
    },
  },
};
</script>

<style>
.favorite {
  color: #ffc000;
}

.log-field {
  display: flex;
  justify-content: center;
  padding-right: 0.5rem;
}

.log-icon {
  color: white;
  font-weight: bold;
  width: 16px;
  height: 16px;
  line-height: 1;
}

.amigo-icon {
  background: rgb(0, 112, 192, 0.8);
}

.gamebench-icon {
  background: rgb(255, 122, 18, 0.8);
}

.quickperf-icon {
  background: rgb(99, 198, 71, 0.8);
}

table.vgt-table {
  font-size: 14px;
}

table.vgt-table thead th {
  text-align: center;
  vertical-align: middle;
}

.vgt-wrap__footer .footer__navigation__info {
  margin: 0px;
  padding-top: 3px;
}

.vgt-wrap__footer,
.vgt-wrap__footer .footer__navigation,
.vgt-wrap__footer .footer__row-count__label,
.vgt-wrap__footer .footer__row-count__select,
.vgt-wrap__footer .footer__navigation__page-btn span {
  font-size: 14px;
  margin-bottom: 0px;
}
</style>
