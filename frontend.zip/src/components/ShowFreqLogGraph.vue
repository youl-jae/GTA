<template>
  <highcharts
    constructor-type="stockChart"
    :options="chartOptions"></highcharts>
</template>

<script>
import { Chart } from "highcharts-vue";
import Highcharts from "highcharts";
import stockInit from "highcharts/modules/stock";
import boost from "highcharts/modules/boost";

stockInit(Highcharts);
boost(Highcharts);

export default {
  name: "ShowFreqLogGraph",
  props: {
    title: String,
    series: Array,
    pointInterval: Number,
  },
  components: {
    highcharts: Chart,
  },
  data() {
    return {
      chartOptions: {
        chart: {
          type: "line",
          height: 600,
          zoomType: "x",
          animation: false,
          borderWidth: 1,
          borderColor: "#e6e6e6",
        },
        boost: {
          enabled: true,
          useGPUTranslations: true,
        },
        title: {
          text: this.title,
        },
        credits: {
          enabled: false,
        },
        scrollbar: {
          liveRedraw: true,
        },
        navigator: {
          height: 30,
        },
        rangeSelector: {
          enabled: true,
          inputEnabled: false,
          buttons: [
            {
              type: "second",
              count: 1,
              text: "1s",
              title: "View 1 second",
            },
            {
              type: "second",
              count: 30,
              text: "30s",
              title: "View 30 second",
            },
            {
              type: "minute",
              count: 1,
              text: "1m",
              title: "View 1 minute",
            },
            {
              type: "minute",
              count: 5,
              text: "5m",
              title: "View 5 minute",
            },
            {
              type: "minute",
              count: 10,
              text: "10m",
              title: "View 10 minute",
            },
            {
              type: "all",
              text: "All",
              title: "View all",
            },
          ],
        },
        legend: {
          enabled: true,
        },
        tooltip: {
          enabled: true,
          crosshairs: true,
          shared: true,
          split: false,
          borderColor: "rgb(100, 100, 100)",
          headerFormat: "<span>{point.index}</span><br/>",
        },
        plotOptions: {
          line: {
            lineWidth: 1,
            shadow: false,
            animation: false,
            boostThreshold: 1,
            pointInterval: this.pointInterval,
          },
        },
        xAxis: {
          lineWidth: 1,
          lineColor: "#e6e6e6",
          showLastLabel: true,
          dateTimeLabelFormats: {
            millisecond: "%H:%M:%S.%L",
            second: "%H:%M:%S",
            minute: "%H:%M:%S",
            hour: "%H:%M:%S",
            day: "%H:%M:%S",
            week: "%H:%M:%S",
            month: "%H:%M:%S",
            year: "%H:%M:%S",
          },
        },
        yAxis: [
          {
            min: 0,
            // max: 4500,
            tickInterval: 500,
            startOnTick: false,
            endOnTick: false,
            opposite: false,
            showLastLabel: true,
          },
          {
            min: 0,
            // max: 135,
            tickInterval: 15,
            startOnTick: false,
            endOnTick: false,
            opposite: true,
            showLastLabel: true,
          },
        ],
        series: this.series,
      },
    };
  },
};
</script>
