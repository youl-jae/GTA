<template>
  <vue-good-table
    ref="table"
    :key="tableKey"
    :columns="columns"
    :rows="rows"
    :select-options="{
      enabled: true,
      selectOnCheckboxOnly: true,
      disableSelectInfo: true,
    }"
    :search-options="{
      enabled: true,
      placeholder: 'Filter this table',
      skipDiacritics: true,
    }"
    :pagination-options="{
      enabled: true,
      perPage: 50,
      perPageDropdown: [25, 50, 75, 100],
      setCurrentPage: currentPage,
    }"
    :sort-options="{
      enabled: true,
      initialSortBy: initialSortBy,
    }"
    @on-row-click="onRowClick"
    styleClass="vgt-table condensed">
    <template slot="table-row" slot-scope="props">
      <span v-if="props.column.field == 'is_favorite'" class="star">{{
        props.row.is_favorite ? "★" : "☆"
      }}</span>
      <span
        v-else-if="props.column.field == 'length' && props.row.length != null"
        >{{ props.row.length }} min</span
      >
      <span v-else-if="props.column.field == 'fps' && props.row.fps != null">{{
        props.row.fps.toFixed(1)
      }}</span>
      <span
        v-else-if="props.column.field == 'power' && props.row.power != null"
        >{{ props.row.power }}</span
      >
      <span v-else-if="props.column.field == 'date'">{{
        props.row.date.substring(0, 10)
      }}</span>
      <div v-else-if="props.column.field == 'log'" class="log-field">
        <span v-show="props.row.amigo_log" class="log-icon amigo-icon">A</span>
        <span v-show="props.row.gamebench_url" class="log-icon gamebench-icon"
          >G</span
        >
        <span v-show="props.row.quickperf_url" class="log-icon quickperf-icon"
          >Q</span
        >
      </div>
      <span v-else>{{ props.row[props.column.field] }}</span>
    </template>
  </vue-good-table>
</template>

<script>
import "vue-good-table/dist/vue-good-table.css";
import { VueGoodTable } from "vue-good-table";

export default {
  name: "TestTable",
  components: {
    VueGoodTable,
  },
  props: {
    rows: Array,
  },
  computed: {
    selectedRows() {
      return this.$refs.table.selectedRows;
    },
  },
  data() {
    return {
      columns: [
        {
          label: "",
          field: "is_favorite",
          sortable: false,
          tdClass: "text-center",
          width: "2%",
        },
        {
          label: "",
          field: "id",
          sortable: false,
          tdClass: "text-center",
          width: "3%",
        },
        {
          label: "",
          field: "type",
          sortable: false,
          tdClass: "text-center",
          hidden: true,
        },
        {
          label: "Title",
          field: "title",
          width: "40%",
        },
        {
          label: "Project",
          field: "project",
          tdClass: "text-center",
          width: "4%",
        },
        {
          label: "App",
          field: "app",
          tdClass: "text-center",
          width: "10%",
        },
        {
          label: "Testcase",
          field: "testcase",
          tdClass: "text-center",
          width: "15%",
        },
        {
          label: "Chip",
          field: "chip",
          tdClass: "text-center",
          width: "10%",
        },
        {
          label: "Length",
          field: "length",
          tdClass: "text-center",
          type: "number",
          width: "4%",
        },
        {
          label: "FPS",
          field: "fps",
          tdClass: "text-center",
          type: "number",
          width: "4%",
        },
        {
          label: "Power",
          field: "power",
          tdClass: "text-center",
          type: "number",
          width: "4%",
        },
        {
          label: "Date",
          field: "date",
          tdClass: "text-center",
          width: "7%",
        },
        {
          label: "Tester",
          field: "tester",
          tdClass: "text-center",
          width: "4%",
        },
        {
          label: "",
          field: "log",
          sortable: false,
          tdClass: "text-center",
          width: "4%",
        },
      ],
      tableKey: 0,
      currentPage: 1,
      initialSortBy: null,
    };
  },
  methods: {
    onRowClick(params) {
      let path = params.event.target;

      if (path.className == "vgt-checkbox-col" || path.nodeName == "INPUT") {
        return;
      } else if (path.innerText == "☆" || path.innerText == "★") {
        this.$http.put(`/api/tests/${params.row.id}/favorite`).then(() => {
          this.rows[params.row.originalIndex].is_favorite =
            !this.rows[params.row.originalIndex].is_favorite;
        });
      } else if (path.className == "log-icon amigo-icon") {
        window.open(`http://g2.gta.samsungds.net/#/log/${params.row.testitem_id}`);
        return;
      } else if (path.className == "log-icon gamebench-icon") {
        window.open(params.row.gamebench_url);
        return;
      } else if (path.className == "log-icon quickperf-icon") {
        window.open(params.row.quickperf_url);
        return;
      } else {
        const routeData = this.$router.resolve({
          name: "TestScore",
          params: {
            id: params.row.id,
          },
        });

        window.open(routeData.href, "_blank");
      }
    },
    resetTable() {
      this.tableKey += 1;
      this.$refs.table.reset();
    },
  },
};
</script>

<style>
.star {
  color: #ffc000;
}

table.vgt-table {
  font-size: 14px;
  /* table-layout: fixed; */
}

table.vgt-table td {
  word-wrap: break-word;
}

.vgt-table th.vgt-checkbox-col {
  width: 35px;
  padding: 0 0.75em 0 0.75em;
}

table.vgt-table thead th {
  text-align: center;
  vertical-align: middle;
}

.vgt-wrap__footer .footer__navigation__info {
  margin: 0px;
  padding-top: 3px;
}

.vgt-wrap__footer,
.vgt-wrap__footer .footer__navigation,
.vgt-wrap__footer .footer__row-count__label,
.vgt-wrap__footer .footer__row-count__select,
.vgt-wrap__footer .footer__navigation__page-btn span {
  font-size: 14px;
  margin-bottom: 0px;
}
</style>
