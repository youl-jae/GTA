<template>
  <img :src="link" />
</template>

<script>
export default {
  props: {
    url: String,
  },
  data() {
    return {
      link: "loading",
    };
  },
  created() {
    this.getLink();
  },
  methods: {
    getLink() {
      setTimeout(() => {
        this.link = this.url;
      }, 1000);
    },
  },
};
</script>
