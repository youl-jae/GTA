<template>
  <div class="chart-wrapper">
    <highcharts
      ref="highchart"
      constructor-type="stockChart"
      :options="chartOptions">
    </highcharts>

    <button class="toggle-all-btn" @click="toggleAllSeries">
      {{ allSeriesVisible ? 'Hide All' : 'Show All' }}
    </button>
  </div>
</template>

<script>
import { Chart } from "highcharts-vue";
import Highcharts from "highcharts";
import stockInit from "highcharts/modules/stock";
import boost from "highcharts/modules/boost";

stockInit(Highcharts);
boost(Highcharts);

export default {
  name: "PowerViewerGraph",
  props: {
    index: Number,
    title: String,
    series: Array,
    pointInterval: Number,
    yAxis: Array,
  },
  components: {
    highcharts: Chart,
  },
  data() {
    return {
      chart: null,
      allSeriesVisible: true,
      chartOptions: {
        chart: {
          type: "line",
          height: 500,
          zoomType: "x",
          animation: false,
          borderWidth: 1,
          borderColor: "#e6e6e6",
          events: {
            load: (function (self) {
              return function () {
                self.chart = this;

                this.options._vue = self;

                this.caption.element.onclick = self.copyCaptionText;
                this.caption.element.onmouseover = self.mouseOver;
                this.caption.element.onmouseout = self.mouseOut;                
              };
            })(this),
          },
        },
        boost: {
          enabled: true,
          useGPUTranslations: true,
        },
        title: {
          text: this.title,
        },
        credits: {
          enabled: false,
        },
        scrollbar: {
          liveRedraw: true,
        },
        navigator: {
          height: 30,
        },
        rangeSelector: {
          enabled: true,
          inputEnabled: false,
          buttons: [
            {
              type: "second",
              count: 1,
              text: "1s",
              title: "View 1 second",
            },
            {
              type: "second",
              count: 30,
              text: "30s",
              title: "View 30 second",
            },
            {
              type: "minute",
              count: 1,
              text: "1m",
              title: "View 1 minute",
            },
            {
              type: "minute",
              count: 5,
              text: "5m",
              title: "View 5 minute",
            },
            {
              type: "minute",
              count: 10,
              text: "10m",
              title: "View 10 minute",
            },
            {
              type: "all",
              text: "All",
              title: "View all",
            },
            {
              type: "null",
              text: "Sync",
              title: "Sync range",
              events: {
                click: this.syncRange,
              },
            },
            {
              type: "null",
              text: "Calc",
              title: "calculator power",
              events: {
                click: this.calculator,
              },
            },
          ],
        },
        legend: {
          enabled: true,
        },
        tooltip: {
          enabled: true,
          crosshairs: true,
          shared: true,
          split: false,
          borderColor: "rgb(100, 100, 100)",
          headerFormat: "<span>{point.index}</span><br/>",
          pointFormat: "{series.name}: <b>{point.y:.2f}</b><br/>",
        },
        plotOptions: {
          line: {
            lineWidth: 1,
            shadow: false,
            animation: false,
            boostThreshold: 1,
            pointInterval: this.pointInterval,
          },
          series: {
            events: {
              legendItemClick: function () {
                const chart = this.chart;
                const vue = chart.options._vue;

                setTimeout(() => {
                  const anyVisible = chart.series.some(s => s.visible);

                  if (vue) {
                    vue.allSeriesVisible = anyVisible;
                  }
                }, 0);

                return true;
              },
            },
          },
        },
        xAxis: {
          lineWidth: 1,
          lineColor: "#e6e6e6",
          showLastLabel: true,
          dateTimeLabelFormats: {
            millisecond: "%H:%M:%S.%L",
            second: "%H:%M:%S",
            minute: "%H:%M:%S",
            hour: "%H:%M:%S",
            day: "%H:%M:%S",
            week: "%H:%M:%S",
            month: "%H:%M:%S",
            year: "%H:%M:%S",
          },
        },
        yAxis: this.yAxis,
        series: this.series,
      },
    };
  },
  mounted() {
    this.chart = this.$refs.highchart.chart;
  },
  methods: {
    syncRange() {
      Highcharts.charts.filter(
        chart =>
          chart &&
          chart.title.textStr.slice(0, -2) ==
            this.chartOptions.title.text.slice(0, -2),
      );

      for (const chart of Highcharts.charts) {
        if (
          chart &&
          chart.title.textStr.slice(0, -2) ==
            this.chartOptions.title.text.slice(0, -2)
        ) {
          chart.xAxis[0].setExtremes(
            this.chart.xAxis[0].min,
            this.chart.xAxis[0].max,
          );
        }
      }

      return false;
    },
    calculator() {
      const min_num = Math.floor(this.chart.xAxis[0].min / 100);
      const max_num = Math.floor(this.chart.xAxis[0].max / 100);
      const length_num = max_num - min_num;
      this.$emit("calculator", this.index, min_num, max_num, length_num);
      return false;
    },
    toggleAllSeries() {
      if (!this.chart) return;
      const anyVisible = this.chart.series.some(s => s.visible);

      this.chart.series.forEach(s => s.setVisible(!anyVisible, false));
      this.chart.redraw();
      this.allSeriesVisible = !anyVisible;
    }
  },
};
</script>

<style scoped>
.chart-wrapper {
  position: relative;
}

.toggle-all-btn {
  position: absolute;
  top: 8px;
  right: 8px;
  padding: 4px 10px;
  font-size: 11px;
  background: #f7f7f7;
  border: 1px solid #ccc;
  border-radius: 4px;
  cursor: pointer;
}

.toggle-all-btn:hover {
  background: #e6e6e6;
}
</style>
