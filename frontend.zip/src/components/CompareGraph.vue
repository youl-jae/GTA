<template>
  <div>
    <highcharts :options="chartOptions"></highcharts>

    <b-modal id="titleModal" title="Chart Title" @ok="editTitle">
      <div class="form-group">
        <label class="col-form-label">Title</label>
        <input class="form-control" type="text" v-model="title" />
      </div>
    </b-modal>
  </div>
</template>

<script>
import { Chart } from "highcharts-vue";
import Highcharts from "highcharts";
import stockInit from "highcharts/modules/stock";
import boost from "highcharts/modules/boost";

stockInit(Highcharts);
boost(Highcharts);

export default {
  props: {},
  components: {
    highcharts: Chart,
  },
  data() {
    return {
      chart: null,
      title: "",
      chartOptions: {
        // colors: [ '#A0A0A0', '#FF0000', '#0070C0', '#70AD47', '#ED7C31' ],
        // colors: ["#fcc916", "#2671b9", "#76d2ea", "#ee8301", "#f9dce1", "#664596"],
        chart: {
          type: "column",
          height: 450,
          spacing: [20, 20, 20, 170],
          animation: false,
          borderWidth: 1,
          borderColor: "#f2f2f2",
          events: {
            load: (function (self) {
              return function () {
                self.chart = this;
              };
            })(this),
            redraw: (function (self) {
              return function () {
                this.title.element.onclick = self.showTitleModal;
              };
            })(this),
          },
        },
        title: {
          text: "",
        },
        credits: {
          enabled: false,
        },
        legend: {
          enabled: true,
        },
        tooltip: {
          enabled: true,
          crosshairs: true,
          shared: true,
          split: false,
        },
        rangeSelector: {
          enabled: true,
          inputEnabled: false,
          y: -42,
          x: -35,
          labelStyle: {
            display: "none",
          },
          buttonPosition: {
            align: "right",
          },
          buttons: [
            {
              type: "null",
              text: "Line",
              title: "Line",
              events: {
                click: this.setLineChart,
              },
            },
            {
              type: "null",
              text: "Bar",
              title: "Bar",
              events: {
                click: this.setBarChart,
              },
            },
          ],
        },
        xAxis: {
          categories: [],
        },
        yAxis: [
          {
            title: {
              text: null,
            },
            labels: {
              format: "{value}",
            },
          },
          {
            title: {
              text: null,
            },
            labels: {
              format: "{value}",
            },
            opposite: true,
            min: 0,
          },
        ],
        series: [],
        plotOptions: {
          series: {
            marker: {
              symbol: "circle",
            },
          },
        },
      },
    };
  },
  methods: {
    setData(power, fps, title, xAxis, series) {
      this.chartOptions.yAxis[0].title.text = power ? "Power (mW)" : "FPS";
      this.chartOptions.yAxis[1].title.text = power && fps ? "FPS" : null;

      this.chartOptions.xAxis.categories = xAxis;
      this.chartOptions.title.text = title;
      this.chartOptions.series = series;
    },
    showTitleModal() {
      this.title = this.chartOptions.title.text;
      this.$bvModal.show("titleModal");
    },
    editTitle() {
      this.chartOptions.title.text = this.title;
    },
    setLineChart() {
      this.chartOptions.chart.type = "line";
    },
    setBarChart() {
      this.chartOptions.chart.type = "column";
    },
  },
};
</script>

<style>
.highcharts-title:hover {
  font-weight: bold;
  cursor: pointer;
}
</style>
