<template>
  <div id="wrapper">
    <table class="raw-table" cellpadding="0" cellspacing="0" border="0">
      <thead>
        <tr>
          <th v-for="(key, index) in Object.keys(get_columns)" :key="index" :colspan="columns[key].length"
            :rowspan="columns[key].length == 1 ? 2 : 1">
            {{ key }}</th>
        </tr>
        <tr>
          <th v-for="(column, index) in get_sub_columns" :key="index">{{ column }}</th>
        </tr>
      </thead>
    </table>

    <RecycleScroller :items="get_items" :item-size="19" class="scroller">
      <div slot-scope="props" class="recycle-scroller-table">
        <tr class="item">
          <td v-for="(item, index) in props.item.data" :key="`td-${index}`" >
            {{ item }}
          </td>
        </tr>
      </div>
    </RecycleScroller>
  </div>
</template>

<script>
import { RecycleScroller } from "vue-virtual-scroller";
import "vue-virtual-scroller/dist/vue-virtual-scroller.css";

export default {
  components: {
    RecycleScroller,
  },
  props: {
    series: Object,
    fileName: String,
  },
  computed: {
    get_columns() {
      if (!this.series) {
        return columns;
      }
      this.columns["index"] = ["index"];
      this.columns["xValue"] = ["xValue"];
      // Columns
      for (let key in this.series) {
        if (key == "raw") continue;
        this.columns[key] = []
        for (let i = 0; i < this.series[key].length; i++) {
          let sub_name = this.series[key][i]["name"];
          if (sub_name) {
            this.columns[key].push(sub_name);
          }
        }
      }
      return this.columns;
    },
    get_sub_columns() {
      let arr = [];
      for (let key in this.columns) {
        if (this.columns[key].length < 2) continue;
        for (let index in this.columns[key]) {
          arr.push(this.columns[key][index]);
        }
      }
      return arr;
    },
    get_items() { 
      if (!this.series) {
        return this.items;
      }
      const len = this.series["raw"][1]["data"].length;
      for (let i = 0; i < len; i++) {
        // var item = [i, this.series["raw"][0]["data"][i]];
        var item = [i, 100];
        for (let key in this.columns) {
          if (key == "raw") continue;
          for (let index in this.series[key]) {
            let sub_name = this.series[key][index]["name"]
            if (sub_name) {
              let data = this.series[key][index]["data"][i];
              if (data % 1 == 0) item.push(data);
              else item.push(data.toFixed(1))
            }
          }
        }
        this.items.push({
          id: `log-${i}`,
          data: item,
        });;
      }
      return this.items;
    },
  },
  data() {
    return {
      columns: {},
      items: [],
    };
  },
  created() {
  },
  mounted() {
  },
  methods: {
    downloadCsv() {
      const bom = "\uFEFF";
      const names = this.fileName.split("\\");
      const fileName = names[names.length - 1].replace(".log", ".csv");
      const titles = []

      for (let key in this.columns){
        for (let value of this.columns[key]){
          if (key == value) {
            titles.push(key);
          }else {
            titles.push(`${key}_${value}`);
          }
        }
      }
      titles.push("\r\n")

      const csvString =
        bom + titles + this.items.map(x => x.data.join(",")).join("\r\n");

      // IE 10, 11, Edge Run
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        let blob = new Blob([decodeURIComponent(csvString)], {
          type: "text/csv;charset=utf8",
        });

        window.navigator.msSaveOrOpenBlob(blob, fileName);
      } else if (window.Blob && window.URL) {
        // HTML5 Blob
        let blob = new Blob([csvString], {
          type: "text/csv;charset=utf8",
        });
        let csvUrl = URL.createObjectURL(blob);
        let a = document.createElement("a");
        a.setAttribute("style", "display:none");
        a.setAttribute("href", csvUrl);
        a.setAttribute("download", fileName);
        document.body.appendChild(a);

        a.click();
        a.remove();
      }
    },
  },
};
</script>

<style scoped>
#wrapper {
  height: 700px;
  width: 6110px;
}

.scroller {
  height: 642px;
}

.raw-table {
  text-align: center;
  font-size: 12px;
}

.raw-table th,
.raw-table td {
  border: 1px solid rgba(0, 0, 0, 0.596);
  width: 60px;
  height: 20px;
}

.raw-table th {
  position: sticky;
  background-color: rgb(217, 217, 217);
}

.event-column {
  width: 270px;
}

.recycle-scroller-table {
  border-collapse: collapse;
  display: table;
}

td {
  width: 60px;
  text-align: right;
  font-size: 12px;
  border: 1px solid rgba(0, 0, 0, 0.596);
  /* border-right: 1px solid black;
    border-bottom: 1px solid black; */
  padding-right: 0.3rem;
}

</style>
