<template>
  <div>
    <div v-show="profileVisible" class="sub-title-group">
      <span class="sub-title">Profiling {{ title }}</span>
    </div>

    <div v-show="gamebenchVisible">
      <profile-graph
        title="Gamebench FPS"
        :series="gamebenchFpsSeries"
        :tickInterval="20"
        :pointInterval="1000"></profile-graph>
    </div>

    <div v-show="quickperfFpsVisible">
      <profile-graph
        title="Quickperf FPS"
        :series="quickperfFpsSeries"
        :tickInterval="20"
        :pointInterval="1000"></profile-graph>
    </div>

    <div
      v-show="quickperfTempVisible"
      v-for="(series, index) in seriesList"
      :key="index">
      <profile-graph
        :title="series.name"
        :series="series.series"
        :tickInterval="series.tickInterval"></profile-graph>
    </div>

    <!-- <div v-if="testitem_id">
            <power-graph :testitem="testitem_id"></power-graph>
        </div> -->
  </div>
</template>

<script>
import ProfileGraph from "./ProfileGraph.vue";

export default {
  components: {
    ProfileGraph,
  },
  props: {
    tester: {
      type: String,
    },
    title: {
      type: String,
    },
    gamebench_id: {
      type: String,
    },
    quickperf_id: {
      type: String,
    },
    testitem_id: {},
  },
  computed: {
    profileVisible() {
      return (
        this.gamebenchVisible ||
        this.quickperfFpsVisible ||
        this.quickperfTempVisible
      );
    },
    gamebenchVisible() {
      return this.gamebenchFpsSeries.length != 0;
    },
    quickperfFpsVisible() {
      return this.quickperfFpsSeries.length != 0;
    },
    quickperfTempVisible() {
      return this.seriesList.filter(x => x.series.length != 0).length > 0;
    },
  },
  data() {
    return {
      seriesList: [],
      gamebenchFpsSeries: [],
      quickperfFpsSeries: [],
    };
  },
  created() {
    const auth = {
      username: "younjae.lee@samsung.com",
      password: "5dc2ba0a4335378b3b4ba69ad6db0233",
    };

    const qroadAuth = {
      username: "hs4926.kim@samsung.com",
      password: "7d797114b56663d69564310f4d30c988",
    };

    if (this.gamebench_id) {
      this.$http
        .get(`https://gamebench.sgpi.io/v1/sessions/${this.gamebench_id}/fps`, {
          auth: this.tester == "큐로드" ? qroadAuth : auth,
        })
        .then(res => {
          this.gamebenchFpsSeries.push({
            name: "FPS",
            data: res.data.samples.map(x => x.fpsValue),
          });
        })
        .catch(err => {
          console.log(err);
        });
    }

    if (this.quickperf_id) {
      this.$http
        .get(`/quickperf/json/fps_profile.aspx?score=${this.quickperf_id}`)
        .then(res => {
          this.quickperfFpsSeries.push({
            name: "FPS",
            data: res.data[0].profiling["1"],
          });
        })
        .catch(err => {
          console.log(err);
        });

      this.$http
        .get(`/quickperf/json/temp_profile.aspx?score=${this.quickperf_id}`)
        .then(res => {
          const keys = Object.keys(res.data);

          for (let i = 1; i <= 6; i++) {
            var filteredKeys = keys.filter(x => x.startsWith(`0${i}`));

            this.seriesList.push({
              name: "",
              series: [],
            });

            for (const key of filteredKeys) {
              const title = key.split("-")[1].split("_");

              var tickInterval = 500;

              if (title[0].startsWith("temp")) {
                tickInterval = 10;
              } else if (title[0].startsWith("gpu")) {
                tickInterval = 50;
              }

              this.seriesList[i - 1].name = title[0];
              this.seriesList[i - 1].tickInterval = tickInterval;
              this.seriesList[i - 1].series.push({
                name: title[1],
                data: res.data[key].data,
              });
            }
          }
        })
        .catch(err => {
          console.log("temp error");
          console.log(err.message);
        });
    }
  },
};
</script>
