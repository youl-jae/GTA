<template>
  <div>
    <vue-instant-loading-spinner ref="Spinner" color="#205081" />
    <score-slider ref="refscoreSlider" class="score-slider-margin" />

    <b-button class="mb-2" @click="toggleView('raw')">
      <font-awesome-icon
        :icon="visibleRaw ? 'angle-up' : 'angle-down'"
        class="mr-1" />
      {{ visibleRaw ? "Hide Raw Log" : "Show Raw Log" }}
    </b-button>

    <div class="fold-box" @click="expandIfHidden('raw')">
      <transition name="fade">
        <div
          v-show="visibleRaw"
          class="ai-log"
          v-html="renderedMarkdownRaw"></div>
      </transition>

      <div v-if="!visibleRaw" class="collapsed-hint text-muted">
        <i class="fa-solid fa-ellipsis"></i>
        <span> Raw log is hidden. Click to expand. </span>
      </div>
    </div>

    <b-button class="mb-2" @click="toggleView('result')">
      <font-awesome-icon
        :icon="visibleResult ? 'angle-up' : 'angle-down'"
        class="mr-1" />
      {{ visibleResult ? "Hide Summary" : "Show Summary" }}
    </b-button>

    <div class="fold-box" @click="expandIfHidden('result')">
      <transition name="fade">
        <div
          v-show="visibleResult"
          class="ai-log"
          v-html="renderedMarkdownResult"></div>
      </transition>

      <div v-if="!visibleResult" class="collapsed-hint text-muted">
        <i class="fa-solid fa-ellipsis"></i>
        <span> Summary is hidden. Click to expand. </span>
      </div>
    </div>
  </div>
</template>

<script>
import ScoreSlider from "@/components/module/ScoreSlider.vue";
import MarkdownIt from "markdown-it";
import VueInstantLoadingSpinner from "vue-instant-loading-spinner";

export default {
  components: {
    VueInstantLoadingSpinner,
    ScoreSlider,
  },
  props: {
    comparisonId: {
      type: Array,
      required: true,
    },
    patchesInfo: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      md: new MarkdownIt(),
      renderedMarkdownRaw: "",
      renderedMarkdownResult: "",
      visibleRaw: false,
      visibleResult: false,
      bufferRaw: "",
      bufferResult: "",
    };
  },
  mounted() {
    if (this.comparisonId?.length > 0) this.run();
  },
  watch: {
    comparisonId() {
      this.run();
    },
  },
  methods: {
    toggleView(target) {
      if (target === "raw") {
        this.visibleRaw = !this.visibleRaw;
      } else if (target === "result") {
        this.visibleResult = !this.visibleResult;
      }
    },
    expandIfHidden(target) {
      if (target === "raw") {
        if (!this.visibleRaw) this.visibleRaw = true;
      } else if (target === "result") {
        if (!this.visibleResult) this.visibleResult = true;
      }
    },
    collapseIfVisible(target) {
      if (target === "raw") {
        if (this.visibleRaw) this.visibleRaw = false;
      } else if (target === "result") {
        if (this.visibleResult) this.visibleResult = false;
      }
    },
    async run() {
      try {
        const res_patchesInfo = await fetch("/api/aiagent/save", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: this.patchesInfo }),
        });

        const savePatchesInfo = await res_patchesInfo.json();
        let url = `/api/aiagent/compare?id=${this.comparisonId.join(",")}`;
        if (savePatchesInfo?.success && savePatchesInfo.filename) {
          url += `&patchesInfoFilename=${encodeURIComponent(
            savePatchesInfo.filename,
          )}`;
        }

        const res = await fetch(url);
        const reader = res.body.getReader();
        const decoder = new TextDecoder("utf-8");

        this.renderedMarkdownRaw = "";
        this.renderedMarkdownResult = "";
        this.expandIfHidden("raw");

        this.bufferRaw = "";
        this.bufferResult = "";
        let isSummaryStarted = false;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);

          if (chunk.includes("Finalizing(3/3)...")) {
            const [before, after] = chunk.split("Finalizing(3/3)...");

            this.bufferRaw += before + "Finalizing(3/3)...\n";
            this.renderedMarkdownRaw = this.md.render(this.bufferRaw);
            if (after && after.trim()) {
              this.bufferResult += after;
              this.renderedMarkdownResult = this.md.render(this.bufferResult);
              this.collapseIfVisible("raw");
              this.expandIfHidden("result");
            }
            isSummaryStarted = true;
          } else if (!isSummaryStarted) {
            this.bufferRaw += chunk;
            this.renderedMarkdownRaw = this.md.render(this.bufferRaw);
          } else {
            this.bufferResult += chunk;
            this.renderedMarkdownResult = this.md.render(this.bufferResult);
            this.collapseIfVisible("raw");
            this.expandIfHidden("result");
          }
        }
      } catch (err) {
        this.renderedMarkdownResult = this.md.render(
          "❌ 오류 발생: " + err.message,
        );
        this.visibleRaw = false;
        this.visibleResult = true;
      }
    },
    applyLoadedData() {
      this.renderedMarkdownRaw = this.md.render(this.bufferRaw || "");
      this.renderedMarkdownResult = this.md.render(this.bufferResult || "");

      this.collapseIfVisible("raw");
      this.expandIfHidden("result");
    },
  },
};
</script>

<style scoped>
.score-slider-margin {
  margin-top: 15px;
  margin-bottom: 15px;
}

.ai-log {
  font-family: monospace;
  font-size: 0.9rem;
  padding: 0.75rem;
  border: 1px solid lightgray;
  border-radius: 8px;
  max-height: 85vh;
  overflow-y: auto;
  scroll-behavior: smooth;
  font-family: "Malgun Gothic", "맑은 고딕", Arial, sans-serif;
}

.ai-log code {
  background: rgba(255, 255, 255, 0.1);
  padding: 2px 4px;
  border-radius: 4px;
}

.fold-box {
  border: 1px dashed #ccc;
  border-radius: 6px;
  padding: 6px;
  background: #fdfdfd;
  cursor: pointer;
  transition: background 0.2s ease;
  margin-bottom: 15px;
}

.fold-box:hover {
  background: #f8f9fa;
}

.collapsed-hint {
  text-align: center;
  padding: 10px;
  font-style: italic;
  font-size: 0.85rem;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>
