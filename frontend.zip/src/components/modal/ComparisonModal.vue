<template>
  <b-modal id="comparisonModal" title="Save" @ok="okComparisonModal">
    <div v-show="isEdit == false" class="form-group">
      <label class="col-form-label">Comparison</label>
      <b-form-select
        class="form-control"
        v-model="comparison"
        :options="comparisons"></b-form-select>
    </div>
    <div v-show="isEdit || comparison == 0" class="form-group">
      <label class="col-form-label">Title</label>
      <input class="form-control" type="text" v-model="title" />
    </div>
    <div v-show="isEdit || comparison == 0" class="form-group">
      <label class="col-form-label">Note</label>
      <textarea
        class="form-control"
        type="text"
        rows="10"
        v-model="note"></textarea>
    </div>
  </b-modal>
</template>

<script>
export default {
  name: "ComparisonModal",
  props: {
    type: String,
  },
  data() {
    return {
      isEdit: false,
      title: "",
      note: "",
      comparison: 0,
      comparisons: [
        {
          value: 0,
          text: "== New ==",
        },
      ],
      testIdList: [],
      patchesInfo: "",
      bufferRaw: "",
      bufferResult: "",
    };
  },
  created() {
    this.getComparisons();
  },
  methods: {
    reset() {
      this.title = "";
      this.note = "";
      this.comparison = 0;
    },
    setValue(comparisonId, title, note) {
      this.isEdit = true;
      this.comparison = comparisonId;
      this.title = title;
      this.note = note;
    },
    getComparisons() {
      this.comparison = 0;
      this.comparisons = [
        {
          value: 0,
          text: "== New ==",
        },
      ];

      this.$http.get(`/api/comparisons?type=${this.type}`).then(res => {
        for (const comparison of res.data) {
          this.comparisons.push({
            value: comparison.id,
            text: comparison.title,
          });
        }
      });
    },
    okComparisonModal(event) {
      event.preventDefault();

      if (this.isEdit) {
        this.editComparison();
      } else {
        this.saveComparison();
      }
    },
    editComparison() {
      if (this.title == "") {
        alert("Title is empty !!");
      } else {
        var body = {
          title: this.title,
          note: this.note,
        };

        this.$http
          .put(`/api/comparisons/${this.comparison}`, body)
          .then(() => {
            this.$nextTick(() => this.$bvModal.hide("comparisonModal"));
            this.$emit("editComparison");
          })
          .catch(err => {
            alert(err.message);
          });
      }
    },
    saveComparison() {
      if (this.comparison == 0) {
        // new
        if (this.title == "") {
          alert("Title is empty !!");
        } else {
          var body = {
            title: this.title,
            note: this.note,
            tests: this.testIdList,
          };

          this.$http
            .post(`/api/comparisons`, body)
            .then(res => {
              this.$nextTick(() => this.$bvModal.hide("comparisonModal"));
              this.$emit("updateAiagent", res.data.insertId);
              this.$router.push({
                name: "TestScoreComparisonById",
                params: {
                  id: res.data.insertId,
                },
              });
            })
            .catch(err => {
              alert(err);
            });
        }
      } else {
        this.$http
          .put(
            `/api/comparisons/${this.comparison}/${this.testIdList.join(",")}`,
          )
          .then(() => {
            this.$nextTick(() => this.$bvModal.hide("comparisonModal"));

            this.$router.push({
              name: "TestScoreComparisonById",
              params: {
                id: this.comparison,
              },
            });
          })
          .catch(err => {
            alert(err);
          });
      }
    },
  },
};
</script>
