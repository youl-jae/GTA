<template>
  <b-modal id="editEtcModal" title="Edit ETC" size="lg" @ok="editEtc">
    <div class="form-group">
      <textarea class="form-control" rows="10" v-model="etc"></textarea>
    </div>
  </b-modal>
</template>

<script>
export default {
  name: "EditEtcModal",
  data() {
    return {
      etc: "",
    };
  },
  methods: {
    editEtc(e) {
      this.$emit("editEtc", e, this.etc);
    },
  },
};
</script>
