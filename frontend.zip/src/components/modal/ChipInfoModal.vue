<template>
  <b-modal id="chipInfoModal" size="xl" title="Chip Info">
    <div id="chip-info">
      <div class="sub-title-group">
        <h6>{{ chipInfo }}</h6>
        <div class="sub-title-btn-group">
          <b-button
            id="copy-btn"
            variant="outline-secondary"
            size="sm"
            v-b-tooltip.hover.bottom
            title="copy"
            @click="copyToClipboard">
            <font-awesome-icon icon="copy" />
          </b-button>
        </div>
      </div>
      <ve-table
        style="margin-bottom: 1rem"
        :max-height="705"
        :columns="columns"
        :border-x="true"
        :border-y="true"
        :table-data="tableData" />
      <div class="sub-title-group" v-show="voltageData.length">
        <h6>Voltage Info</h6>
      </div>
      <div
        class="row"
        style="justify-content: space-between; margin-left: 0rem">
        <ve-table
          v-for="(data, index) in voltageData"
          :key="index"
          style="width: 200px; margin-right: 1rem; margin-bottom: 1rem"
          :columns="data.columns"
          :table-data="data.tableData"
          :border-y="true"></ve-table>
      </div>
    </div>
  </b-modal>
</template>

<script>
export default {
  name: "ChipInfoModal",
  data() {
    return {
      chipId: null,
      chip: {
        name: null,
      },
      columns: [
        {
          field: "chip_id",
          key: "chip_id",
          title: "Chip ID",
          align: "center",
          width: "10%",
        },
        {
          field: "asv_groups",
          key: "asv_groups",
          title: "ASV Group",
          align: "center",
          children: [],
        },
        {
          field: "ids_values",
          key: "ids_values",
          title: "IDS Value",
          align: "center",
          children: [],
        },
      ],
      tableData: [],
      voltageData: [],
    };
  },
  computed: {
    chipInfo() {
      let revisionNumber = "";

      if (this.chip.revision_number) {
        revisionNumber = `, EVT${this.chip.revision_number}`;
      }

      return `${this.chip.name} (${this.chip.project}${revisionNumber})`;
    },
  },
  methods: {
    async init(chipId) {
      this.chipId = chipId;

      const chipResult = await this.$http.get(`/api/chips/${this.chipId}`);

      this.chip = chipResult.data;
      this.tableData = [chipResult.data];

      const ipResult = await this.$http.get(
        `/api/projects/${this.chip.project_id}/ip`,
      );

      const asvCol = this.columns.filter(x => x.field === "asv_groups")[0];
      const idsCol = this.columns.filter(x => x.field === "ids_values")[0];

      asvCol.children = [];
      idsCol.children = [];

      for (const ip of ipResult.data) {
        if (ip.name.includes("CP")) {
          continue;
        }

        asvCol.children.push({
          field: `asv_${ip.name}`,
          key: `asv_${ip.name}`,
          title: ip.name,
        });

        idsCol.children.push({
          field: `ids_${ip.name}`,
          key: `ids_${ip.name}`,
          title: ip.name,
        });
      }

      this.columns.push();

      this.voltageData = [];

      for (const key of Object.keys(this.chip.voltage_info)) {
        if (!this.chip.voltage_info[key]) {
          continue;
        }

        this.voltageData.push({
          columns: [
            {
              field: key,
              key: key,
              title: key,
              children: [
                {
                  field: "frequency",
                  key: "frequency",
                  title: "Freq(KHz)",
                },
                {
                  field: "voltage",
                  key: "voltage",
                  title: "Voltage(uV)",
                },
              ],
            },
          ],
          tableData: JSON.parse(this.chip.voltage_info[key]).map(x => ({
            frequency: x[0],
            voltage: x[1],
          })),
        });
      }
    },
    copyToClipboard() {
      var selection = window.getSelection();

      const copyBtn = document.getElementById("copy-btn");
      copyBtn.style.display = "none";

      const tBody = document.getElementsByClassName("ve-table-body");
      for (const body of tBody) {
        body.children[0].style.display = "none";
      }

      const chipInfo = document.getElementById("chip-info");
      const range = document.createRange();

      range.selectNodeContents(chipInfo);
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand("copy");
      selection.removeAllRanges();

      copyBtn.style.display = "";
      for (const body of tBody) {
        body.children[0].style.display = "";
      }
    },
  },
};
</script>
