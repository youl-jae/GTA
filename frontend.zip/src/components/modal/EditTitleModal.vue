<template>
  <b-modal id="editTitleModal" title="Title" @ok="editTitle">
    <div class="form-group">
      <input class="form-control" type="text" v-model="title" />
    </div>
  </b-modal>
</template>

<script>
export default {
  name: "EditTitleModal",
  data() {
    return {
      title: "",
    };
  },
  methods: {
    editTitle(e) {
      this.$emit("editTitle", e, this.title);
    },
  },
};
</script>
