<template>
  <b-modal
    id="board-info-modal"
    :title="board.name == null ? 'Board Info' : board.name"
    ok-only>
    <div class="board-group">
      <h6>ID:</h6>
      <span>{{ board.serial_number }}</span>
    </div>
    <div class="board-group">
      <h6>Board Type:</h6>
      <span
        >{{ board.type }}
        {{ board.is_current_board ? "Current board" : "" }}</span
      >
    </div>
    <div>
      <h6>ASV Info</h6>
      <span style="white-space: pre">
        {{ board.asv_info }}
      </span>
    </div>
    <div>
      <h6>ETC</h6>
      <span style="white-space: pre">
        {{ board.etc }}
      </span>
    </div>
  </b-modal>
</template>

<script>
export default {
  name: "BoardInfoModal",
  props: {
    boardId: Number,
  },
  data() {
    return {
      board: {
        type: null,
        name: null,
        serial_number: null,
        asv_info: null,
        is_current_board: null,
        etc: null,
      },
    };
  },
  methods: {
    getBoardInfo() {
      if (this.id) {
        return;
      }

      this.$http
        .get(`/api/boards/${this.boardId}`)
        .then(res => {
          this.board = res.data;
        })
        .catch(err => {
          alert(err);
        });
    },
  },
};
</script>

<style scoped>
.board-group {
  display: flex;
  justify-content: flex-start;
}

.board-group span {
  margin-left: 10px;
}
</style>
