<template>
  <b-modal
    id="editTestIdModal"
    title="Move TestItem"
    size="md"
    @ok="confirmTestId">
    <div class="form-group">
      <label for="testIdInput">Test ID</label>
      <input
        id="testIdInput"
        type="number"
        class="form-control"
        v-model="testId"
        placeholder="Enter test_id" />
    </div>
  </b-modal>
</template>

<script>
export default {
  name: "editTestIdModal",
  data() {
    return {
      testId: "",
    };
  },
  methods: {
    confirmTestId(e) {
      this.$emit("confirmTestId", e, this.testId);
    },
    open(testId = "") {
      this.testId = testId;
      this.$bvModal.show("editTestIdModal");
    },
  },
};
</script>
