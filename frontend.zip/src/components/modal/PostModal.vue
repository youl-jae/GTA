<template>
  <b-modal
    id="post-modal"
    size="xl"
    title="New Post"
    hide-header-close
    no-close-on-esc
    no-close-on-backdrop
    @ok="save"
    @cancel="cancel">
    <div class="row header">
      <div style="width: 15%; padding-right: 0.5rem">
        <b-form-select
          v-model="selectedBenchmark"
          :options="benchmarks"></b-form-select>
      </div>
      <div style="width: 85%">
        <b-form-input placeholder="Title" v-model="title"></b-form-input>
      </div>
    </div>
    <ckeditor ref="editor" v-model="content" :config="editorConfig"></ckeditor>
  </b-modal>
</template>

<script>
import CKEditor from "ckeditor4-vue";

export default {
  components: {
    ckeditor: CKEditor.component,
  },
  props: {
    benchmark: String,
  },
  data() {
    return {
      benchmarks: [
        {
          value: "GFXBench",
          text: "GFXBench",
        },
        {
          value: "3DMark",
          text: "3DMark",
        },
        {
          value: "Antutu",
          text: "Antutu",
        },
        {
          value: "Basemark",
          text: "Basemark",
        },
      ],
      selectedBenchmark: "",
      editorConfig: {
        height: 540,
        extraPlugins:
          "justify, copyformatting, font, tableresize, autolink, indentblock",
        removeButtons: "Styles,About,Font",
        contentsCss: "body pre {white-space:break-spaces;}",
      },
      id: "",
      title: "",
      content: "",
      projects: [],
      projectId: "",
    };
  },
  methods: {
    reset() {
      this.selectedBenchmark = this.benchmark;
      this.id = "";
      this.title = "";
      this.content = "";
    },
    setData(postId) {
      this.$http
        .get(`/api/bmrelease/${postId}`)
        .then(res => {
          const post = res.data;

          this.id = post.id;
          this.title = post.title;
          this.content = post.content;
          this.selectedBenchmark = post.benchmark;
        })
        .catch(err => {
          console.log(err);
        });
    },
    save(event) {
      event.preventDefault();

      const body = {
        title: this.title,
        content: this.content,
        benchmark: this.selectedBenchmark,
        updated_at: this.getCurrentDateTime(),
      };

      if (this.id) {
        body.id = this.id;
        this.$emit("edit-post", body);
      } else {
        this.$emit("add-post", body);
      }
    },
    cancel(event) {
      if (
        confirm(
          "If you navigate away from this page without first saving your data, the changes will be lost.",
        ) == false
      ) {
        event.preventDefault();
      }
    },
    getCurrentDateTime() {
      var today = new Date();
      today.setHours(today.getHours() + 9);
      return today.toISOString().replace("T", " ").substring(0, 19);
    },
  },
};
</script>

<style scoped>
.header {
  margin: 0rem 0rem;
  margin-bottom: 0.5rem;
}

.footer-btn {
  margin-top: 0.5rem;
  display: flex;
  flex-flow: row nowrap;
  justify-content: flex-end;
}
</style>
