<template>
  <b-modal id="add-assignee-modal" title="Assignee" @ok="addAssignee">
    <b-form-group label="ID" label-for="input-id">
      <b-form-input v-model="id"></b-form-input>
    </b-form-group>
    <b-form-group label="Name" label-for="input-name">
      <b-form-input v-model="name"></b-form-input>
    </b-form-group>
  </b-modal>
</template>

<script>
export default {
  name: "AddAssigneeModal",
  data() {
    return {
      id: "",
      name: "",
    };
  },
  methods: {
    reset() {
      this.id = "";
      this.name = "";
    },
    addAssignee(event) {
      event.preventDefault();

      if (this.id && this.name) {
        var body = {
          id: this.id,
          name: this.name,
        };

        this.$http
          .post("/api/assignees", body)
          .then(() => {
            this.$nextTick(() => this.$bvModal.hide("add-assignee-modal"));
            window.location.reload();
          })
          .catch(err => {
            if (err.response.status == 400) {
              alert("ID already exists.");
            }
          });
      } else {
        alert("Fill in the blanks.");
      }
    },
  },
};
</script>
