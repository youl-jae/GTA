<template>
  <b-modal id="add-chip" title="Chip" @ok="addChip">
    <b-form-group label="Project *" label-size="sm">
      <b-form-select
        size="sm"
        :options="projects"
        v-model="projectId"></b-form-select>
    </b-form-group>
    <b-form-group label="Name (Do not include project name) *" label-size="sm">
      <b-form-input size="sm" v-model="name"></b-form-input>
    </b-form-group>
    <b-form-group label="Chip ID (0x00000000000) *" label-size="sm">
      <b-form-input size="sm" v-model="chipId"></b-form-input>
    </b-form-group>
    <b-form-group label="Board Serial Number" label-size="sm">
      <b-form-input size="sm" v-model="serialNumber"></b-form-input>
    </b-form-group>
    <b-form-group label="Revision Number *" label-size="sm">
      <b-input-group prepend="EVT" size="sm">
        <b-form-input
          size="sm"
          v-model="revisionNumber"
          type="number"></b-form-input>
      </b-input-group>
    </b-form-group>
    <b-form-group :label="`ASV Group (${ipList})`" label-size="sm">
      <b-form-input
        size="sm"
        v-model="asvGroup"
        placeholder="separate with a space"
        :disabled="ipCount === 0"></b-form-input>
    </b-form-group>
    <b-form-group :label="`IDS Value (${ipList})`" label-size="sm">
      <b-form-input
        size="sm"
        v-model="idsValue"
        placeholder="separate with a space"
        :disabled="ipCount === 0"></b-form-input>
    </b-form-group>
    <b-form-group label="Voltage Info" label-size="sm">
      <b-textarea
        size="sm"
        v-model="voltageInfo"
        rows="5"
        :placeholder="voltageInfoPlaceHolder"
        :disabled="ipCount === 0"></b-textarea>
    </b-form-group>
  </b-modal>
</template>

<script>
export default {
  name: "AddChipModal",
  data() {
    return {
      projects: [],
      projectId: "",
      name: "",
      chipId: "",
      serialNumber: "",
      revisionNumber: "",
      asvGroup: "",
      idsValue: "",
      voltageInfo: "",
      voltageInfoPlaceHolder: "IP\nfreq\t\tvoltage\nfreq\t\tvoltage\n...",
      ipDict: {
        BIG: "CL2",
        MIDH: "CL1H",
        MIDL: "CL1L",
        MID: "CL1",
        LIT: "CL0",
        INTSCI: "SCI",
      },
    };
  },
  computed: {
    ipList() {
      const project = this.projects.find(x => x.value === this.projectId);
      return project?.ipList
        .filter(x => !x.name.includes("CP"))
        .map(x => x.name)
        .join(" ");
    },
    ipCount() {
      const project = this.projects.find(x => x.value === this.projectId);
      return project?.ipList.length;
    },
  },
  created() {
    this.$http.get(`/api/projects/ip`).then(res => {
      this.projects = res.data.map(x => ({
        value: x.id,
        text: x.name,
        default: x.default,
        ipList: x.ipList,
      }));
      //this.projectId = this.projects.find(x => x.default === 1).id;
      this.projectId = this.projects.find(x => x.default === 1)?.value;
    });
  },
  methods: {
    reset() {
      this.projectId = this.projects.filter(x => x.default === 1)[0]?.value;
      this.name = "";
      this.chipId = "";
      this.serialNumber = "";
      this.revisionNumber = "";
      this.asvGroup = "";
      this.idsValue = "";
      this.voltageInfo = "";
    },
    addChip(event) {
      event.preventDefault();

      if (!this.name || !this.chipId || !this.revisionNumber) {
        alert("Fill in the blanks.");
        return;
      }

      var chipInfo = [];

      if (this.asvGroup || this.idsValue || this.voltageInfo) {
        const ipList = this.projects.find(
          x => x.value === this.projectId,
        ).ipList;
        const asvList = this.asvGroup.split(/\s+/);
        const idsList = this.idsValue.split(/\s+/);

        for (let i = 0; i < ipList.length; i++) {
          chipInfo.push({
            ipId: ipList[i].id,
            ipName: ipList[i].name,
            asvGroup: asvList[i] ? asvList[i] : null,
            idsValue: idsList[i] ? idsList[i] : null,
            voltageList: [],
          });
        }

        let index = "";

        for (var line of this.voltageInfo.split("\n")) {
          if (!line) {
            continue;
          }

          line = line.trim();

          if (line.includes("\t") === false) {
            index = chipInfo.findIndex(x => x.ipName === line);

            if (index == -1) {
              index = chipInfo.findIndex(x => x.ipName === this.ipDict[line]);
            }
          } else if (line.startsWith("F") === false && index !== -1) {
            chipInfo[index].voltageList.push(
              line.split("\t").map(x => Number(x)),
            );
          }
        }
      }

      var body = {
        projectId: this.projectId,
        name: this.name,
        chipId: this.chipId,
        serialNumber: this.serialNumber,
        revisionNumber: this.revisionNumber,
        chipInfo: chipInfo,
      };

      this.$http
        .post(`/api/chips`, body)
        .then(() => {
          this.$nextTick(() => this.$bvModal.hide("add-chip"));
          this.$emit("getData");
        })
        .catch(err => {
          console.log(err.response?.data);

          if (err.response?.status == 400) {
            alert("Chip ID already exists.");
          } else {
            alert(
              err.response?.data?.sqlMessage ||
              err.response?.data?.message ||
              err.message
            );
          }
        });
    },
  },
};
</script>
