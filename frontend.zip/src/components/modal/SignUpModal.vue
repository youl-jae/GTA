<template>
  <b-modal id="signUpModal" title="Sign Up" @ok="signUp">
    <div>
      <b-form-group label="Name">
        <b-form-input type="text" v-model="name"></b-form-input>
      </b-form-group>
      <b-form-group label="Knox ID">
        <b-form-input type="text" v-model="knoxId"></b-form-input>
      </b-form-group>
      <b-form-group label="Password">
        <b-form-input type="password" v-model="password"></b-form-input>
      </b-form-group>
      <b-form-group label="Password Confirm">
        <b-form-input type="password" v-model="passwordConfirm"></b-form-input>
      </b-form-group>
    </div>
  </b-modal>
</template>

<script>
export default {
  name: "SignUpModal",
  data() {
    return {
      name: "",
      knoxId: "",
      password: "",
      passwordConfirm: "",
    };
  },
  methods: {
    init() {
      this.name = "";
      this.knoxId = "";
      this.password = "";
      this.passwordConfirm = "";
    },
    signUp(e) {
      e.preventDefault();

      if (
        !this.name ||
        !this.knoxId ||
        !this.password ||
        !this.passwordConfirm
      ) {
        alert("Fill in the blank!");
        return;
      }

      if (this.password !== this.passwordConfirm) {
        alert("Password doesn't match");
        return;
      }

      const data = {
        name: this.name,
        knoxId: this.knoxId,
        password: this.password,
      };

      this.$http
        .post(`/api/users`, data)
        .then(() => {
          alert("Successful signup!");
          this.$nextTick(() => this.$bvModal.hide("signUpModal"));
        })
        .catch(err => {
          alert(err.response.data);
        });
    },
  },
};
</script>
