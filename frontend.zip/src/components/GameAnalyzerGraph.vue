<template>
  <div>
    <highcharts :options="chartOptions"></highcharts>
  </div>
</template>

<script>
import { Chart } from "highcharts-vue";
import Highcharts from "highcharts";
import highchartsMore from "highcharts/highcharts-more";

highchartsMore(Highcharts);

export default {
  props: {
    title: String,
    chartType: String,
    xAxis: Object,
    yAxis: Array,
    tooltip: Object,
    legend: Object,
    series: Array,
    plotOptions: Object,
  },
  computed: {},
  components: {
    highcharts: Chart,
  },
  created() {
    // this.chartOptions.caption.text = "chaption_test";
  },
  data() {
    return {
      colors: [
        "#ED7C31",
        "#0070C0",
        "#FF0000",
        "#0070C0",
        "#70AD47",
        "#ED7C31",
      ],
      // chart: null,
      chartOptions: {
        colors: [
          "#ED7C31",
          "#0070C0",
          "#FF0000",
          "#0070C0",
          "#70AD47",
          "#ED7C31",
        ],
        chart: {
          type: this.chartType,
          height: 400,
        },
        title: {
          text: this.title,
        },
        xAxis: this.xAxis,
        yAxis: this.yAxis,
        tooltip: this.tooltip,
        plotOptions: this.plotOptions,
        legend: this.legend,
        series: this.series,
        credits: {
          enabled: false,
        },
      },
    };
  },
  methods: {},
};
</script>
