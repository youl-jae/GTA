<template>
  <b-card no-body>
    <b-card-header header-tag="header" class="header" role="tab">
      <div
        class="header-title"
        :aria-controls="'post-body-' + post.id"
        @click="postLocal.collapse = !postLocal.collapse">
        <b-button size="sm" variant="link" style="margin-right: 1rem"
          ><b-icon
            :icon="post.collapse ? 'chevron-up' : 'chevron-down'"></b-icon
        ></b-button>
        <span>{{ post.title }}</span>
        <span class="date"
          >{{ post.writer }} / {{ post.updated_at.substring(0, 16) }}</span
        >
      </div>
      <b-dropdown text="menu" size="sm" variant="link" right no-caret>
        <template #button-content>
          <b-icon icon="three-dots-vertical"></b-icon>
        </template>
        <b-dropdown-item @click="copyPost">Copy</b-dropdown-item>
        <b-dropdown-item @click="editPost">Edit</b-dropdown-item>
        <b-dropdown-item @click="deletePost">Delete</b-dropdown-item>
      </b-dropdown>
    </b-card-header>
    <b-collapse
      :id="'post-body-' + post.id"
      v-model="postLocal.collapse"
      role="tabpanel">
      <b-card-body>
        <span :id="'post-content-' + post.id" v-html="post.content"></span>
      </b-card-body>
    </b-collapse>
  </b-card>
</template>

<script>
export default {
  name: "PostCard",
  props: {
    post: Object,
  },
  data() {
    return {
      postLocal: this.post,
    };
  },
  methods: {
    copyPost() {
      let body = document.getElementById(`post-content-${this.post.id}`);

      var range = document.createRange();
      range.selectNode(body);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);
      document.execCommand("copy");
      window.getSelection().removeAllRanges();
    },
    editPost() {
      this.$emit("edit-post", this.post.id);
    },
    deletePost() {
      this.$emit("delete-post", this.post);
    },
  },
};
</script>

<style scoped>
.header {
  padding: 0.7rem 1rem;
  display: flex;
  justify-content: space-between;
}

.header-title {
  cursor: pointer;
  display: flex;
  align-items: center;
  width: 98%;
}

.date {
  margin-left: 0.8rem;
  font-size: 12px;
  line-height: 2em;
}

.card {
  border-radius: 0rem;
}
</style>

<style>
.btn-link {
  padding: 0rem;
  color: #6c757d;
}

.btn-link:hover {
  color: #5a6268;
}

.card-body > span > pre {
  white-space: break-spaces;
}
</style>
