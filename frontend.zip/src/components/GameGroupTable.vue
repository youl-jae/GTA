<template>
  <vue-good-table
    ref="table"
    :columns="columns"
    :rows="rows"
    :search-options="{
      enabled: true,
      placeholder: 'Filter this table',
      skipDiacritics: true,
    }"
    :group-options="{
      enabled: true,
      collapsable: true,
    }"
    @on-row-click="onRowClick"
    styleClass="vgt-table condensed">
    <template slot="table-header-row" slot-scope="props">
      <span class="comparison-label">{{ props.row.label }}</span>
      <b-button
        class="comparison-btn"
        variant="outline-secondary"
        size="sm"
        v-b-tooltip.hover.bottom
        title="delete"
        @click="deleteComparison(props.row)"
        ><font-awesome-icon icon="trash-alt"
      /></b-button>
      <b-button
        class="comparison-btn"
        variant="outline-secondary"
        size="sm"
        v-b-tooltip.hover.bottom
        title="comparison"
        @click="compareTests(props.row)"
        ><font-awesome-icon icon="exchange-alt"
      /></b-button>
    </template>
    <template slot="table-row" slot-scope="props">
      <span v-if="props.column.field == 'is_favorite'" class="favorite">{{
        props.row.is_favorite ? "★" : "☆"
      }}</span>
      <span
        v-else-if="props.column.field == 'length' && props.row.length != null"
        >{{ props.row.length }} min</span
      >
      <span
        v-else-if="
          props.column.field == 'average_fps' && props.row.average_fps != null
        "
        >{{ props.row.average_fps.toFixed(1) }}</span
      >
      <span
        v-else-if="
          props.column.field == 'median_fps' && props.row.median_fps != null
        "
        >{{ props.row.median_fps.toFixed(1) }}</span
      >
      <span
        v-else-if="props.column.field == 'power' && props.row.power != null"
        >{{ props.row.power }}</span
      >
      <span v-else-if="props.column.field == 'date'">{{
        props.row.date.substring(0, 10)
      }}</span>
      <div v-else-if="props.column.field == 'log'" class="log-field">
        <span v-show="props.row.amigo_log" class="log-icon amigo-icon">A</span>
        <span v-show="props.row.gamebench_url" class="log-icon gamebench-icon"
          >G</span
        >
        <span v-show="props.row.quickperf_url" class="log-icon quickperf-icon"
          >Q</span
        >
      </div>
      <span v-else>{{ props.row[props.column.field] }}</span>
    </template>
  </vue-good-table>
</template>

<script>
import "vue-good-table/dist/vue-good-table.css";
import { VueGoodTable } from "vue-good-table";

export default {
  name: "GameGroupTable",
  components: {
    VueGoodTable,
  },
  props: {
    rows: Array,
  },
  computed: {
    selectedRows() {
      return this.$refs.table.selectedRows;
    },
  },
  data() {
    return {
      columns: [
        {
          label: "",
          field: "group_title",
          hidden: true,
        },
        {
          label: "",
          field: "is_favorite",
          sortable: false,
          tdClass: "text-center",
          width: "1px",
        },
        {
          label: "",
          field: "id",
          sortable: false,
          tdClass: "text-center",
          // hidden: true
        },
        {
          label: "Title",
          field: "title",
          width: "50%",
        },
        {
          label: "Project",
          field: "project",
          tdClass: "text-center",
        },
        {
          label: "App",
          field: "app",
          tdClass: "text-center",
        },
        {
          label: "Length",
          field: "length",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Average FPS",
          field: "average_fps",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Median FPS",
          field: "median_fps",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Power",
          field: "power",
          tdClass: "text-center",
          type: "number",
        },
        {
          label: "Date",
          field: "date",
          tdClass: "text-center",
        },
        {
          label: "Tester",
          field: "tester",
          tdClass: "text-center",
        },
        {
          label: "",
          field: "log",
          sortable: false,
          tdClass: "text-center",
          width: "5%",
        },
      ],
    };
  },
  methods: {
    compareTests(row) {
      this.$router.push({
        name: "TestScoreComparisonById",
        params: {
          id: this.rows[row.vgt_header_id].id,
        },
      });
    },
    deleteComparison(row) {
      if (confirm("Are you sure continue to delete these scores?") == false) {
        return;
      }

      this.$http.delete(`/api/comparisons/${row.id}`).then(() => {
        this.rows.splice(row.vgt_header_id, 1);
      });
    },
    onRowClick(params) {
      let path = params.event.target;

      if (path.className == "vgt-checkbox-col" || path.nodeName == "INPUT") {
        return;
      } else if (path.innerText == "☆" || path.innerText == "★") {
        this.$http.put(`/api/tests/${params.row.id}/favorite`).then(row => {
          this.rows[params.row.originalIndex].is_favorite =
            !this.rows[params.row.originalIndex].is_favorite;
          console.log(row.data);
        });
      } else if (path.className == "log-icon amigo-icon") {
        window.open(`http://g2.gta.samsungds.net/#/log/${params.row.testitem_id}`);
        return;
      } else if (path.className == "log-icon gamebench-icon") {
        window.open(params.row.gamebench_url);
        return;
      } else if (path.className == "log-icon quickperf-icon") {
        window.open(params.row.quickperf_url);
        return;
      } else {
        this.$router.push({
          name: "TestScore",
          params: {
            id: params.row.id,
          },
        });
      }
    },
  },
};
</script>

<style>
.comparison-btn {
  float: right;
  margin-left: 5px;
}

.comparison-label {
  position: relative;
  top: 6px;
  left: 6px;
  display: inline-block;
  width: 90%;
}

.vgt-table th.vgt-row-header .triangle:after {
  margin: 0px;
}
</style>
