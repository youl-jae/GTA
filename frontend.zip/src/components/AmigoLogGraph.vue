<template>
  <div>
    <highcharts
      constructor-type="stockChart"
      :options="chartOptions"></highcharts>
  </div>
</template>

<script>
import Highcharts from "highcharts";
import { Chart } from "highcharts-vue";
import boost from "highcharts/modules/boost";
import stockInit from "highcharts/modules/stock";

stockInit(Highcharts);
boost(Highcharts);

export default {
  props: {
    title: String,
    chartType: String,
    yAxis: Array,
    series: Array,
    height: Number,
    pointInterval: Number,
  },
  components: {
    highcharts: Chart,
  },
  data() {
    const palette = [
      "#A0A0A0", // Gray
      "#FF0000", // Red
      "#D2A7E8", // Light Purple (Lavender)
      "#0070C0", // Medium Blue (Azure)
      "#70AD47", // Green (Olive Green)
      "#ED7C31", // Orange (Burnt Orange)
      "#FFD700", // Gold
      "#FF69B4", // Hot Pink
      "#8B4513", // Saddle Brown
      "#40E0D0", // Turquoise
      "#6A5ACD", // Slate Blue
      "#228B22", // Forest Green
      "#FF8C00", // Dark Orange
      "#C71585", // Medium Violet Red
      "#4682B4", // Steel Blue
      "#9ACD32", // Yellow Green
      "#8B0000", // Dark Red
      "#00CED1", // Dark Turquoise
      "#9932CC", // Dark Orchid
      "#B8860B", // Dark Goldenrod
    ];
    return {
      step: 100,
      colors: palette,
      chart: null,
      chartOptions: {
        colors: palette,
        chart: {
          type: this.chartType,
          zoomType: "x",
          height: this.height ?? 350,
          animation: false,
          events: {
            load: (function (self) {
              return function () {
                self.chart = this;
                this.syncKey = self.syncKey;
                self.bindCaptionEvents(this); // ← 최초 1회
              };
            })(this),
            render: (function (self) {
              return function () {
                self.bindCaptionEvents(this); // ← 매 redraw 때마다 재바인딩
              };
            })(this),
          },
        },
        boost: {
          enabled: this.chartType == "line",
          useGPUTranslations: true,
        },
        title: {
          text: this.title,
          x: -8,
          align: "left",
        },
        caption: {
          text: "",
          align: "right",
          verticalAlign: "top",
          x: -30,
          y: 16,
          margin: 0,
        },
        credits: { enabled: false },
        exporting: { enabled: true },
        scrollbar: { liveRedraw: true },
        navigator: {
          height: 30,
          margin: 10,
        },
        rangeSelector: {
          enabled: true,
          y: -35,
          dropdown: "never",
          buttons: [
            { type: "second", count: 1, text: "1s", title: "View 1 second" },
            { type: "second", count: 30, text: "30s", title: "View 30 second" },
            { type: "minute", count: 1, text: "1m", title: "View 1 minute" },
            { type: "minute", count: 5, text: "5m", title: "View 5 minute" },
            { type: "minute", count: 10, text: "10m", title: "View 10 minute" },
            { type: "minute", count: 20, text: "20m", title: "View 10 minute" },
            { type: "minute", count: 40, text: "40m", title: "View 10 minute" },
            {
              type: "all",
              text: "All",
              title: "View all",
            },
            {
              type: "null",
              text: "Sync",
              title: "Sync range",
              events: {
                click: this.syncRange,
              },
            },
          ],
          inputDateFormat: "%M:%S.%L",
          inputEditDateFormat: "%M:%S.%L",
          inputDateParser: function (value) {
            value = value.split(/[:.]/);
            return Date.UTC(
              1970,
              0,
              1,
              0,
              parseInt(value[0]),
              parseInt(value[1]),
              parseInt(value[2]),
            );
          },
          inputBoxBorderColor: "gray",
          inputStyle: {
            color: "#039",
            fontWeight: "bold",
          },
          labelStyle: {
            color: "silver",
            fontWeight: "bold",
          },
        },
        legend: {
          enabled: true,
          layout: "vertical",
          align: "left",
          verticalAlign: "middle",
          width: 101,
        },
        tooltip: {
          enabled: true,
          crosshairs: true,
          shared: true,
          split: false,
          borderColor: "rgb(100, 100, 100)",
          headerFormat: "<span>{point.index}</span><br/>",
          valueDecimals: 1,
        },
        plotOptions: {
          line: {
            lineWidth: 1,
            shadow: false,
            pointInterval: this.pointInterval,
            animation: false,
            boostThreshold: 1,
          },
          area: {
            lineWidth: 1,
            stacking: "normal",
            pointInterval: this.pointInterval,
            animation: false,
          },
        },
        xAxis: {
          lineWidth: 1,
          lineColor: "#e6e6e6",
          showLastLabel: true,
          dateTimeLabelFormats: {
            millisecond: "%Mm %Ss %Lms",
            second: "%Mm %Ss",
            minute: "%Mm %Ss",
            hour: "%Hh %Mm %Ss",
            day: "%Mm %Ss",
            week: "%Mm %Ss",
            month: "%Mm %Ss",
            year: "%Mm %Ss",
          },
          events: (function (self) {
            return {
              afterSetExtremes(e) {
                self.chartAverage();
              },
            };
          })(this),
        },
        yAxis: this.yAxis,
        series: this.series,
      },
    };
  },
  computed: {
    getAverage() {
      const list = [];

      if (!Array.isArray(this.series) || this.series.length === 0)
        return "<span style='color: white;'>-</span>";

      for (let i = 0; i < this.series.length; i++) {
        const s = this.series[i];
        if (!s || !s.average || !Array.isArray(s.data) || s.data.length === 0)
          continue;
        const avg = s.data.length
          ? s.data.reduce((a, b) => a + b, 0) / s.data.length
          : 0;
        list.push(
          `<span style="color: ${s.color ?? this.colors[i % 5]};">${s.name}: ${
            avg ? avg.toFixed(2) : 0
          }</span>`,
        );
      }
      return list.length === 0
        ? "<span style='color: white;'>-</span>"
        : list.join("   ");
    },
  },
  created() {
    this.chartOptions.caption.text = this.getAverage;
  },
  methods: {
    bindCaptionEvents(chart) {
      const el = chart?.caption?.element;
      if (!el) return;
      el.style.pointerEvents = "auto";
      el.onclick = e => {
        const raw =
          el.innerHTML ||
          el.textContent ||
          chart.caption?.textStr ||
          chart.options?.caption?.text ||
          "";
        this.copyCaptionText(raw);
      };
      el.onmouseover = this.mouseOver;
      el.onmouseout = this.mouseOut;
    },
    rangeToIndex(min, max) {
      const lo = Math.max(0, Math.floor(Number(min) / this.step));
      const hi = Math.max(lo + 1, Math.floor(Number(max) / this.step));
      return [lo, hi];
    },
    avgInRange(arr, lo, hi) {
      const subset = arr.slice(lo, hi + 1); // hi 포함
      return subset.length
        ? subset.reduce((a, b) => a + b, 0) / subset.length
        : 0;
    },
    buildCaptionFor(chart) {
      const list = [];
      const opts = chart.options;
      const [lo, hi] = this.rangeToIndex(
        chart.xAxis[0].min,
        chart.xAxis[0].max,
      );
      for (let i = 0; i < opts.series.length; i++) {
        const s = opts.series[i];
        if (!s || !s.average || !Array.isArray(s.data) || s.data.length === 0)
          continue;
        const avg = this.avgInRange(s.data, lo, hi);
        const color =
          s.color ??
          (opts.colors
            ? opts.colors[i % opts.colors.length]
            : this.colors[i % 5]);
        list.push(
          `<span style="color: ${color};">${s.name}: ${
            avg ? avg.toFixed(2) : 0
          }  </span>`,
        );
      }
      return list.length === 0
        ? "<span style='color: white;'>-</span>"
        : list.join("   ");
    },
    chartAverage() {
      if (!this.chart || !this.chart.xAxis?.[0]) return false;
      const text = this.buildCaptionFor(this.chart);
      this.chart.update({ caption: { text } }, false);
      this.chart.redraw(false);
      return false;
    },
    syncRange() {
      if (!this.chart) return false;
      const targetMin = this.chart.xAxis[0].min;
      const targetMax = this.chart.xAxis[0].max;
      for (const c of Highcharts.charts) {
        if (!c) continue;
        if (c.title?.textStr !== this.chartOptions.title.text) continue;
        c.xAxis[0].setExtremes(targetMin, targetMax, false);
        const text = this.buildCaptionFor(c);
        c.update({ caption: { text } }, false);
        c.redraw(false);
      }
      return false;
    },
    copyCaptionText(captionStr) {
      if (!captionStr) return;

      const tmp = document.createElement("div");
      tmp.innerHTML = captionStr;
      const plainText = tmp.textContent || tmp.innerText || "";

      if (!plainText.trim()) return;

      const ta = document.createElement("textarea");
      ta.value = plainText;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    },

    mouseOver() {
      if (!this.chart?.caption?.element) return;
      this.chart.caption.element.style.fontWeight = "600";
      this.chart.caption.element.style.cursor = "pointer";
    },
    mouseOut() {
      if (!this.chart?.caption?.element) return;
      this.chart.caption.element.style.fontWeight = "";
      this.chart.caption.element.style.cursor = "";
    },
  },
};
</script>
