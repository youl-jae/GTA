<template>
  <div id="app">
    <div class="box">
      <div class="title-group">
        <h1 class="main-title">
          <router-link :to="{ name: 'Home' }"
            ><img src="@/assets/gta_logo.png"></router-link
          >
        </h1>
        <div class="title-group" style="margin-top: 10px;">
          <span>
            <a href="https://confluence.samsungds.net/pages/viewpage.action?pageId=273511206" target="_blank" class="menu-text"><img src="@/assets/guide.png"></a>
          </span>
          <span><a href="https://confluence.samsungds.net/pages/viewpage.action?spaceKey=APSW&title=GTA+VOC" target="_blank" class="menu-text"><img src="@/assets/voc.png"></a></span>
          <span class="login-text menu-text" v-show="!this.$store.getters.isLogin"
            ><router-link :to="{ name: 'Login' }"><img src="@/assets/login.png"></router-link></span
          >
          <div class="title-group" style="margin-left: 5px;" v-show="this.$store.getters.isLogin">
            <b-dropdown
              right
              size="sm"
              variant="link"
              :text="`${this.$store.state.userStore.userName} (${this.$store.state.userStore.knoxId})`"
              class="profile-dropdown">
              <b-dropdown-item @click="logout">Logout</b-dropdown-item>
            </b-dropdown>
          </div>
        </div>
      </div>
      <nav-bar></nav-bar>
      <div class="body">
        <router-view :key="$route.fullPath"></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import NavBar from "@/components/navigation/NavBar.vue";

export default {
  name: "App",
  components: {
    NavBar,
  },
  methods: {
    logout() {
      this.$http.get("/api/login/logout").then(() => {
        this.$store.commit("logout");
        alert("Logout !");
        this.$router.push({
          name: "Home",
        });
      });
    },
  },
};
</script>

<style>
#app {
  /* font-family: Avenir, Helvetica, Arial, sans-serif; */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}

.main-title {
  color: #205081;
  font-size: 30pt;
  padding-top: 10px;
  padding-bottom: 5px;
  font-weight: bold;
}

.main-title a:link,
.login-text a:link {
  color: #205081;
  text-decoration: none;
}

.main-title a:visited,
.login-text a:visited {
  color: #205081;
  text-decoration: none;
}

.main-title a:hover,
.login-text a:hover {
  color: #193857;
  text-decoration: none;
}

.menu-text {
  color: #205081;
  text-decoration: none;
  margin-left: 15px;
}

.menu-text:hover {
  color: #193857;
  text-decoration: none;
}

.body {
  padding: 10px;
  background-color: #ffffff;
  border-style: solid;
  border-width: 0.1ch;
  border-color: rgb(220, 220, 220);
  margin-top: 15px;
  margin-bottom: 15px;
}

.sub-title {
  font-size: large;
}

.sub-title-group {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.sub-title-btn-group button {
  margin-left: 0.3rem;
}

.box {
  padding-right: 10px;
  padding-left: 10px;
}

.title-group {
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #205081;
  font-weight: bold;
}

.profile-icon {
  color: white;
  vertical-align: -0.1em;
}

.profile-background {
  width: 32px;
  height: 32px;
  font-size: 1.4rem;
  text-align: center;
  border-radius: 70%;
  background-color: #4472C4;
  margin-left: 0.5rem;
}

.profile-dropdown button,
.profile-dropdown button:hover,
.profile-dropdown button:focus {
  color: #4472C4;
  font-weight: bold;
  font-size: 16px;
  text-decoration: none;
  background-color: #80000000;
  border-color: #80000000;
  box-shadow: 0 0 0 0 rgba(0, 0, 0, 0);
}
</style>
