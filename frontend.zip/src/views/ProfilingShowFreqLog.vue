<template>
  <div>
    <vue-instant-loading-spinner ref="Spinner" color="#205081" />
    <div class="sub-title-group">
      <span class="sub-title">Soc Dumper Viewer</span>
    </div>
    <div>
      <div v-show="!testitemId" class="custom-file">
        <input
          type="file"
          class="custom-file-input"
          ref="inputDirectory"
          id="inputDirectory"
          webkitdirectory
          @change="readDirectory" />
        <label class="custom-file-label" for="inputDirectory"
          >Choose directory (*.log or *.txt)</label
        >
      </div>
      <div v-for="(file, index) in fileList" :key="`freq-log-${index}`">
        <p v-show="testitemId" class="sub-title">{{ file.path }}</p>
        <show-freq-log-graph
          class="mt-3 mb-3"
          :ref="`show-freq-graph`"
          :title="file.name"
          :series="file.series"
          :pointInterval="pointInterval">
        </show-freq-log-graph>
      </div>
    </div>
  </div>
</template>

<script>
import VueInstantLoadingSpinner from "vue-instant-loading-spinner";
import ShowFreqLogGraph from "../components/ShowFreqLogGraph.vue";

export default {
  name: "ShowFreqLogProfiler",
  components: {
    ShowFreqLogGraph,
    VueInstantLoadingSpinner,
  },
  data() {
    return {
      fileList: [],
      pointInterval: 100,
    };
  },
  computed: {
    testitemId() {
      return this.$route.params.id;
    },
  },
  async mounted() {
    this.$refs.Spinner.show();

    if (this.testitemId) {
      try {
        const idList = this.$route.params.id.split(",");

        for (let i = 0; i < idList.length; i++) {
          const res = await this.$http.get(
            `/api/testitems/${idList[i]}/showfreq`,
          );

          var names = res.data.fileName.split("\\");
          var file = {
            path: res.data.fileName,
            name: names[names.length - 1].split(".txt")[0],
            data: res.data.log,
            series: [],
          };

          this.parseLog(file);
        }
      } catch (err) {
        console.log(err);
      }
    }
    this.$refs.Spinner.hide();
  },
  methods: {
    readDirectory() {
      const selectedFiles = this.$refs.inputDirectory.files;

      const failedOpen = [];

      for (const file of selectedFiles) {
        if (file.name.lastIndexOf(".") > 0) {
          const extension = file.name.substring(
            file.name.lastIndexOf(".") + 1,
            file.name.length,
          );

          if (!(extension == "log" || extension == "txt")) {
            failedOpen.push(file.name);
            continue;
          }

          const reader = new FileReader();
          reader.fileName = file.name;
          reader.onload = this.readFile;
          reader.readAsText(file, "UTF-8");
        } else {
          failedOpen.push(file.name);
          continue;
        }
      }

      if (failedOpen.length != 0) {
        alert(
          "Please enter the file extension as .log or .txt\n\n" +
            failedOpen.join("\n"),
        );
      }
    },
    readFile(event) {
      var file = {
        path: event.target.fileName,
        name: event.target.fileName,
        data: event.target.result,
        series: [],
      };

      this.parseLog(file);
    },
    parseLog(file) {
      let result = file.data
        .trim()
        .split("\n")
        .map(x => x.split("|"));

      const title = result[0];
      result = result.slice(1);

      for (let i = 0; i < title.length; i++) {
        const titleArr = title[i].split(" ");
        const resultArr = result.map(x => x[i].split(" ").filter(x => x));

        for (let j = 0; j < titleArr.length; j++) {
          const data = resultArr.map(x => parseFloat(x[j]));
          const avg = data.reduce((acc, cur) => acc + cur, 0) / data.length;

          file.series.push({
            yAxis: avg > 100 ? 0 : 1,
            name: titleArr[j],
            data: data,
            visible: titleArr.length == 1,
          });
        }
      }

      this.fileList.push(file);
    },
  },
};
</script>
