<template>
  <div class="analayzer-box">
    <vue-instant-loading-spinner
      ref="Spinner"
      color="#205081"></vue-instant-loading-spinner>

    <div class="sub-title-group">
      <span class="sub-title">Game Analyzer</span>
      <div class="sub-title-group">
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="copy"
          @click="copyToClipboard">
          <font-awesome-icon icon="copy" />
        </b-button>

        <div class="info-group" @click="showInfoMenu">INFO</div>
      </div>
    </div>
    <hr />
    <div
      v-for="(item, index) in tableItems"
      class="table-box-sub"
      :key="`table-box-${index}-FPS`"
      :id="`table-box-${index}-FPS`">
      <div class="tooltip_test">
        FPS
        <div class="tooltiptext_test">
          <h5 id="fps-fps-">FPS(fps)</h5>
          <ul>
            <li>
              목적
              <ul>
                <li>FPS 목표치와 실측치를 통해 현재의 FPS 상황 확인</li>
              </ul>
            </li>
            <li>
              항목
              <ul>
                <li>
                  <code>TargetFPS</code>: App, Display등의 상황을 고려하여
                  Amigo가 산출하는 목표 FPS
                </li>
                <li>
                  <code>CurrentFPS</code>: 현재의 실제 측정 FPS(refresh rate,
                  off-screen등의 Test는 낮게 나올 수 있음)
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
      <div class="analyzertb">
        <!-- <div> -->
        <ve-table
          :columns="item.FPS.columns"
          :table-data="item.FPS.tableData" />
      </div>
    </div>
    <div
      v-for="(item, index) in chartItems"
      :key="`chart-box-${index}`"
      :id="`chart-box-${index}`">
      <!-- <h4 :id="index">{{ index }}</h4> -->
      <!-- Rendertime in state -->
      <div
        class="chart-box-sub"
        :key="`chart-box-tis-${item.render_TIS}`"
        :id="`chart-box-tis-${item.render_TIS}`">
        <game-analyzer-graph
          :title="item.render_TIS.title"
          :chartType="item.render_TIS.chartType"
          :xAxis="item.render_TIS.xAxis"
          :yAxis="item.render_TIS.yAxis"
          :tooltip="item.render_TIS.tooltip"
          :plotOptions="item.render_TIS.plotOptions"
          :legend="item.render_TIS.legend"
          :series="item.render_TIS.series">
        </game-analyzer-graph>
      </div>
      <!-- Frequency time in state -->
      <div
        v-for="(tis_item, tis_index) in item.frequency_tis"
        class="chart-box-sub"
        :key="`chart-box-tis-${tis_index}`"
        :id="`chart-box-tis-${tis_index}`">
        <!-- <h4 :id="tis_index">{{ tis_index }}</h4> -->
        <game-analyzer-graph
          :title="tis_item.title"
          :chartType="tis_item.chartType"
          :xAxis="tis_item.xAxis"
          :yAxis="tis_item.yAxis"
          :tooltip="tis_item.tooltip"
          :plotOptions="tis_item.plotOptions"
          :legend="tis_item.legend"
          :series="tis_item.series">
        </game-analyzer-graph>
      </div>
      <div
        v-for="(avg_item, avg_index) in item.averageItem"
        class="chart-box-sub"
        :key="`chart-box-avg-${avg_index}`"
        :id="`chart-box-avg-${avg_index}`">
        <!-- <h4 :id="avg_index">{{ avg_index }}</h4> -->
        <game-analyzer-graph
          :title="avg_item.title"
          :chartType="avg_item.chartType"
          :xAxis="avg_item.xAxis"
          :yAxis="avg_item.yAxis"
          :tooltip="avg_item.tooltip"
          :plotOptions="avg_item.plotOptions"
          :legend="avg_item.legend"
          :series="avg_item.series">
        </game-analyzer-graph>
      </div>
    </div>
    <div
      v-for="(item, index) in tableItems"
      :key="`table-box-${index}`"
      :id="`table-box-${index}`">
      <div class="analyzertb">
        <div
          v-for="(tb_item, tb_index) in item"
          class="table-box-sub"
          :key="`table-box-${index}-${tb_index}`"
          :id="`table-box-${index}-${tb_index}`">
          <h5>{{ tb_index }}</h5>
          <ve-table
            :columns="tb_item.columns"
            :table-data="tb_item.tableData" />
        </div>
      </div>
    </div>
    <b-modal id="info-modal" title="INFO Page" size="xl">
      <div>
        <draggable
          @start="drag = true"
          @end="drag = false"
          class="list-group list-group-flush">
          <div class="info_class">
            <h3 id="gameanalyzer">GameAnalyzer</h3>
            <h5 id="fps-fps-">FPS(fps)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>FPS 목표치와 실측치를 통해 현재의 FPS 상황 확인</li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li>
                    <code>TargetFPS</code>: App, Display등의 상황을 고려하여
                    Amigo가 산출하는 목표 FPS
                  </li>
                  <li>
                    <code>CurrentFPS</code>: 현재의 실제 측정 FPS(refresh rate,
                    off-screen등의 Test는 낮게 나올 수 있음)
                  </li>
                </ul>
              </li>
            </ul>
            <h5 id="render-time-in-state-">Render Time in state(%)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>
                    구간 내의 CPU/GPU의 실측 FPS 분포 비율을 확인하여, CPU/GPU
                    Bound 판별에 사용
                  </li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li><code>CPU</code>: CPU의 Rendering FPS Time in state</li>
                  <li><code>GPU</code>: GPU의 Rendering FPS Time in state</li>
                </ul>
              </li>
            </ul>
            <h5 id="frequency-time-in-state-">Frequency Time in state(%)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>
                    구간 내의 각 IP별로 구간 내의 Frequency 분포 비율을 확인
                  </li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li>
                    <code>IP name</code>: {IP name}의 Frequency Time in state
                  </li>
                </ul>
              </li>
              <li>단위 : 백분률(%)</li>
              <li>판단: 어떤 Frequency에서 많이 돌았는지</li>
            </ul>
            <h5 id="frequency-l-mhz-r-">Frequency(L:Mhz, R:%)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>
                    구간 내의 각 IP별로 평균/최소/최대 Frequency 및 Active Ratio
                    확인
                  </li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li>
                    <code>Current</code>: 현재 IP의 Current Frequency(clock)
                    평균
                  </li>
                  <li><code>Max</code>: 현재 IP의 Max Frequency(clock) 평균</li>
                  <li><code>Min</code>: 현재 IP의 Min Frequency(clock) 평균</li>
                  <li>
                    <code>Active Ratio</code>: 현재 IP의 Active Ratio 평균
                  </li>
                </ul>
              </li>
            </ul>
            <h5 id="estimated-power-mw-">Estimated Power(mW)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>
                    Amigo내에서 DVFS Table, Time in state를 참조하여 예측한
                    Power (100ms 단위)
                  </li>
                  <li>실험 조건에 따른 Power 경향성 예측에 활용</li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li><code>Power</code>: mW단위의 예측 Power</li>
                </ul>
              </li>
            </ul>
            <h5 id="temperature-c-">Temperature(°C)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>
                    각 IP들에 해당 되는 Thermal Zone의 계측 값을 확인하고, 온도
                    경향 예측에 활용
                  </li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li><code>°C</code>: 각 IP들에 해당되는 Thermal Zone의 값</li>
                </ul>
              </li>
            </ul>
            <h5 id="performance-mode-">Performance Mode(%)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>구간 내의 시간축으로 Amigo mode 변화를 확인</li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li><code>Normal</code> : 일반 Amigo mode</li>
                  <li>
                    <code>HP(High Performance)</code>: 일정 성능 Drop 관련 조건
                    만족시 진입하는 Performance 우선 mode
                  </li>
                  <li>
                    <code>LP(Low Performance)</code>: 성능을 유지한 Power
                    optimization 우선 mode
                  </li>
                  <li>
                    <code>ELP(Extreme Low Power scenario)</code>: 최대한의 Power
                    optimization을 동작하기 위한 Power opimization 우선 mode
                  </li>
                </ul>
              </li>
            </ul>
            <h5 id="heaviness-by-moving-window-average-power-">
              Heaviness by Moving Window Average Power(%)
            </h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>
                    2초 간(100ms * 20window) 관측 된 Estimation power data를
                    통해 CPU/GPU Heavy 여부 판단 된 횟수 비율 확인
                  </li>
                  <li>총 구간 내 CPU/GPU Heavy로 판단 된 Time slice의 비율</li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li>
                    <code>cpuheavy</code>: CPU Heavy count(CPU Power &gt;=
                    700mW)
                  </li>
                  <li>
                    <code>gpuheavy</code>: GPU Heavy count(CPU Power &gt;= 400mW
                    &amp;&amp; (GPU Power / CPU Power) &gt;= 40%)
                  </li>
                </ul>
              </li>
            </ul>
            <h5 id="workload-kilo-cycle-">Workload(kilo cycle)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>구간 내 CPU/GPU에 가해지는 Workload 비율의 평균</li>
                  <li>1frame 당 CPU/GPU Cycle 갯수</li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li>
                    <code>CPU Workload</code> : CPU Workload, Mid freq * AVG(CPU
                    Render time)
                  </li>
                  <li>
                    <code>GPU Workload</code>: GPU Worklaod, GPU freq * AVG(GPU
                    Render time )
                  </li>
                </ul>
              </li>
            </ul>
            <h5 id="bottleneck-">Bottleneck(%)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>
                    CPU/GPU/MIF의 bottleneck flag 활성화 정도를 통해, bottleneck
                    IP 판단
                  </li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li>
                    <code>CPU</code> : 구간 시간내 CPU Bottleneck 판단 비율
                  </li>
                  <li>
                    <code>GPU</code> :구간 시간내 CPU Bottleneck 판단 비율
                  </li>
                  <li>
                    <code>MIF-BW</code>: 구간 시간내 MIF-BW Bottleneck 판단 비율
                  </li>
                  <li>
                    <code>MIF-LAT</code>: 구간 시간내 MIF-LAT Bottleneck 판단
                    비율
                  </li>
                </ul>
              </li>
            </ul>
            <h5 id="the-number-of-frame-drops-by-bottleneck-">
              The Number of Frame Drops by bottleneck(%)
            </h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>Framedrop 발생 시, 이를 유발한 Bottlenck IP 확인</li>
                  <li>
                    구간 내 각 IP별로 Max Frequency일 때, Target rendertime을
                    충족 못한 경우의 비율
                  </li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li><code>{IP name}</code>: 각 IP 별 Framedrop %</li>
                </ul>
              </li>
              <li>판단 : 어떤 IP가 많이 눌리는 지 확인</li>
            </ul>
            <h5 id="mif-latency-us-cpc-">MIF Latency(us, cpc)</h5>
            <ul>
              <li>
                목적
                <ul>
                  <li>MIF Latency 비교를 위해 필요</li>
                </ul>
              </li>
              <li>
                항목
                <ul>
                  <li><code>MIF Latency(ns)</code> :MIF Latency 값</li>
                  <li>
                    <code>MIF Latnecy (cpc)</code> : CPU Cycle 당 MIF Latency
                    cycle
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </draggable>
      </div>
    </b-modal>
  </div>
</template>

<script>
import GameAnalyzerGraph from "../components/GameAnalyzerGraph";
import VueInstantLoadingSpinner from "vue-instant-loading-spinner";

export default {
  name: "AmigoAnalyzer",
  components: {
    GameAnalyzerGraph,
    VueInstantLoadingSpinner,
  },
  data() {
    return {
      logData: [],
      frequency: {},
      convertdata: [],
      chartItems: [],
      tableItems: [],
      logItem: {
        TargetFPS: { unit: "fps", calc: "average" },
        CurrentFPS: { unit: "fps", calc: "average" },

        /*Freq*/
        fLIT: { unit: "MHz", calc: "average" },
        fMinLIT: { unit: "MHz", calc: "average" },
        fMaxLIT: { unit: "MHz", calc: "average" },
        fMID: { unit: "MHz", calc: "average" },
        fMinMID: { unit: "MHz", calc: "average" },
        fMaxMID: { unit: "MHz", calc: "average" },
        fMIDL: { unit: "MHz", calc: "average" },
        fMinMIDL: { unit: "MHz", calc: "average" },
        fMaxMIDL: { unit: "MHz", calc: "average" },
        fMIDH: { unit: "MHz", calc: "average" },
        fMinMIDH: { unit: "MHz", calc: "average" },
        fMaxMIDH: { unit: "MHz", calc: "average" },
        fBIG: { unit: "MHz", calc: "average" },
        fMinBIG: { unit: "MHz", calc: "average" },
        fMaxBIG: { unit: "MHz", calc: "average" },
        fGPU: { unit: "MHz", calc: "average" },
        fMinGPU: { unit: "MHz", calc: "average" },
        fMaxGPU: { unit: "MHz", calc: "average" },
        fMIF: { unit: "MHz", calc: "average" },
        fMinMIF: { unit: "MHz", calc: "average" },
        fMaxMIF: { unit: "MHz", calc: "average" },

        /*Active Ratio*/
        ActiveRatioLIT: { unit: "%", calc: "average" },
        ActiveRatioMID: { unit: "%", calc: "average" },
        ActiveRatioMIDL: { unit: "%", calc: "average" },
        ActiveRatioMIDH: { unit: "%", calc: "average" },
        ActiveRatioBIG: { unit: "%", calc: "average" },
        ActiveRatioGPU: { unit: "%", calc: "average" },
        ActiveRatioMIF: { unit: "%", calc: "average" },

        /*Margin*/
        MarginLIT: { unit: "%", calc: "average" },
        MinMarginLIT: { unit: "%", calc: "average" },
        MaxMarginLIT: { unit: "%", calc: "average" },
        MarginMID: { unit: "%", calc: "average" },
        MinMarginMID: { unit: "%", calc: "average" },
        MaxMarginMID: { unit: "%", calc: "average" },
        MarginMIDL: { unit: "%", calc: "average" },
        MinMarginMIDL: { unit: "%", calc: "average" },
        MaxMarginMIDL: { unit: "%", calc: "average" },
        MarginMIDH: { unit: "%", calc: "average" },
        MinMarginMIDH: { unit: "%", calc: "average" },
        MaxMarginMIDH: { unit: "%", calc: "average" },
        MarginBIG: { unit: "%", calc: "average" },
        MinMarginBIG: { unit: "%", calc: "average" },
        MaxMarginBIG: { unit: "%", calc: "average" },
        MarginGPU: { unit: "%", calc: "average" },
        MinMarginGPU: { unit: "%", calc: "average" },
        MaxMarginGPU: { unit: "%", calc: "average" },
        MarginMIF: { unit: "%", calc: "average" },
        MinMarginMIF: { unit: "%", calc: "average" },
        MaxMarginMIF: { unit: "%", calc: "average" },

        /*Power*/
        LeakageLIT: { unit: "mW", calc: "average" },
        DynamicLIT: { unit: "mW", calc: "average" },
        LeakageMID: { unit: "mW", calc: "average" },
        DynamicMID: { unit: "mW", calc: "average" },
        LeakageMIDL: { unit: "mW", calc: "average" },
        DynamicMIDL: { unit: "mW", calc: "average" },
        LeakageMIDH: { unit: "mW", calc: "average" },
        DynamicMIDH: { unit: "mW", calc: "average" },
        LeakageBIG: { unit: "mW", calc: "average" },
        DynamicBIG: { unit: "mW", calc: "average" },
        LeakageGPU: { unit: "mW", calc: "average" },
        DynamicGPU: { unit: "mW", calc: "average" },
        LeakageMIF: { unit: "mW", calc: "average" },
        DynamicMIF: { unit: "mW", calc: "average" },
        TotalPower: { unit: "mW", calc: "average" },

        /*Temp*/
        tempLIT: { unit: "ºC", calc: "average" },
        tempMID: { unit: "ºC", calc: "average" },
        tempMIDL: { unit: "ºC", calc: "average" },
        tempMIDH: { unit: "ºC", calc: "average" },
        tempBIG: { unit: "ºC", calc: "average" },
        tempGPU: { unit: "ºC", calc: "average" },
        tempMIF: { unit: "ºC", calc: "average" },
        tempAVG: { unit: "ºC", calc: "average" },

        /*CPU Tracer*/
        // *not yet used*
        // Latest_SwapCaller :  {unit: "", calc: ""},
        // Main_SwapCaller :  {unit: "", calc: ""},
        // SwapPCT_LIT :  {unit: "", calc: ""},
        // SwapPCT_MIDL :  {unit: "", calc: ""},
        // SwapPCT_MIDH :  {unit: "", calc: ""},
        // SwapPCT_BIG :  {unit: "", calc: ""},
        // Target_FrameTime :  {unit: "", calc: ""},
        // Swap_Interval :  {unit: "", calc: ""},
        // CPU_RenderTime :  {unit: "", calc: ""},
        // GPU_RenderTime :  {unit: "", calc: ""},
        // CPU_RenderTimeMargin :  {unit: "", calc: ""},
        // GPU_RenderTimeMargin :  {unit: "", calc: ""},

        /*Time*/
        RenderTime_Avg_Preparing: { unit: "", calc: "average" },
        RenderTime_Avg_CPU: { unit: "", calc: "average" },
        RenderTime_Avg_V2S: { unit: "", calc: "average" },
        RenderTime_Avg_GPU: { unit: "", calc: "average" },
        RenderTime_Avg_V2F: { unit: "", calc: "average" },
        RenderTime_Max_Preparing: { unit: "", calc: "average" },
        RenderTime_Max_CPU: { unit: "", calc: "average" },
        RenderTime_Max_V2S: { unit: "", calc: "average" },
        RenderTime_Max_GPU: { unit: "", calc: "average" },
        RenderTime_Max_V2F: { unit: "", calc: "average" },
        cpuwl_ratio: { unit: "", calc: "average" },
        heavypre: { unit: "", calc: "average" },

        /*MIF bw/lat*/
        SYS_BW_kbpc: { unit: "", calc: "average" },
        SYS_BW_Gbps: { unit: "", calc: "average" },
        SYS_Lat_cyc: { unit: "cpc", calc: "average" },
        SYS_Lat_ns: { unit: "", calc: "average" },
        CPU_BW_Gbps: { unit: "", calc: "average" },
        CPU_Lat_cyc: { unit: "", calc: "average" },
        CPU_Lat_ns: { unit: "", calc: "average" },
        GPU_BW_Gbps: { unit: "", calc: "average" },
        GPU_Lat_cyc: { unit: "", calc: "average" },
        GPU_Lat_ns: { unit: "", calc: "average" },

        /*HP/LP/ELP*/
        HP: { unit: "%", calc: "percentage" },
        LP: { unit: "%", calc: "percentage" },
        ELP: { unit: "%", calc: "percentage" },
        NormalP: { unit: "%", calc: "percentage" },

        /*Bottleck*/
        bottleneckCPU: { unit: "%", calc: "percentage" },
        bottleneckGPU: { unit: "%", calc: "percentage" },
        bottleneckMIF_BW: { unit: "%", calc: "percentage" },
        bottleneckMIF_lat: { unit: "%", calc: "percentage" },

        /*PWR*/
        PWRCPUPowerHeavy: { unit: "%", calc: "percentage" },
        PWRGPUPowerHeavy: { unit: "%", calc: "percentage" },

        /*Event*/
        Event: { unit: "", calc: "" },

        /*Calculator data*/
        CPUWorkload: { unit: "Kcycle", calc: "average" },
        GPUWorkload: { unit: "Kcycle", calc: "average" },
        MIFLatencyns: { unit: "ns", calc: "average" },
        FrameDropLIT: { unit: "%", calc: "percentage" },
        FrameDropMID: { unit: "%", calc: "percentage" },
        FrameDropMIDL: { unit: "%", calc: "percentage" },
        FrameDropMIDH: { unit: "%", calc: "percentage" },
        FrameDropBIG: { unit: "%", calc: "percentage" },
        FrameDropGPU: { unit: "%", calc: "percentage" },
        FrameDropMIF: { unit: "%", calc: "percentage" },
      },
      IP_DICT: {
        CL0: "LIT",
        CL1: "MID",
        CL1L: "MIDL",
        CL1H: "MIDH",
        CL2: "BIG",
        G3D: "GPU",
        MIF: "MIF",
      },
    };
  },
  async mounted() {
    // show loading
    this.$refs.Spinner.show();

    try {
      // read quary string - ex) /Gameanalyze?id=345&min=0&max=123
      const idList = this.$route.query.id.split(",");
      const minTimeList = this.$route.query.min.split(",");
      const maxTimeList = this.$route.query.max.split(",");
      // Get log with id
      for (let i = 0; i < idList.length; i++) {
        var res, res2;
        const id = idList[i];
        if (Number(id) > 0) {
          res = await this.$http.get(`/api/testitems/${id}/log`);
          this.logData.splice(i, 1, res.data);
          res2 = await this.$http.get(`/api/frequency/${res.data.projectId}`);
          this.convertdata.push({});
          this.chartItems.push({});
          this.tableItems.push({});
          this.frequency = res2.data;
          if (res.data.log) {
            this.convertLog(i, minTimeList[i], maxTimeList[i]);
            this.convertform(i);
            this.convertvetable(i);
          }
        }
      }
      await this.$nextTick();
    } catch (err) {
      console.log(err);
    }

    //  hide loading
    this.$refs.Spinner.hide();
  },
  computed: {},
  methods: {
    copyToClipboard() {
      var selection = window.getSelection();
      var range = document.createRange();
      // var range2 = document.createRange();
      let test = document.getElementsByClassName("analyzertb");
      range.selectNodeContents(test[0]);
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand("copy");
      selection.removeAllRanges();
    },
    convertLog(index, minTime, maxTime) {
      const amigoLog = this.logData[index];

      //The error values frequently occur in the first line.
      minTime = Number(minTime) + 1;
      maxTime = Number(maxTime) + 1;

      // split log to list
      const lines = amigoLog.log
        .split("\n")
        .filter(x => x.match(/\| FPS\(t\/c\/r\)=.+/) != null);

      if (lines.length < 1) {
        return;
      }

      // check cpu cluster count
      this.logData[index].freqCnt = lines[0]
        .match(/\| F=[\s-\d]+?[|]/)[0]
        .match(/([-]?\d+)/gi).length;

      let ip_dict = {
        4: [
          { name: "Little", key: "LIT" },
          { name: "Big", key: "BIG" },
          { name: "GPU", key: "GPU" },
          { name: "MIF", key: "MIF" },
        ],
        5: [
          { name: "Little", key: "LIT" },
          { name: "Middle", key: "MID" },
          { name: "Big", key: "BIG" },
          { name: "GPU", key: "GPU" },
          { name: "MIF", key: "MIF" },
        ],
        6: [
          { name: "Little", key: "LIT" },
          { name: "Middle LF", key: "MIDL" },
          { name: "Middle HF", key: "MIDH" },
          { name: "Big", key: "BIG" },
          { name: "GPU", key: "GPU" },
          { name: "MIF", key: "MIF" },
        ],
      };
      this.logData[index].IPs = ip_dict[this.logData[index].freqCnt];
      var logItem = {
        TargetFPS: [],
        CurrentFPS: [],

        /*Freq*/
        // fLIT:[], fMinLIT:[], fMaxLIT:[],
        // fMIDL:[], fMinMIDL:[], fMaxMIDL:[],
        // fMIDH:[], fMinMIDH:[], fMaxMIDH:[],
        // fBIG:[], fMinBIG:[], fMaxBIG:[],
        // fGPU:[], fMinGPU:[], fMaxGPU:[],
        // fMIF:[], fMinMIF:[], fMaxMIF:[],

        /*Active Ratio*/
        // ActiveRatioLIT : [],
        // ActiveRatioMIDL : [],
        // ActiveRatioMIDH : [],
        // ActiveRatioBIG : [],
        // ActiveRatioGPU : [],
        // ActiveRatioMIF : [],

        /*Margin*/
        // MarginLIT:[], MinMarginLIT:[], MaxMarginLIT : [],
        // MarginMIDL:[], MinMarginMIDL:[], MaxMarginMIDL : [],
        // MarginMIDH:[], MinMarginMIDH:[], MaxMarginMIDH : [],
        // MarginBIG:[], MinMarginBIG:[], MaxMarginBIG : [],
        // MarginGPU:[], MinMarginGPU:[], MaxMarginGPU : [],
        // MarginMIF:[], MinMarginMIF:[], MaxMarginMIF : [],

        /*Power*/
        // LeakageLIT:[], DynamicLIT : [],
        // LeakageMIDL:[], DynamicMIDL : [],
        // LeakageMIDH:[], DynamicMIDH : [],
        // LeakageBIG:[], DynamicBIG : [],
        // LeakageGPU:[], DynamicGPU : [],
        // LeakageMIF:[], DynamicMIF : [],
        TotalPower: [],

        /*Temp*/
        // tempLIT : [],
        // tempMIDL : [],
        // tempMIDH : [],
        // tempBIG : [],
        // tempGPU : [],
        // tempMIF : [],
        tempAVG: [],

        /*CPU Tracer*/
        // *not yet used*
        // Latest_SwapCaller : [],
        // Main_SwapCaller : [],
        // SwapPCT_LIT : [],
        // SwapPCT_MIDL : [],
        // SwapPCT_MIDH : [],
        // SwapPCT_BIG : [],
        // Target_FrameTime : [],
        // Swap_Interval : [],
        // CPU_RenderTime : [],
        // GPU_RenderTime : [],
        // CPU_RenderTimeMargin : [],
        // GPU_RenderTimeMargin : [],

        /*Time*/
        RenderTime_Avg_Preparing: [],
        RenderTime_Avg_CPU: [],
        RenderTime_Avg_V2S: [],
        RenderTime_Avg_GPU: [],
        RenderTime_Avg_V2F: [],
        RenderTime_Max_Preparing: [],
        RenderTime_Max_CPU: [],
        RenderTime_Max_V2S: [],
        RenderTime_Max_GPU: [],
        RenderTime_Max_V2F: [],
        cpuwl_ratio: [],
        heavypre: [],

        /*MIF bw/lat*/
        SYS_BW_kbpc: [],
        SYS_BW_Gbps: [],
        SYS_Lat_cyc: [],
        SYS_Lat_ns: [],
        CPU_BW_Gbps: [],
        CPU_Lat_cyc: [],
        CPU_Lat_ns: [],
        GPU_BW_Gbps: [],
        GPU_Lat_cyc: [],
        GPU_Lat_ns: [],

        /*HP/LP/ELP*/
        HP: [],
        LP: [],
        ELP: [],
        NormalP: [],

        /*Bottleck*/
        bottleneckCPU: [],
        bottleneckGPU: [],
        bottleneckMIF_BW: [],
        bottleneckMIF_lat: [],

        /*PWR*/
        PWRCPUPowerHeavy: [],
        PWRGPUPowerHeavy: [],

        /*Event*/
        Event: [],

        /*Calculator data*/
        CPUWorkload: [],
        GPUWorkload: [],
        MIFLatencyns: [],
        // FrameDrop: [],
      };
      let additional_items = [
        "f",
        "fMin",
        "fMax",
        "ActiveRatio",
        "Margin",
        "Leakage",
        "Dynamic",
        "temp",
        "FrameDrop",
      ];
      for (var item of additional_items) {
        for (var IP of this.logData[index].IPs) {
          let item_name = item + IP.key;
          logItem[item_name] = [];
        }
      }

      if (maxTime > lines.length) {
        maxTime = lines.length;
      }

      for (let s = minTime; s <= maxTime; s++) {
        var line = lines[s];
        var data = line
          .split(" ")
          .filter(x => x && x != "|")
          .map(x => (isNaN(x) ? x : parseInt(x)));

        for (let i = 0; i < data.length; i++) {
          if (data[i] == "FPS(t/c/r)=") {
            // FPS - target current diff%
            // FPS(t/c/r)= TargetFPS CurrentFPS Diff
            logItem.TargetFPS.push(data[i + 1] / 10);
            logItem.CurrentFPS.push(data[i + 2] / 10);
          } else if (
            data[i] == "A(%)=" ||
            data[i] == "A(pct)=" ||
            data[i] == "A()="
          ) {
            // Active Ratio%
            for (
              let IP_index = 0;
              IP_index < this.logData[index].IPs.length;
              IP_index++
            ) {
              let item_name =
                "ActiveRatio" + this.logData[index].IPs[IP_index].key;
              logItem[item_name].push(data[i + IP_index + 1]);
            }
          } else if (data[i] == "M=") {
            // Margine%
            for (
              let IP_index = 0;
              IP_index < this.logData[index].IPs.length;
              IP_index++
            ) {
              let item_name = "Margin" + this.logData[index].IPs[IP_index].key;
              logItem[item_name].push(data[i + IP_index + 1]);
            }
          } else if (data[i] == "F=") {
            // Freq.
            for (
              let IP_index = 0;
              IP_index < this.logData[index].IPs.length;
              IP_index++
            ) {
              let item_name = "f" + this.logData[index].IPs[IP_index].key;
              logItem[item_name].push(data[i + IP_index + 1]);
            }
          } else if (data[i] == "l/h=") {
            // Freq Min Max.
            for (
              let IP_index = 0;
              IP_index < this.logData[index].IPs.length;
              IP_index++
            ) {
              IP_index = parseInt(IP_index);
              let item_name = "fMin" + this.logData[index].IPs[IP_index].key;
              logItem[item_name].push(data[i + IP_index * 2 + 1]);
              item_name = "fMax" + this.logData[index].IPs[IP_index].key;
              logItem[item_name].push(data[i + IP_index * 2 + 2]);
            }
          } else if (data[i] == "AP/SP=") {
            // Power - Leakage Dynamic
            var sumPower = 0;
            for (
              let IP_index = 0;
              IP_index < this.logData[index].IPs.length;
              IP_index++
            ) {
              let item_name = "Dynamic" + this.logData[index].IPs[IP_index].key;
              logItem[item_name].push(data[i + IP_index * 2 + 1]);
              sumPower += data[i + IP_index * 2 + 1];
              item_name = "Leakage" + this.logData[index].IPs[IP_index].key;
              logItem[item_name].push(data[i + IP_index * 2 + 2]);
              sumPower += data[i + IP_index * 2 + 2];
            }
            logItem.TotalPower.push(sumPower);
          } else if (data[i] == "T=") {
            // Temperature
            var sumtemp = 0;
            var noValid = 0;
            for (
              let IP_index = 0;
              IP_index < this.logData[index].IPs.length;
              IP_index++
            ) {
              let item_name = "temp" + this.logData[index].IPs[IP_index].key;
              let tmp = data[i + IP_index + 1];
              logItem[item_name].push(tmp);
              if (tmp > 0) noValid++;
              sumtemp += tmp;
            }
            logItem.tempAVG.push(sumtemp / noValid);
          } else if (data[i] == "Time=") {
            // RunningTime, "Time=" CPU.Avg CPU.Max GPU.Avg GPU.Max
            logItem.RenderTime_Avg_Preparing.push(data[i + 1]);
            logItem.RenderTime_Max_Preparing.push(data[i + 2]);
            logItem.RenderTime_Avg_CPU.push(data[i + 3]);
            logItem.RenderTime_Max_CPU.push(data[i + 4]);
            logItem.RenderTime_Avg_V2S.push(data[i + 5]);
            logItem.RenderTime_Max_V2S.push(data[i + 6]);
            logItem.RenderTime_Avg_GPU.push(data[i + 7]);
            logItem.RenderTime_Max_GPU.push(data[i + 8]);
            logItem.RenderTime_Avg_V2F.push(data[i + 9]);
            logItem.RenderTime_Max_V2F.push(data[i + 10]);
            if (this.logData[index].freqCnt < 6) {
              logItem.cpuwl_ratio.push(data[i + 11]);
              logItem.heavypre.push(data[i + 11]);
            }
          } else if (data[i] == "BC/BS/LT=") {
            // BW Bpc, BW GBps, Latency
            logItem.SYS_BW_kbpc.push(data[i + 1] / 1000);
            logItem.SYS_BW_Gbps.push(data[i + 2] / 1000);
            logItem.SYS_Lat_cyc.push(data[i + 3]);
            if (this.logData[index].freqCnt >= 6) {
              logItem.SYS_Lat_ns.push(data[i + 4]);
              logItem.CPU_BW_Gbps.push(data[i + 5]);
              logItem.CPU_Lat_cyc.push(data[i + 6]);
              logItem.CPU_Lat_ns.push(data[i + 7]);
              logItem.GPU_BW_Gbps.push(data[i + 8]);
              logItem.GPU_Lat_cyc.push(data[i + 9]);
              logItem.GPU_Lat_ns.push(data[i + 10]);
            }
          } else if (data[i] == "e=") {
            // Event Id
            logItem.Event.push(data[i + 1]);
          } else if (data[i] == "MODE=") {
            // HP LP ELP
            if (this.logData[index].freqCnt < 6) {
              var hp = 0;
              var lp = 0;
              var elp = 0;
              var normalp = 0;

              if (data[i + 2]) hp = 1;
              else if (data[i + 3] % 2 == 1) lp = 1;
              else if (data[i + 3] % 2 == 0) elp = 1;
              else normalp = 1;

              logItem.HP.push(hp);
              logItem.LP.push(lp);
              logItem.ELP.push(elp);
              logItem.NormalP.push(normalp);
            }
          } else if (data[i] == "BTL=") {
            // Bottleneck
            logItem.bottleneckCPU.push(data[i + 1]);
            logItem.bottleneckGPU.push(data[i + 2]);
            logItem.bottleneckMIF_BW.push(data[i + 3]);
            logItem.bottleneckMIF_lat.push(data[i + 4]);
          } else if (data[i] == "PWR=") {
            //CPUPWR, GPUPWR, GPU/CPU_Ratio, CPU heavy(>=700mW), GPU heavy(>=400mW, >=70%)
            logItem.PWRCPUPowerHeavy.push(data[i + 4]);
            logItem.PWRCPUPowerHeavy.push(data[i + 5]);
          }
        }

        if (this.logData[index].freqCnt == 5) {
          // Workload
          var cpuWorkload =
            (logItem.fMID.slice(-1)[0] *
              logItem.RenderTime_Avg_CPU.slice(-1)[0]) /
            1000;
          logItem.CPUWorkload.push(cpuWorkload);
          var gpuWorkload =
            (logItem.fGPU.slice(-1)[0] *
              logItem.RenderTime_Avg_GPU.slice(-1)[0]) /
            1000;
          logItem.GPUWorkload.push(gpuWorkload);
          // MIFLatency(ns)
          var maxfreq = 0;
          for (
            let IP_index = 0;
            IP_index < this.logData[index].IPs.length - 2;
            IP_index++
          ) {
            let item_name = "f" + this.logData[index].IPs[IP_index].key;
            let curfreq = logItem[item_name].slice(-1)[0];
            if (maxfreq < curfreq) {
              maxfreq = curfreq;
            }
          }
          let miflatencyns =
            (logItem.SYS_Lat_cyc.slice(-1)[0] * 1000000) / maxfreq;
          if (isNaN(miflatencyns)) miflatencyns = 0;
          logItem.MIFLatencyns.push(miflatencyns);
        }
        // FrameDrop
        for (var IP_index in this.logData[index].IPs) {
          let item_name = "FrameDrop" + this.logData[index].IPs[IP_index].key;
          let f_item_name = "f" + this.logData[index].IPs[IP_index].key;
          let fmax_item_name = "fMax" + this.logData[index].IPs[IP_index].key;

          let current_freq = logItem[f_item_name].slice(-1)[0];
          let max_freq = logItem[fmax_item_name].slice(-1)[0];

          var framedrop_value = 0;
          if (
            logItem.CurrentFPS.slice(-1)[0] < 60 &&
            current_freq >= max_freq
          ) {
            framedrop_value = 1;
          }
          logItem[item_name].push(framedrop_value);
        }
      }
      // Average Item
      var averagedata = {};
      for (var [testitem, values] of Object.entries(logItem)) {
        if (this.logItem[testitem].calc == "average")
          averagedata[testitem] = this.calculateAverage(values);
        else if (this.logItem[testitem].calc == "percentage")
          averagedata[testitem] = this.convertToPercentageByArray(values);
        else averagedata[testitem] = this.calculateAverage(values);
      }
      // Frequency Time in State
      var frequency_TIS = {};
      for (
        let IP_index = 0;
        IP_index < this.logData[index].IPs.length;
        IP_index++
      ) {
        IP_index = parseInt(IP_index);
        var item_name = this.logData[index].IPs[IP_index].key;
        frequency_TIS[item_name] = {
          name: this.logData[index].IPs[IP_index].name,
          frequency: {},
        };

        let ip = this.frequency.find(x => this.IP_DICT[x.name] === item_name);

        for (const freq of ip.values.filter(x => x)) {
          frequency_TIS[item_name].frequency[freq] = { index: 0, per: 0 };
        }
        var cur_item_name = "f" + this.logData[index].IPs[IP_index].key;
        var freq_entries = Object.entries(frequency_TIS[item_name].frequency);
        for (
          let cur_freq_index = 0;
          cur_freq_index < logItem[cur_item_name].length;
          cur_freq_index++
        ) {
          let freq;
          for ([freq] of freq_entries) {
            let freq_MHz = Number(freq) / 1000;
            if (freq_MHz >= Number(logItem[cur_item_name][cur_freq_index])) {
              frequency_TIS[item_name].frequency[freq].index++;
              break;
            }
            if (freq_entries[freq_entries.length - 1][0] === freq)
              frequency_TIS[item_name].frequency[freq].index++;
          }
        }
        freq_entries = Object.entries(frequency_TIS[item_name].frequency);
        for (let [freq, cnt] of freq_entries) {
          var freq_percentage = this.convertToPercentageByCount(
            cnt.index,
            logItem[cur_item_name].length,
          );
          frequency_TIS[item_name].frequency[freq].per = freq_percentage;
        }
      }
      // Render Time in State
      var start_render_TIS = 8;
      var max_render_TIS = 40;
      var render_TIS_cpu = [];
      var render_TIS_gpu = [];
      var render_TIS = {
        fpstime: [],
        time: [],
        cpustatus: [],
        gpustatus: [],
        cpuindex: [],
        gpuindex: [],
      };
      let log_length = logItem.RenderTime_Avg_CPU.length;
      for (let i = 0; i <= max_render_TIS; i++)
        render_TIS_cpu[i] = render_TIS_gpu[i] = 0;
      for (let s = 0; s < log_length; s++) {
        // time_cpuavg / time_gpuavg
        var cpuidx = Math.floor(
          logItem.RenderTime_Avg_CPU[s] - start_render_TIS,
        );
        var gpuidx = Math.floor(
          logItem.RenderTime_Avg_GPU[s] - start_render_TIS,
        );
        if (cpuidx < 0) cpuidx = 0;
        if (gpuidx < 0) gpuidx = 0;
        if (cpuidx > max_render_TIS) cpuidx = max_render_TIS;
        if (gpuidx > max_render_TIS) gpuidx = max_render_TIS;
        render_TIS_cpu[cpuidx]++;
        render_TIS_gpu[gpuidx]++;
      }
      for (let i = start_render_TIS == 0 ? 1 : 0; i <= max_render_TIS; i++) {
        render_TIS.fpstime.push(
          this.round(10000 / ((i + start_render_TIS) * 10 + 5)),
        );
        render_TIS.time.push(start_render_TIS + i);
        render_TIS.cpustatus.push(
          this.round((render_TIS_cpu[i] / log_length) * 100),
        );
        render_TIS.gpustatus.push(
          this.round((render_TIS_gpu[i] / log_length) * 100),
        );
        render_TIS.cpuindex.push(render_TIS_cpu[i]);
        render_TIS.gpuindex.push(render_TIS_gpu[i]);
      }

      //

      this.logData[index].logItem = logItem;
      this.logData[index].averagedata = averagedata;
      this.logData[index].frequency_TIS = frequency_TIS;
      this.logData[index].render_TIS = render_TIS;
    },
    convertform(index) {
      var colors = [
        "#ED7C31",
        "#0070C0",
        "#FF0000",
        "#70AD47",
        "#00AC8C",
        "#CF76a3",
        "#C278AE",
      ];
      var colors2 = [
        "#E67672",
        "#0079A7",
        "#E65C5E",
        "#B0A734",
        "#60A25B",
        "#C278AE",
        "#CF7486",
      ];
      // Rendertime in state
      var render_TIS = this.logData[index].render_TIS;
      this.chartItems[index].render_TIS = {
        title: "Render Time in State",
        chartType: "bar",
        xAxis: {
          categories: render_TIS.fpstime,
          title: {
            text: "단위(fps)",
          },
        },
        yAxis: {
          min: 0,
          title: {
            text: "단위(%)",
          },
        },
        tooltip: {
          valueSuffix: " %",
        },
        plotOptions: {
          bar: {
            dataLabels: {
              // enabled: true
            },
            // pointInterval: 10,
          },
        },
        legend: {
          enabled: true,
          layout: "vertical",
          align: "left",
          verticalAlign: "middle",
          width: 100,
        },
        series: [
          {
            name: "CPU",
            data: render_TIS.cpustatus.map(value => this.round(value)),
          },
          {
            name: "GPU",
            data: render_TIS.gpustatus.map(value => this.round(value)),
          },
        ],
      };
      // frequency time in state
      this.chartItems[index].frequency_tis = [];
      var frequency_TIS = this.logData[index].frequency_TIS;
      var frequency_TIS_entries = Object.entries(frequency_TIS);
      for (let i = 0; i < frequency_TIS_entries.length; i++) {
        let ip_name = frequency_TIS_entries[i][1].name;
        let ip_tis = frequency_TIS_entries[i][1].frequency;
        var frequency_per_value = Object.values(ip_tis).map(item => item.per);
        this.chartItems[index].frequency_tis.push({
          title: `${ip_name} Time In State`,
          chartType: "bar",
          xAxis: {
            categories: Object.keys(ip_tis),
            title: {
              text: "단위(Hz)",
            },
          },
          yAxis: {
            min: 0,
            title: {
              text: "단위(%)",
            },
          },
          tooltip: {
            valueSuffix: " %",
          },
          plotOptions: {
            bar: {
              dataLabels: {
                // enabled: true
              },
              // pointInterval: 10,
            },
          },
          legend: {
            enabled: true,
            layout: "vertical",
            align: "left",
            verticalAlign: "middle",
            width: 100,
          },
          series: [
            {
              name: ip_name,
              data: Object.values(frequency_per_value).map(value =>
                this.round(value),
              ),
            },
          ],
        });
      }
      // average item
      var unit_list = {
        frequency: {
          title: "Frequency",
          type: "boxplot",
          x: "",
          y: "단위(Hz)",
          tooltip: " %",
          format: `{point.y:.1f} %`,
        },
        estpower: {
          title: "Estimated Power",
          type: "column",
          x: "단위(mW)",
          y: "",
          tooltip: " mW",
          format: "{point.y:.f} mW",
        },
        temp: {
          title: "Temperature",
          type: "column",
          x: "단위(°C)",
          y: "",
          tooltip: " °C",
          format: "{point.y:.1f} °C",
        },
        performancemode: {
          title: "Performance Mode",
          type: "pie",
          x: "단위(%)",
          y: "",
          tooltip: " %",
          format: "{point.percentage:.1f} %",
        },
        pwr: {
          title: "Moving Window Average Power",
          type: "column",
          x: "단위(%)",
          y: "",
          tooltip: " ",
          format: "{point.y:.1f} %",
        },
        workload: {
          title: "Workload",
          type: "column",
          x: "",
          y: "",
          tooltip: "",
          format: "{point.y:.1f} mW",
        },
        bottleneck: {
          title: "Bottleneck",
          type: "column",
          x: "단위(%)",
          y: "",
          tooltip: " %",
          format: "{point.y:.1f} %",
        },
        margin: {
          title: "Margin",
          type: "column",
          x: "단위(%)",
          y: "",
          tooltip: " %",
          format: "{point.y:.1f} %",
        },
        miflatency: {
          title: "MIF Latency",
          type: "column",
          x: "ABS:us CPC:cpc)",
          y: "",
          tooltip: "",
        },
        bw: {
          title: "Bandwidth",
          type: "column",
          x: "BPS / GBPS",
          y: "",
          tooltip: "",
          format: "{point.y:.2f}",
        },
        framedrop: {
          title: "The Number of Frame Drops",
          type: "column",
          x: "단위(%)",
          y: "",
          tooltip: " %",
          format: "{point.y:.1f} %",
        },
        // fps: {},
      };
      this.chartItems[index].averageItem = [];
      var averagedata = this.logData[index].averagedata;
      for (var i in unit_list) {
        var avg_series = [];
        if (i === "frequency") {
          var freq_categories = [];
          var freq_data = { freq: [], ratio: [] };
          for (var j of this.logData[index].IPs) {
            var cur_freq = averagedata["f" + j.key];
            var min_freq = averagedata["fMin" + j.key];
            var max_freq = averagedata["fMax" + j.key];
            var active_ratio = averagedata["ActiveRatio" + j.key];

            freq_categories.push(j.name);
            freq_data.freq.push([
              min_freq,
              cur_freq,
              cur_freq,
              cur_freq,
              max_freq,
            ]);
            freq_data.ratio.push([active_ratio]);
          }
          this.chartItems[index].averageItem.push({
            title: unit_list[i].title,
            chartType: unit_list[i].type,
            xAxis: {
              categories: freq_categories,
              title: {
                text: unit_list[i].x,
              },
            },
            yAxis: [
              {
                min: 0,
                title: {
                  text: unit_list[i].y,
                },
              },
              {
                min: 0,
                opposite: true,
                title: {
                  text: "Active Ratio(단위: %)",
                },
              },
            ],
            tooltip: {
              // valueSuffix: unit_list[i].tooltip,
              // format: unit_list[i].format,
              enabled: true,
              shared: true,
            },
            legend: {
              enabled: false,
              layout: "vertical",
              align: "left",
              verticalAlign: "middle",
              width: 100,
            },
            plotOptions: {
              series: {
                borderWidth: 0,
                dataLabels: {
                  enabled: true,
                  format: unit_list[i].format,
                  // format: "{point.percentage:f} %",
                },
              },
            },
            series: [
              {
                name: "Freq",
                type: "boxplot",
                data: freq_data.freq.map(row =>
                  row.map(value => this.round(value)),
                ),
                lineWidth: 5,
                dataLabels: {
                  enabled: true,
                  format: "{point.y:.1f} Hz",
                },
                tooltip: {
                  enabled: true,
                  shared: true,
                },
              },
              {
                name: "ratio",
                type: "scatter",
                yAxis: 1,
                data: freq_data.ratio.map(value => this.round(value)),
              },
            ],
          });
          continue;
        } else if (i === "estpower") {
          // var avg_series_item = {y:0, name:"Title", color: ""}
          for (let j of this.logData[index].IPs) {
            // DynamicPower
            avg_series.push({
              name: "Dynamic " + j.name,
              y: this.round(averagedata["Dynamic" + j.key]),
              colors: colors[this.logData[index].IPs.indexOf(j)],
            });
            // leakagePower
            avg_series.push({
              name: "Leakage " + j.name,
              y: this.round(averagedata["Leakage" + j.key]),
              colors: colors2[this.logData[index].IPs.indexOf(j)],
            });
          }
          avg_series.push({
            name: "Total Power",
            y: this.round(averagedata["TotalPower"]),
            colors: colors.slice(-1)[0],
          });
        } else if (i === "temp") {
          for (let j of this.logData[index].IPs) {
            avg_series.push({
              name: j.name,
              y: this.round(averagedata["temp" + j.key]),
              colors: colors[this.logData[index].IPs.indexOf(j)],
            });
          }
          avg_series.push({
            name: "Average",
            y: this.round(averagedata["tempAVG"]),
            colors: colors[this.logData[index].IPs.length],
          });
        } else if (i === "performancemode") {
          //HP LP ELP NormalP
          let items = ["HP", "LP", "ELP", "NormalP"];
          for (let j of items) {
            avg_series.push({
              name: j,
              y: this.round(averagedata[j]),
              colors: colors[items.indexOf(j)],
            });
          }
        } else if (i === "pwr") {
          let items = ["PWRCPUPowerHeavy", "PWRGPUPowerHeavy"];
          for (let j of items) {
            avg_series.push({
              name: j.substring(3),
              y: this.round(averagedata[j]),
              colors: colors[items.indexOf(j)],
            });
          }
        } else if (i === "workload") {
          let items = ["CPUWorkload", "GPUWorkload"];
          for (let j of items) {
            avg_series.push({
              name: j.substring(0, 3),
              y: this.round(averagedata[j]),
              colors: colors[items.indexOf(j)],
            });
          }
        } else if (i === "bottleneck") {
          let items = [
            "bottleneckCPU",
            "bottleneckGPU",
            "bottleneckMIF_BW",
            "bottleneckMIF_lat",
          ];
          for (let j of items) {
            avg_series.push({
              name: j.substring(10).replace("_", "-"),
              y: this.round(averagedata[j]),
              colors: colors[items.indexOf(j)],
            });
          }
        } else if (i === "margin") {
          for (let j of this.logData[index].IPs) {
            avg_series.push({
              name: j.name,
              y: this.round(averagedata["Margin" + j.key]),
              colors: colors[this.logData[index].IPs.indexOf(j)],
            });
          }
        } else if (i == "miflatency") {
          this.chartItems[index].averageItem.push({
            title: unit_list[i].title,
            chartType: unit_list[i].type,
            xAxis: {
              // categories: ["ABS", "CPC"],
              crosshair: true,
            },
            yAxis: [
              {
                min: 0,
                title: {
                  text: "MIF Latency(ns)",
                },
              },
              {
                min: 0,
                title: {
                  text: "MIF Latency(cpc)",
                },
                opposite: true,
              },
            ],
            tooltip: {
              shared: true,
            },
            legend: {
              enabled: true,
              layout: "vertical",
              align: "left",
              verticalAlign: "middle",
              width: 100,
            },
            plotOptions: {
              series: {
                borderWidth: 0,
                dataLabels: {
                  enabled: true,
                  format: unit_list[i].format,
                  // format: "{point.percentage:f} %",
                },
              },
            },
            series: [
              {
                name: "MIF Latency(ns)",
                type: "column",
                colorByPoint: true,
                data: [this.round(averagedata["MIFLatencyns"])],
                colors: [colors[0]],
                tooltip: {
                  valueSuffix: " ns",
                },
                dataLabels: {
                  enabled: true,
                  format: "{point.y:.1f} ns",
                },
              },
              {
                name: "MIF Latency(cpc)",
                type: "column",
                colorByPoint: true,
                data: [NaN, this.round(averagedata["SYS_Lat_cyc"])],
                colors: [NaN, colors[1]],
                tooltip: {
                  valueSuffix: " cpc",
                },
                dataLabels: {
                  enabled: true,
                  format: "{point.y:.1f} cpc",
                },
                yAxis: 1,
              },
            ],
          });
          continue;
        } else if (i === "bw") {
          let items = [
            { name: "BW (Bps)", item: "SYS_BW_kbpc" },
            { name: "BW (GBps)", item: "SYS_BW_Gbps" },
          ];
          for (let j of items) {
            avg_series.push({
              name: j.name,
              y: this.round(averagedata[j.item]),
              colors: colors[items.indexOf(j)],
            });
          }
        } else if (i === "framedrop") {
          for (let j of this.logData[index].IPs) {
            avg_series.push({
              name: j.name,
              y: this.round(averagedata["FrameDrop" + j.key]),
              colors: colors[this.logData[index].IPs.indexOf(j)],
            });
          }
        } else if (i === "fps") {
          let items = ["TargetFPS", "CurrentFPS"];
          for (let j of items) {
            avg_series.push({
              name: j,
              y: this.round(averagedata[j]),
              colors: colors[items.indexOf(j)],
            });
          }
        }
        this.chartItems[index].averageItem.push({
          title: unit_list[i].title,
          chartType: unit_list[i].type,
          xAxis: {
            type: "category",
            title: {
              text: unit_list[i].x,
            },
          },
          yAxis: [
            {
              min: 0,
              title: {
                text: unit_list[i].y,
              },
            },
          ],
          tooltip: {
            valueSuffix: unit_list[i].tooltip,
            // format: unit_list[i].format,
          },
          legend: {
            enabled: true,
            layout: "vertical",
            align: "left",
            verticalAlign: "middle",
            width: 100,
          },
          plotOptions: {
            series: {
              borderWidth: 0,
              dataLabels: {
                enabled: true,
                format: unit_list[i].format,
                // format: "{point.percentage:f} %",
              },
            },
          },
          series: [
            {
              name: i.toUpperCase(),
              colorByPoint: true,
              data: avg_series,
              colors: colors,
            },
          ],
        });
      }
    },
    convertvetable(index) {
      var averagedata = this.logData[index].averagedata;
      var frequency_TIS = this.logData[index].frequency_TIS;
      var render_TIS = this.logData[index].render_TIS;
      // Table item ( for Sequence )
      var tableItem = {
        "FPS": {},
        "Render Time in State": {},
        "Little Time in State": {},
        "Middle Time in State": {},
        "Middle LF Time in State": {},
        "Middle HF Time in State": {},
        "Big Time in State": {},
        "GPU Time in State": {},
        "MIF Time in State": {},
        "Frequency": {},
        "Estimated Power": {},
        "Temperature": {},
        "Performance Mode": {},
        "Heaviness by Moving Window Average Power": {},
        "Workload": {},
        "Bottleneck": {},
        "Margin": {},
        "MIF Latency": {},
        "BW (Bandwidth)": {},
        "The Number of Frame Drops by bottleneck": {},
      };
      var unit_list = {
        "FPS": [
          { name: "TargetFPS", item: "TargetFPS" },
          { name: "CurrentFPS", item: "CurrentFPS" },
        ],
        "Render Time in State": [
          { name: "FPS", item: "fpstime" },
          { name: "CPU(index)", item: "cpuindex" },
          { name: "CPU(%)", item: "cpustatus" },
          { name: "GPU(index)", item: "gpuindex" },
          { name: "GPU(%)", item: "gpustatus" },
        ],
        "Frequency Time in State": [
          { name: "Frequency(Hz)", item: "frequency" },
          { name: "index", item: "index" },
          { name: "per", item: "per" },
        ],
        "Frequency": [
          {
            name: "Name",
            data: ["Current(MHz)", "Min(MHz)", "Max(MHz)", "Active Ratio(%)"],
          },
        ],
        "Estimated Power": [{ name: "Name", data: ["단위(mW)"] }],
        "Temperature": [{ name: "Name", data: ["단위(°C)"] }],
        "Performance Mode": [{ name: "Name", data: ["단위(%)"] }],
        "Heaviness by Moving Window Average Power": [
          { name: "Name", data: ["단위(%)"] },
        ],
        "Workload": [{ name: "Name", data: ["단위(kilo cycle)"] }],
        "Bottleneck": [{ name: "Name", data: ["단위(%)"] }],
        "Margin": [{ name: "Name", data: ["단위(%)"] }],
        "MIF Latency": [{ name: "Name", data: ["단위(ns/cpc)"] }],
        "BW (Bandwidth)": [{ name: "Name", data: ["단위(Bps/GBps)"] }],
        "The Number of Frame Drops by bottleneck": [
          { name: "Name", data: ["단위(%)"] },
        ],
      };
      for (let i in unit_list) {
        if (i === "Frequency") {
          for (let j of this.logData[index].IPs) {
            unit_list.Frequency.push({
              name: j.name,
              item: [
                "f" + j.key,
                "fMin" + j.key,
                "fMax" + j.key,
                "ActiveRatio" + j.key,
              ],
            });
          }
        } else if (i === "Estimated Power") {
          for (let j of this.logData[index].IPs) {
            // DynamicPower
            unit_list["Estimated Power"].push({
              name: "Dynamic " + j.name,
              item: "Dynamic" + j.key,
            });
            // leakagePower
            unit_list["Estimated Power"].push({
              name: "Leakage " + j.name,
              item: "Leakage" + j.key,
            });
          }
          unit_list["Estimated Power"].push({
            name: "Total Power",
            item: "TotalPower",
          });
        } else if (i === "Temperature") {
          for (let j of this.logData[index].IPs) {
            unit_list["Temperature"].push({
              name: j.name,
              item: "temp" + j.key,
            });
          }
          unit_list["Temperature"].push({
            name: "Average",
            item: "tempAVG",
          });
        } else if (i === "Performance Mode") {
          //HP LP ELP NormalP
          let items = ["HP", "LP", "ELP", "NormalP"];
          for (let j of items) {
            unit_list["Performance Mode"].push({
              name: j,
              item: j,
            });
          }
        } else if (i === "Heaviness by Moving Window Average Power") {
          let items = ["PWRCPUPowerHeavy", "PWRGPUPowerHeavy"];
          for (let j of items) {
            unit_list["Heaviness by Moving Window Average Power"].push({
              name: j.substring(3),
              item: j,
            });
          }
        } else if (i === "Workload") {
          let items = ["CPUWorkload", "GPUWorkload"];
          for (let j of items) {
            unit_list.Workload.push({
              name: j.substring(0, 3),
              item: j,
            });
          }
        } else if (i === "Bottleneck") {
          let items = [
            "bottleneckCPU",
            "bottleneckGPU",
            "bottleneckMIF_BW",
            "bottleneckMIF_lat",
          ];
          for (let j of items) {
            unit_list.Bottleneck.push({
              name: j.substring(10).replace("_", "-"),
              item: j,
            });
          }
        } else if (i === "Margin") {
          for (let j of this.logData[index].IPs) {
            unit_list.Margin.push({
              name: j.name,
              item: "Margin" + j.key,
            });
          }
        } else if (i == "MIF Latency") {
          unit_list["MIF Latency"].push({
            name: "MIF Latency(ns)",
            item: "MIFLatencyns",
          });
          unit_list["MIF Latency"].push({
            name: "MIF Latency(cpc)",
            item: "SYS_Lat_cyc",
          });
        } else if (i === "BW (Bandwidth)") {
          unit_list["BW (Bandwidth)"].push({
            name: "BW (Bps)",
            item: "SYS_BW_kbpc",
          });
          unit_list["BW (Bandwidth)"].push({
            name: "BW (GBps)",
            item: "SYS_BW_Gbps",
          });
        } else if (i === "The Number of Frame Drops by bottleneck") {
          for (let j of this.logData[index].IPs) {
            unit_list["The Number of Frame Drops by bottleneck"].push({
              name: j.name,
              item: "FrameDrop" + j.key,
            });
          }
        }
      }
      let unit_list_entries = Object.entries(unit_list);
      // let pass_list = ["Render Time in State", "Little Time in State", "Middle Time in State", "Middle LF Time in State", "Middle HF Time in State","BIG Time in State", "GPU Time in State", "MIF Time in State", "Frequency"];
      let pass_list = [
        "Render Time in State",
        "Frequency Time in State",
        "Frequency",
      ];
      for (let [key, value] of unit_list_entries) {
        if (pass_list.includes(key)) continue;
        let columns = [];
        let tableDatas = [];
        let tableData = {};
        for (let column of value) {
          columns.push({
            field: column.name.toLowerCase(),
            key: column.name.toLowerCase(),
            title: column.name,
            align: "center",
          });
          if (column.item) {
            tableData[column.name.toLowerCase()] = this.round(
              averagedata[column.item],
            );
          } else if (column.data) {
            tableData[column.name.toLowerCase()] = column.data[0];
          }
        }
        tableDatas.push(tableData);
        tableItem[key] = {
          columns: columns,
          tableData: tableDatas,
        };
      }
      // Frequency
      let columns = [];
      let tableDatas = [];
      for (let column of unit_list["Frequency"]) {
        columns.push({
          field: column.name.toLowerCase(),
          key: column.name.toLowerCase(),
          title: column.name,
          align: "center",
        });
      }
      for (let i = 0; i < 4; i++) {
        let tableData = {};
        tableData["name"] = unit_list["Frequency"][0].data[i];
        for (let j of this.logData[index].IPs) {
          let ip_index = this.logData[index].IPs.indexOf(j) + 1;
          let value = this.round(
            averagedata[unit_list["Frequency"][ip_index].item[i]],
          );
          tableData[j.name.toLowerCase()] = value;
        }
        tableDatas.push(tableData);
      }
      tableItem["Frequency"] = {
        columns: columns,
        tableData: tableDatas,
      };
      //Render Time in State
      columns = [];
      tableDatas = [];
      for (let column of unit_list["Render Time in State"]) {
        columns.push({
          field: column.item.toLowerCase(),
          key: column.item.toLowerCase(),
          title: column.name,
          align: "center",
        });
      }
      for (let i = 0; i < render_TIS.fpstime.length; i++) {
        let tableData = {};
        for (let column of unit_list["Render Time in State"]) {
          tableData[column.item] = this.round(render_TIS[column.item][i]);
        }
        tableDatas.push(tableData);
      }
      tableItem["Render Time in State"] = {
        columns: columns,
        tableData: tableDatas,
      };
      // Frequency Time in State
      for (let j of this.logData[index].IPs) {
        let columns = [];
        let tableDatas = [];
        for (let column of unit_list["Frequency Time in State"]) {
          columns.push({
            field: column.item.toLowerCase(),
            key: column.item.toLowerCase(),
            title: column.name,
            align: "center",
          });
        }
        for (let [key, value] of Object.entries(
          frequency_TIS[j.key].frequency,
        )) {
          let tableData = {
            frequency: key,
            index: this.round(value.index),
            per: this.round(value.per),
          };
          tableDatas.push(tableData);
        }
        tableItem[j.name + " Time in State"] = {
          columns: columns,
          tableData: tableDatas,
        };
      }
      for (let j in tableItem) {
        if (Object.keys(tableItem[j]).length === 0) {
          delete tableItem[j];
        }
      }
      this.tableItems[index] = tableItem;
    },
    round(number) {
      return Math.round(number * 10) / 10;
    },
    calculateAverage(arr) {
      if (arr.length === 0) {
        return 0;
      }

      var sum = 0;
      for (var i = 0; i < arr.length; i++) {
        sum += arr[i];
      }

      var average = sum / arr.length;
      return average;
    },
    convertToPercentageByArray(arr) {
      if (arr.length === 0) {
        return 0; // 빈 배열일 경우 0을 반환
      }

      var count = 0;

      for (var i = 0; i < arr.length; i++) {
        if (arr[i] === 1) {
          count++;
        }
      }

      if (count === 0) {
        return 0;
      }

      var ratio = (count / arr.length) * 100;
      return ratio;
    },
    convertToPercentageByCount(cnt, total) {
      if (total === 0) {
        return 0;
      }

      var percentage = (cnt / total) * 100;
      return percentage;
    },
    showInfoMenu() {
      this.$bvModal.show("info-modal");
    },
    hideMenu() {
      this.$nextTick(() => {
        this.$bvModal.hide("info-modal");
      });
    },
  },
};
</script>

<style>
.info-box {
  background-color: white;
  padding: 10px;
  border: 1px solid rgb(230, 230, 230);
  margin-bottom: 10px;
}
</style>

<style scoped>
.sub-title {
  font-weight: bold;
  font-size: x-large;
  margin-bottom: 3px;
}

.between-group {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.between-title {
  margin-bottom: 0px;
}

.between-checkbox {
  margin-right: 10px;
}

.sticky {
  position: -webkit-sticky;
  position: sticky;
  top: 0;
  background-color: white;
  z-index: 1002;
}

.rawdata-title-group {
  display: flex;
  justify-content: flex-start;
}

.rawdata-title-group h4 {
  margin-bottom: 0rem;
  margin-right: 0.5rem;
}

.footer {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  height: 50px;
  padding-top: 8px;
  color: white;
}

.footer-content {
  background-color: rgb(25, 56, 87);
  margin-left: 10px;
  margin-right: 10px;
  padding: 20px;
  height: 100%;
  /* vertical-align: middle; */
  align-items: center;
  display: flex;
  justify-content: flex-start;
}

.footer-content a {
  color: white;
  margin-right: 30px;
}

.pointer-cursor {
  cursor: pointer;
  margin-right: 30px;
}

.calculator {
  cursor: pointer;
  margin-right: 30px;
}

.list-group-item {
  padding: 0.4rem 1.25rem;
  user-select: none;
}

.wrap {
  width: 100%;
  /* height: 700px; */
  /* max-height: 800px; */
  overflow: auto;
  margin-top: 10px;
  margin-bottom: 20px;
}

.ini-spinner-mask {
  background-color: rgba(255, 255, 255, 0.7);
}

h4 {
  font-weight: bold;
}

table {
  margin-bottom: 0px;
}

thead {
  background-color: rgb(240, 240, 240);
}

a {
  color: black;
}

.menu-link:hover {
  cursor: pointer;
}

.table-box-sub {
  /* padding: 10px; */
  /* outline: 2px solid rgb(220, 220, 220); */
  margin-bottom: 24px;
}

.chart-box-sub {
  padding: 10px;
  border: 1px solid rgb(220, 220, 220);
  margin-bottom: 20px;
}

.analayzer-box {
  padding: 10px;
}
.info-group {
  color: #000000;
  border: 1px solid rgb(220, 220, 220);
  padding: 5px;
  background: rgb(222, 225, 230);
  cursor: pointer;
  margin-left: 10px;
}

.info_class {
  font-size: 100%;
}

.tooltip_test {
  position: relative;
  margin-bottom: 0.5rem;
  font-weight: 500;
  line-height: 1.2;
  margin-top: 0;
  font-size: 1.25rem;
  margin-block-start: 1.67em;
  margin-block-end: 1.67em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
  display: block;
}

.tooltip_test .tooltiptext_test {
  visibility: hidden;
  width: 1000px;
  background-color: #555;
  color: #fff;
  /* text-align: center; */
  border-radius: 6px;
  padding: 5px 5px;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 3%;
  margin-left: -60px;
  opacity: 0;
  transition: opacity 0.3s;
}

.tooltip_test .tooltiptext_test::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 3%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

.tooltip_test:hover .tooltiptext_test {
  visibility: visible;
  opacity: 1;
}
</style>
