<template>
  <div>
    <div class="sub-title-group">
      <div class="row">
        <span class="sub-title">Issue List</span>
        <b-form-select
          size="sm"
          v-model="selectedIssueType"
          :options="issueTypes"
          @change="changeCombobox"></b-form-select>
        <b-form-select
          size="sm"
          v-model="selectedProject"
          :options="projects"
          @change="changeCombobox"
          v-show="selectedIssueType == 'soc'"></b-form-select>
        <b-form-select
          size="sm"
          v-model="selectedIssueStatus"
          :options="issueStatus"
          @change="changeCombobox"></b-form-select>
        <b-button
          size="sm"
          variant="secondary"
          v-b-toggle.summary-collapse
          :class="summaryVisible ? null : 'collapsed'"
          :aria-expanded="summaryVisible ? 'true' : 'false'"
          @click="summaryVisible = !summaryVisible"
          >Summary{{ summaryVisible ? " ∧" : " ∨" }}</b-button
        >
      </div>
      <div class="row">
        <div id="reportrange">
          <font-awesome-icon icon="calendar" style="margin-right: 5px" />&nbsp;
          <span></span>
        </div>
        <b-input-group size="sm">
          <b-form-input
            v-model="searchText"
            @keyup.enter="searchIssue"
            placeholder="Search issue number or title"></b-form-input>
          <template #append>
            <b-button
              class="btn-search"
              variant="outline-secondary"
              @click="searchIssue"
              ><font-awesome-icon icon="search"
            /></b-button>
          </template>
        </b-input-group>
        <div class="sub-title-btn-group">
          <b-button
            variant="outline-secondary"
            size="sm"
            v-b-tooltip.hover.bottom
            title="Assignee"
            @click="showAssigneeModal">
            <font-awesome-icon icon="user-friends" />
          </b-button>
          <!--<b-button variant="outline-secondary" size="sm" v-b-tooltip.hover.bottom title="Update" @click="updateData">
            <font-awesome-icon icon="sync-alt" />
          </b-button> -->
          <b-button
            variant="outline-secondary"
            size="sm"
            v-b-tooltip.hover.bottom
            title="Export to Excel"
            @click="exportData">
            <font-awesome-icon icon="download" />
          </b-button>
        </div>
      </div>
    </div>
    <b-collapse id="summary-collapse">
      <hr />
      <div class="summary-box">
        <div class="summary-table">
          <ve-table
            id="status-container"
            :columns="summary.status.columns"
            :table-data="summary.status.data"
            :footer-data="summary.status.footerData" />
        </div>
        <div class="summary-box ml-3 mr-3" style="width: 30%">
          <div
            v-for="(assignees, index) in assigneeSummary"
            :key="index"
            style="width: 50%">
            <ve-table
              id="assignee-container"
              :columns="summary.assignees.columns"
              :table-data="assignees" />
          </div>
        </div>
        <div style="width: 55%">
          <highcharts :options="chartOptions"></highcharts>
        </div>
      </div>
      <hr />
    </b-collapse>
    <ve-table
      id="issue-container"
      :fixed-header="true"
      :columns="columns"
      :table-data="tableData"
      :row-style-option="rowStyleOption"
      :cell-style-option="cellStyleOption"
      :cell-selection-option="cellSelectionOption"
      :sort-option="sortOption"
      :expand-option="expandOption"
      row-key-field-name="id" />
    <div class="table-pagination">
      <ve-pagination
        :total="totalCount"
        :page-index="pageIndex"
        :page-size="pageSize"
        @on-page-number-change="pageNumberChange"
        @on-page-size-change="pageSizeChange" />
    </div>

    <add-assignee-modal ref="addAssigneeModal"></add-assignee-modal>
  </div>
</template>

<script>
import AddAssigneeModal from "@/components/modal/AddAssigneeModal.vue";
import moment from "moment";
import * as XLSX from "xlsx";
import { Chart } from "highcharts-vue";

const OPENED_STATUS = ["Open", "On-going"];
const ISSUE_TYPE = [
  { value: "all", text: "Page" },
  { value: "mx", text: "MX" },
  { value: "soc", text: "S.LSI" },
  { value: "sarc", text: "SARC" },
];

const ISSUE_STATUS = [
  { value: "all", text: "Status" },
  { value: "unassigned", text: "Not Assigned" },
  { value: "unupdated", text: "Not Updated" },
];

const ChildTableComp = {
  name: "ChildTableComp",
  template: `
  <table style="font-size: 13px; width: 100%;">
    <tr v-for="link in row">
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 3%;">-</td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 4%;">{{link.id}}</td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 5%;">
        <a class="issue-link" :href="'https://github.sec.samsung.net/SARC-MCD-AMD-GPU-Collaboration/Issue_Tracker/issues/' + link.mx_number" target="_blank">{{link.mx_number}}</a>
      </td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 7%;">{{link.plm_number}}</td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 7%;">
        <a class="issue-link" :href="'https://jira.slsi.samsungds.net/browse/' + link.soc_number" target="_blank">{{link.soc_number}}</a>
      </td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 7%;">
        <a class="issue-link" :href="'https://jira.sarc.samsung.com/browse/' + link.soc_number" target="_blank">{{link.sarc_number}}</a>
      </td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 5%;">{{link.status}}</td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 6%;">{{link.assignee}}</td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 7%;">{{link.created_at}}</td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: center; width: 7%;">{{link.updated_at}}</td>
      <td class="ve-table-body-td" style="font-size: 13px; text-align: left; width: 45%;" >{{link.title}}</td>
    </tr>
  </table>
  `,
  props: {
    id: Number,
    row: Array,
  },
};

export default {
  name: "IssueList",
  components: {
    AddAssigneeModal,
    highcharts: Chart,
  },
  data() {
    return {
      totalCount: 0,
      pageIndex: 1,
      pageSize: 20,
      rowStyleOption: {
        hoverHighlight: false,
        clickHighlight: false,
      },
      cellStyleOption: {
        bodyCellClass: ({ row }) => {
          if (row.status == "Open" && row.assignee == "MX") {
            return "bg-open-mx-issue";
          }
          var today = moment().subtract(7, "days").format("YYYY-MM-DD HH:mm");
          var updatedAt = moment(row.updated_at, "YY-MM-DD HH:mm").format(
            "YYYY-MM-DD HH:mm",
          );
          if (
            OPENED_STATUS.includes(row.status) &&
            moment(today).isAfter(updatedAt)
          ) {
            return "bg-open-none-update";
          }
        },
      },
      cellSelectionOption: {
        enable: false,
      },
      sortOption: {
        sortChange: params => {
          this.sortChange(params);
        },
      },
      expandOption: {
        trigger: "cell",
        expandable: ({ row }) => row.link.length > 0,
        render: ({ row }) => {
          return <ChildTableComp id={row.id} row={row.link} />;
        },
      },
      expandedCount: 0,
      columns: [
        {
          field: "",
          key: "expand",
          type: "expand",
          title: "",
          align: "center",
          width: "3%",
        },
        {
          field: "id",
          key: "id",
          title: "ID",
          width: "4%",
        },
        {
          field: "mx_number",
          key: "mx_number",
          title: "MCD #",
          width: "5%",
          renderBodyCell: ({ row, column }) => {
            const text = row[column.field];
            const href = `https://github.sec.samsung.net/SARC-MCD-AMD-GPU-Collaboration/Issue_Tracker/issues/${text}`;
            return (
              <a class="issue-link" href={href} target="_blank">
                {text}
              </a>
            );
          },
        },
        {
          field: "plm_number",
          key: "plm_number",
          title: "PLM #",
          width: "7%",
        },
        {
          field: "soc_number",
          key: "soc_number",
          title: "SOC #",
          width: "7%",
          renderBodyCell: ({ row, column }) => {
            const text = row[column.field];
            const href = `https://jira.slsi.samsungds.net/browse/${text}`;
            return (
              <a class="issue-link" href={href} target="_blank">
                {text}
              </a>
            );
          },
        },
        {
          field: "sarc_number",
          key: "sarc_number",
          title: "SARC #",
          width: "7%",
          renderBodyCell: ({ row, column }) => {
            const text = row[column.field];
            const href = ` https://jira.sarc.samsung.com/browse/${text}`;
            return (
              <a class="issue-link" href={href} target="_blank">
                {text}
              </a>
            );
          },
        },
        {
          field: "status",
          key: "status",
          title: "Status",
          width: "5%",
          filter: {
            filterList: [],
            isMultiple: true,
            filterConfirm: filterList => {
              this.searchData.status = filterList
                .filter(x => x.selected)
                .map(x => x.label);
              this.pageReset();
            },
            filterReset: () => {
              this.searchData.status = [];
              this.pageReset();
            },
          },
        },
        {
          field: "assignee",
          key: "assignee",
          title: "Assignee",
          width: "6%",
          filter: {
            filterList: [],
            isMultiple: true,
            filterConfirm: filterList => {
              this.searchData.assignees = filterList
                .filter(x => x.selected)
                .map(x => x.value);
              this.pageReset();
            },
            filterReset: () => {
              this.searchData.assignees = [];
              this.pageReset();
            },
            maxHeight: 500,
          },
          renderBodyCell: ({ row, column }) => {
            return (
              <span v-b-tooltip title={row.assignee_name}>
                {row[column.field]}
              </span>
            );
          },
        },
        {
          field: "created_at",
          key: "created_at",
          title: "Created At",
          width: "7%",
          sortBy: "",
        },
        {
          field: "updated_at",
          key: "updated_at",
          title: "Updated At",
          width: "7%",
          sortBy: "desc",
        },
        {
          field: "title",
          key: "title",
          title: "Issue Title",
          width: "45%",
          align: "left",
        },
      ],
      tableData: [],
      sourceData: [],
      searchText: "",
      searchData: {
        status: ["Open", "On-going"],
        assignees: [],
      },
      sort: {
        field: "updated_at",
        type: "desc",
      },
      projects: [
        {
          value: null,
          text: "Project",
        },
        {
          value: "SLSI_SOC",
          text: "SLSI_SOC",
        },
        {
          value: "Pamir(S5E9925)",
          text: "Pamir(S5E9925)",
        },
        {
          value: "Quadra(S5E9935)",
          text: "Quadra(S5E9935)",
        },
        {
          value: "Root(S5E9945)",
          text: "Root(S5E9945)",
        },
      ],
      selectedProject: null,
      issueTypes: ISSUE_TYPE,
      selectedIssueType: "all",
      issueStatus: ISSUE_STATUS,
      selectedIssueStatus: "all",
      loadingInstance: null,
      dateRange: [moment("1970-01-01"), moment()],
      options: {
        startDate: moment("1970-01-01"),
        endDate: moment(),
        ranges: {
          "Today": [moment(), moment()],
          "Last 7 Days": [
            moment().subtract(6, "days").startOf("day"),
            moment(),
          ],
          "Last 30 Days": [
            moment().subtract(29, "days").startOf("day"),
            moment(),
          ],
          "This Month": [moment().startOf("month"), moment().endOf("month")],
          "Last Month": [
            moment().subtract(1, "month").startOf("month"),
            moment().subtract(1, "month").endOf("month"),
          ],
          "All Day": [moment("1970-01-01"), moment()],
        },
      },
      summary: {
        assignees: {
          columns: [
            {
              field: "id",
              key: "id",
              title: "ID",
              renderBodyCell: ({ row, column }) => {
                return (
                  <span v-b-tooltip title={row.name}>
                    {row[column.field]}
                  </span>
                );
              },
            },
            {
              field: "count",
              key: "count",
              title: "Count",
            },
          ],
          data: [],
        },
        status: {
          columns: [
            {
              field: "status",
              key: "status",
              title: "Issue Status",
            },
            {
              field: "count",
              key: "count",
              title: "Count",
            },
          ],
          data: [],
          footerData: [],
        },
      },
      summaryVisible: false,
      chartOptions: {
        chart: {
          type: "column",
          width: 1003,
          borderWidth: 1,
          borderColor: "#E6E6E6",
          spacing: [20, 20, 25, 20],
        },
        title: {
          text: "담당자 별 이슈",
        },
        legend: {
          enabled: false,
        },
        credits: {
          enabled: false,
        },
        xAxis: {
          categories: [],
          labels: {
            rotation: -45,
            x: -5,
            y: 30,
          },
        },
        yAxis: {
          title: {
            text: "Issue Count",
          },
        },
        series: [
          {
            name: "Issue",
            data: [],
          },
        ],
      },
    };
  },
  computed: {
    assigneeSummary() {
      var tblLen = this.summary.assignees.data.length / 2;
      var data = [[], []];
      for (let i = 0; i < this.summary.assignees.data.length; i++) {
        var index = i < tblLen ? 0 : 1;
        data[index].push(this.summary.assignees.data[i]);
      }

      if (this.summary.assignees.data.length % 2 == 1) {
        data[1].push({ id: "", count: "" });
      }

      return data;
    },
  },
  async created() {
    this.pageReset();
    this.getSummary();
  },
  async mounted() {
    const { data: assignees } = await this.$http.get(`/api/issues/assignees`);

    for (const assignee of assignees) {
      this.columns[7].filter.filterList.push({
        value: assignee.id,
        label: assignee.name,
        selected: true,
      });
    }

    const { data: status } = await this.$http.get(`/api/issues/status`);

    for (const sta of status) {
      this.columns[6].filter.filterList.push({
        value: sta,
        label: sta,
        selected: OPENED_STATUS.includes(sta),
      });
    }

    this.columns.push();

    // eslint-disable-next-line no-undef
    $("#reportrange").daterangepicker(this.options, this.changeDate);

    this.changeDate(this.options.startDate, this.options.endDate);
  },
  methods: {
    changeDate(start, end) {
      // eslint-disable-next-line no-undef
      $("#reportrange span").html(
        start.format("YYYY-MM-DD") + " - " + end.format("YYYY-MM-DD"),
      );

      this.dateRange[0] = start.format("YYYY-MM-DD");
      this.dateRange[1] = end.format("YYYY-MM-DD");

      this.pageReset();
      this.getSummary();
    },
    getIssues() {
      var body = {
        searchText: this.searchText,
        status: this.searchData.status,
        assignees: this.searchData.assignees,
        startDate: this.dateRange[0],
        endDate: this.dateRange[1],
        project: this.selectedProject,
        sortField: this.sort.field,
        sortType: this.sort.type,
        issueType: this.selectedIssueType,
        issueStatus: this.selectedIssueStatus,
      };

      this.$http
        .post(
          `/api/issues?page=${this.pageIndex}&pageSize=${this.pageSize}`,
          body,
        )
        .then(res => {
          this.totalCount = res.data.totalCount;
          this.sourceData = res.data.issueList;
          this.tableData = this.sourceData.slice(0);
        });
    },
    getSummary() {
      this.$http
        .get(
          `/api/issues/summary?project=${this.selectedProject}&issueType=${this.selectedIssueType}&issueStatus=${this.selectedIssueStatus}&startDate=${this.dateRange[0]}&endDate=${this.dateRange[1]}`,
        )
        .then(res => {
          this.summary.assignees.data = res.data.assignee;
          this.chartOptions.xAxis.categories = this.summary.assignees.data.map(
            x => x.id,
          );
          this.chartOptions.series[0].data = this.summary.assignees.data.map(
            x => x.count,
          );

          this.summary.status.data = res.data.status;
          this.summary.status.footerData = [
            {
              status: "Total",
              count: res.data.status.reduce((a, b) => a + b.count, 0),
            },
          ];
        });
    },
    pageReset() {
      this.pageIndex = 1;
      this.getIssues();
    },
    changeCombobox() {
      if (this.selectedIssueType !== 'soc') {
        this.selectedProject = null;
      }

      this.pageReset();
      this.getSummary();
    },
    pageNumberChange(pageIndex) {
      this.pageIndex = pageIndex;
      this.getIssues();
    },
    pageSizeChange(pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
      this.getIssues();
    },
    searchIssue() {
      this.pageIndex = 1;
      this.pageReset();
    },
    updateData() {
      var password = prompt("Enter Password : ");

      if (!password) {
        return;
      }

      if (password != "1234") {
        alert("Incorrect Password");
        return;
      }

      this.loadingInstance = this.$veLoading({
        fullscreen: true,
        name: "flow",
        color: "#205081",
        width: "100px",
        height: "100px",
      });

      this.loadingInstance.show();
      this.$http.get(`/api/issues`).then(() => {
        this.page = 1;
        this.pageSize = 20;
        this.pageReset();

        this.loadingInstance.close();
      });
    },
    showAssigneeModal() {
      this.$refs.addAssigneeModal.reset();
      this.$bvModal.show("add-assignee-modal");
    },
    exportData() {
      var body = {
        searchText: this.searchText,
        status: this.searchData.status,
        assignees: this.searchData.assignees,
        startDate: this.dateRange[0],
        endDate: this.dateRange[1],
        project: this.selectedProject,
        sortField: this.sort.field,
        sortType: this.sort.type,
        issueType: this.selectedIssueType,
      };

      this.$http.post(`/api/issues`, body).then(res => {
        var excelData = XLSX.utils.json_to_sheet(res.data.issueList);
        var workBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workBook, excelData, "Issues");
        XLSX.writeFile(workBook, "issues.xlsx");
      });
    },
    sortChange(params) {
      if (params.created_at) {
        this.sort.field = "created_at";
        this.sort.type = params.created_at;
      } else if (params.updated_at) {
        this.sort.field = "updated_at";
        this.sort.type = params.updated_at;
      }

      this.pageReset();
    },
  },
};
</script>

<style scoped>
.table-pagination {
  margin-top: 15px;
  text-align: right;
}

.input-group {
  width: auto;
}

.input-group > .form-control:not(:last-child) {
  width: 250px;
}

.input-group > .form-control:not(:first-child) {
  border-width: 1px 0px 1px 1px;
}

.input-group > .input-group-prepend > .custom-select {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.row {
  margin-right: 0px;
  margin-left: 0px;
}

#reportrange {
  display: block;
  cursor: pointer;
  height: calc(1.5em + 0.5rem + 2px);
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
  line-height: 1.5;
  font-weight: 400;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  margin-right: 0.3rem;
}

.row > .custom-select {
  width: auto;
  margin-right: 0.3rem;
}

.sub-title {
  margin-right: 1rem;
  padding-top: 0.1rem;
}

.summary-box {
  display: flex;
}

.summary-table {
  width: 15%;
}

.btn-outline-secondary {
  border-color: #ced4da;
}
</style>

<style>
.btn-search {
  border: solid #ced4da;
  border-width: 1px 1px 1px 0px;
}

.ve-table
  .ve-table-container
  table.ve-table-content
  tbody.ve-table-body
  tr.ve-table-body-tr {
  height: 30px;
}

.ve-table
  .ve-table-container
  table.ve-table-content
  tbody.ve-table-body
  tr.ve-table-body-tr
  td.ve-table-body-td {
  font-size: 13px;
  padding: 0.5rem;
}

.summary-box
  .ve-table
  .ve-table-container
  table.ve-table-content
  tbody.ve-table-body
  tr.ve-table-body-tr {
  height: 25px;
}

.summary-box
  .ve-table
  .ve-table-container
  table.ve-table-content
  tbody.ve-table-body
  tr.ve-table-body-tr
  td.ve-table-body-td {
  font-size: 13px;
  padding: 0rem;
}

.ve-checkbox {
  margin-bottom: 0rem;
}

.ve-table
  .ve-table-container
  table.ve-table-content
  tbody.ve-table-body
  .ve-table-expand-tr
  .ve-table-expand-td-content {
  padding: 0px;
}

.ve-table
  .ve-table-container
  table.ve-table-content
  tbody.ve-table-body
  .ve-table-body-tr
  .ve-table-body-td.ve-table-cell-selection {
  border: none;
  border-bottom: 1px solid #eee;
}

.issue-link {
  color: #000000d9;
}

.bg-open-mx-issue {
  background: rgb(255, 242, 204) !important;
}

.bg-open-none-update {
  background: rgb(255, 209, 209) !important;
}
</style>
