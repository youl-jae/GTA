<template>
  <div style="display: flex; justify-content: center; padding-bottom: 10rem">
    <div style="width: 500px">
      <h3 style="text-align: center; margin-top: 2rem; margin-bottom: 2rem">
        Login
      </h3>
      <div style="margin-bottom: 2rem">
        <b-form-group label="Knox ID">
          <b-form-input type="text" v-model="knoxId"></b-form-input>
        </b-form-group>
        <b-form-group label="Password">
          <b-form-input
            type="password"
            v-model="password"
            @keyup.enter="login"></b-form-input>
        </b-form-group>
      </div>
      <b-button style="width: 100%; margin-bottom: 1rem" @click="login"
        >Login</b-button
      >
      <div style="display: flex; justify-content: flex-end">
        <a class="text-link" @click="showSignUpModal">Create account</a>
      </div>
    </div>
    <sign-up-modal ref="signUpModal"></sign-up-modal>
  </div>
</template>

<script>
import SignUpModal from "@/components/modal/SignUpModal.vue";

export default {
  name: "LoginModal",
  components: {
    SignUpModal,
  },
  data() {
    return {
      knoxId: "",
      password: "",
    };
  },
  methods: {
    login() {
      const data = {
        id: this.knoxId,
        pw: this.password,
      };

      this.$http
        .post("/api/login", data)
        .then(res => {
          alert("Login !");
          this.$store.commit("login", res.data);
          this.$router.go(-1);
        })
        .catch(err => {
          alert(err.response.data);
        });
    },
    showSignUpModal() {
      this.$refs.signUpModal.init();
      this.$bvModal.show("signUpModal");
    },
  },
};
</script>
