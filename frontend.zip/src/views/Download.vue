<template>
  <div id="download">
    <div class="sub-title-group">
      <span class="sub-title">Download</span>
    </div>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>SSWA</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <div class="group">
              <span>SSWA</span>
              <b-button
                class="title-button"
                variant="outline-secondary"
                size="sm"
                :href="`http://12.36.165.61:3000/api/downloads/sswa`"
                ><font-awesome-icon icon="download"
              /></b-button>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>APK</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(apk, index) in apks" :key="index">
          <td>
            <div class="group">
              <span>{{ apk }}</span>
              <b-button
                class="title-button"
                variant="outline-secondary"
                size="sm"
                :href="`http://12.36.165.61:3000/api/downloads/${apk}`"
                ><font-awesome-icon icon="download"
              /></b-button>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: "DownloadAPK",
  data() {
    return {
      apks: [],
    };
  },
  created() {
    this.$http.get(`api/downloads/apk`).then(res => {
      this.apks = res.data;
    });
  },
  methods: {},
};
</script>

<style scoped>
#download table {
  font-size: 14px;
}

#download th,
td {
  padding: 0.5rem;
}

.group {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.btn {
  font-size: 12px;
}
</style>
