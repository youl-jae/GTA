<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">{{ title }}</span>
      <div class="sub-title-btn-group">
        <b-button
          v-show="comparisonId"
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Edit comparison"
          @click="clickEditBtn">
          <font-awesome-icon icon="pencil-alt" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          :title="comparisonId ? 'Save test order' : 'Save to comparison'"
          @click="clickSaveBtn">
          <font-awesome-icon icon="save" />
        </b-button>
      </div>
    </div>

    <div style="overflow-x: auto; margin-bottom: 1rem">
      <table
        class="table table-sm table-bordered table-container test-table"
        style="margin-bottom: 0rem">
        <thead>
          <tr>
            <th style="width: 220px">Test ID</th>
            <th
              v-for="(test, index) in testData"
              :key="index + 't'"
              :style="testData.length > 10 ? 'width: 149px;' : 'width: auto;'">
              {{ test.id }}
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(column, index) in testColumns" :key="index + 'tc'">
            <th>{{ column.text }}</th>
            <td v-for="(test, index) in testData" :key="index + 'td'">
              <router-link
                v-if="column.field === 'title'"
                :to="{
                  name: 'TestScore',
                  params: { id: test.id },
                }"
                >{{ test.title }}</router-link
              >
              <a
                v-else-if="column.field === 'binary_quickbuild'"
                :href="test.binary_quickbuild"
                target="_blank"
                >{{ test.binary_quickbuild }}</a
              >
              <span v-else-if="column.field === 'chip'">
                <a
                  class="link-text"
                  style="cursor: pointer"
                  @click="showChipModal(test.chip_id)"
                  >{{ test[column.field] }}</a
                >
              </span>
              <span v-else>{{ test[column.field] }}</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-for="(group, groupIndex) in testGroup" :key="groupIndex + 'tg'">
      <score-table
        ref="refScoreTable"
        :group="group"
        :groupIndex="groupIndex"
        :comparisonId="Number(comparisonId)"
        :ticketId="ticketId"></score-table>
    </div>

    <comparison-modal
      ref="comparisonModal"
      :type="appType"
      @editComparison="editComparison"
      @updateAiagent="updateAiagent"></comparison-modal>

    <edit-title-modal
      ref="editTitleModal"
      @editTitle="editTestName"></edit-title-modal>
    <chip-info-modal ref="chipInfoModal"></chip-info-modal>
  </div>
</template>

<script>
import ChipInfoModal from "@/components/modal/ChipInfoModal.vue";
import ComparisonModal from "@/components/modal/ComparisonModal.vue";
import EditTitleModal from "@/components/modal/EditTitleModal.vue";
import ScoreTable from "@/components/ScoreTable.vue";

export default {
  name: "TestScoreComparison",
  components: {
    ComparisonModal,
    EditTitleModal,
    ScoreTable,
    ChipInfoModal,
  },
  props: {
    ticketId: Number,
  },
  data() {
    return {
      testId: null,
      comparisonId: null,
      title: "Test Information",
      note: null,
      testData: [],
      testGroup: [],
      testColumns: [
        {
          field: "date",
          text: "Date",
        },
        {
          field: "title",
          text: "Title",
        },
        {
          field: "project",
          text: "Project",
        },
        {
          field: "app",
          text: "App",
        },
        {
          field: "testcase",
          text: "Testcase",
        },
        {
          field: "board_type",
          text: "Board Type",
        },
        {
          field: "chip",
          text: "Chip",
        },
        {
          field: "bsp_type",
          text: "BSP Type",
        },
        {
          field: "binary_path",
          text: "Binary Path",
        },
        {
          field: "binary_type",
          text: "Binary Type",
        },
        {
          field: "binary_quickbuild",
          text: "Binary Quickbuild",
        },
        {
          field: "lib_path",
          text: "Lib Path",
        },
        {
          field: "length",
          text: "Length",
        },
        {
          field: "network",
          text: "Network",
        },
        {
          field: "environment",
          text: "Environment",
        },
        {
          field: "start_temp",
          text: "Start Temperature",
        },
        {
          field: "tester",
          text: "Tester",
        },
        {
          field: "condition_name",
          text: "Condition Name",
        },
        {
          field: "commands",
          text: "Commands",
        },
        {
          field: "etc",
          text: "ETC",
        },
      ],
      nameIndex: null,
      appType: "",
    };
  },
  async created() {
    this.testId = this.$route.query.id;

    if (!this.ticketId) {
      this.comparisonId = this.$route.params.id;
    }

    if (this.$route.name === "TicketInfo") {
      const res = await this.$http.get(
        `/api/tickets/${this.ticketId}/test-group`,
      );

      this.testGroup = res.data;
      this.testId = this.testGroup.map(x => x.testIdList).join(",");
    } else if (this.$route.name === "TestScoreComparisonById") {
      const res = await this.$http.get(
        `/api/comparisons/${this.comparisonId}/testid`,
      );

      this.testId = res.data.testid.join(",");
      this.title = res.data.title;
      this.note = res.data.note;

      this.testGroup.push({
        id: null,
        name: "Test Score",
        count: res.data.testid.length,
        testIdList: res.data.testid,
      });

      const res2 = await this.$http.get(
        `/api/comparisons/aiagent/${this.comparisonId}`,
      );

      if (res2.data.success) {
        const score = res2.data.data.score;
        const { patchesInfo, bufferRaw, bufferResult } = res2.data.files;

        const scoreTableRef = this.$refs.refScoreTable?.[0];

        scoreTableRef.visibleAi = true;
        await this.$nextTick();

        const aiAgentRef = scoreTableRef?.$refs?.refAiAgent;

        const scoreSliderRef = aiAgentRef?.$refs?.refscoreSlider;

        scoreTableRef.patchesInfo = patchesInfo;
        aiAgentRef.bufferRaw = bufferRaw;
        aiAgentRef.bufferResult = bufferResult;
        scoreSliderRef.score = score;

        aiAgentRef.applyLoadedData();
      }
    } else {
      const idList = this.testId.split(",");

      this.testGroup.push({
        id: null,
        name: "Test Score",
        count: idList.length,
        testIdList: idList,
      });
    }

    var testData = await this.$http.get(
      `/api/tests?id=${this.testId}&order=id`,
    );

    this.testData = testData.data.result;

    this.testData.forEach(test => {
      test.chip = `${test.chip} (${test.chipId})`;
    });

    if (this.testData.length > 0) {
      this.appType = this.testData[0].type;
    }
  },
  methods: {
    clickEditBtn() {
      this.$refs.comparisonModal.setValue(
        this.comparisonId,
        this.title,
        this.note,
      );
      this.$bvModal.show("comparisonModal");
    },
    clickSaveBtn() {
      if (this.comparisonId) {
        var body = {
          testid: this.testData.map(x => x.id),
        };

        this.$http
          .put(`/api/comparisons/${this.comparisonId}/sort`, body)
          .then(() => {
            this.updateAiagent(this.comparisonId);
            alert("Save!!");
          })
          .catch(err => {
            alert(err.message);
          });
      } else {
        this.$refs.comparisonModal.reset();
        this.$refs.comparisonModal.testIdList = this.testId.split(",");
        this.$bvModal.show("comparisonModal");
      }
    },
    editComparison() {
      if (this.$route.name === "TestScoreComparisonById") {
        this.title = this.$refs.comparisonModal.title;
        this.note = this.$refs.comparisonModal.note;
      } else {
        this.updateAiagent();
        this.$router.push({
          name: "TestScoreComparisonById",
          params: {
            id: this.comparisonId,
          },
        });
      }
    },
    async updateAiagent(comparisonId) {
      const scoreTableRef = this.$refs.refScoreTable?.[0];
      const aiAgentRef = scoreTableRef?.$refs?.refAiAgent;
      const scoreSliderRef = aiAgentRef?.$refs?.refscoreSlider;

      if (!aiAgentRef) {
        return;
      }

      const patchesInfo = scoreTableRef.patchesInfo;
      const bufferRaw = aiAgentRef.bufferRaw;
      const bufferResult = aiAgentRef.bufferResult;
      const score = scoreSliderRef.score;

      await this.$http
        .post(`/api/comparisons/aiagent/${comparisonId}`, {
          score,
          patchesInfo,
          bufferRaw,
          bufferResult,
        })
        .then(res => {
          if (res.data.success) {
            console.log("✅ AI Agent data saved successfully:", res.data);
          } else {
            console.error("❌ Failed to save AI Agent data:", res.data);
          }
        })
        .catch(err => {
          console.error("🚨 Server error while saving AI Agent data:", err);
        });
    },
    showNameEditModal(index, name) {
      this.nameIndex = index;
      this.$refs.editTitleModal.title = name;
      this.$bvModal.show("editTitleModal");
    },
    editTestName(e, name) {
      if (name == "") {
        alert("Title is empty !!");
        e.preventDefault();
      } else {
        var test = this.testData[this.nameIndex];
        test.name = name;

        this.$set(this.testData, this.nameIndex, test);
      }
    },
    showChipModal(chipId) {
      this.$refs.chipInfoModal.init(chipId);
      this.$bvModal.show("chipInfoModal");
    },
  },
};
</script>

<style scoped>
.test-name:hover {
  cursor: pointer;
  color: gray;
}
</style>
