<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">Comparison / Benchmark</span>
    </div>
    <benchmark-group-table ref="table" :rows="rows"></benchmark-group-table>
  </div>
</template>

<script>
import BenchmarkGroupTable from "@/components/BenchmarkGroupTable.vue";

export default {
  name: "BenchmarkComparisonList",
  components: {
    BenchmarkGroupTable,
  },
  data() {
    return {
      rows: [],
    };
  },
  created() {
    this.$http.get(`/api/comparisons?type=benchmark`).then(res => {
      for (const comparison of res.data) {
        this.rows.push({
          mode: "span",
          label: comparison.title,
          id: comparison.id,
          html: false,
          children: comparison.tests,
        });
      }
    });
  },
};
</script>
