<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">{{ title }}</span>
      <div class="sub-title-btn-group">
        <b-input-group size="sm">
          <b-form-input
            v-model="searchText"
            @keyup.enter="getTickets"
            placeholder="Search ticket title"></b-form-input>
          <template #append>
            <b-button
              class="btn-search"
              variant="outline-secondary"
              @click="getTickets"
              ><font-awesome-icon icon="search"
            /></b-button>
          </template>
        </b-input-group>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-show="
            !(this.isKpiTicket && !this.$store.getters.isBenchmarkKpiManager)
          "
          v-b-tooltip.hover.bottom
          title="Create"
          @click="createTicket">
          <font-awesome-icon icon="plus" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-show="this.$store.getters.isLogin"
          v-b-tooltip.hover.bottom
          title="Delete"
          @click="deleteTicket">
          <font-awesome-icon icon="trash-alt" />
        </b-button>
      </div>
    </div>
    <ve-table
      row-key-field-name="id"
      :columns="columns"
      :table-data="tableData"
      :cell-selection-option="cellSelectionOption"
      :event-custom-option="eventCustomOption"
      :checkbox-option="checkboxOption"
      :sort-option="sortOption" />
  </div>
</template>

<script>
import moment from "moment";

export default {
  name: "TicketList",
  data() {
    return {
      title: "Ticket",
      tableData: [],
      sourceData: [],
      rejectComment: null,
      favorite: false,
      selectedTicket: null,
      projects: [],
      cellSelectionOption: {
        enable: false,
      },
      eventCustomOption: {
        bodyCellEvents: ({ row, rowIndex }) => {
          return {
            click: event => {
              const colKey = event.srcElement.getAttribute("col-key");

              if (
                event.srcElement.className.includes("ve-checkbox-input") ||
                colKey === "is_favorite" ||
                colKey === "checkbox"
              ) {
                return;
              } else if (event.srcElement.className.includes("favorite")) {
                if (this.$store.getters.isBenchmarkKpiManager) {
                  this.$http.put(`/api/tickets/${row.id}/favorite`).then(() => {
                    this.tableData[rowIndex].is_favorite =
                      !this.tableData[rowIndex].is_favorite;
                  });
                } else {
                  alert(
                    "Only Benchmark KPI managers are allowed to set a KPI Ticket.",
                  );
                }
              } else {
                this.$router.push({
                  name: "TicketInfo",
                  params: { id: row.id },
                });
              }
            },
          };
        },
      },
      checkboxOption: {
        selectedRowKeys: [],
        selectedRowChange: ({ selectedRowKeys }) => {
          this.changeSelectedRowKeys(selectedRowKeys);
        },
        selectedAllChange: ({ selectedRowKeys }) => {
          this.changeSelectedRowKeys(selectedRowKeys);
        },
      },
      sortOption: {
        sortAlways: true,
        sortChange: params => {
          this.sortChange(params);
        },
      },
      columns: [
        {
          field: "is_favorite",
          key: "is_favorite",
          title: "",
          align: "left",
          width: "40",
          renderBodyCell: ({ row, column }) => {
            return (
              <span class="favorite">{row[column.field] == 1 ? "★" : "☆"}</span>
            );
          },
        },
        {
          field: "checkbox",
          key: "checkbox",
          title: "",
          type: "checkbox",
          width: "1%",
        },
        {
          field: "status",
          key: "status",
          title: "Status",
          width: "5%",
          filter: {
            filterList: [
              { value: "Request", label: "Request" },
              { value: "Approve", label: "Approve" },
              { value: "Reject", label: "Reject" },
              { value: "In progress", label: "In progress" },
              { value: "Complete", label: "Complete" },
            ],
            isMultiple: true,
            filterConfirm: filterList => {
              const labels = filterList
                .filter(x => x.selected)
                .map(x => x.label);
              this.filterData.status = labels;
            },
            filterReset: () => {
              this.filterData.status = [];
            },
          },
          renderBodyCell: ({ row, column }) => {
            return (
              <b-button
                style="width: 90px"
                size="sm"
                variant={this.$store.getters.statusColor(row[column.field])}>
                {row[column.field]}
              </b-button>
            );
          },
          headerClassName: "favorite-header",
        },
        {
          field: "id",
          key: "id",
          title: "ID",
          width: "3%",
        },
        {
          field: "title",
          key: "title",
          title: "Title",
          align: "left",
        },
        {
          field: "test_count",
          key: "test_count",
          title: "Test",
          width: "4%",
        },
        {
          field: "requester",
          key: "requester",
          title: "Requester",
          width: "8%",
          filter: {
            filterList: [],
            isMultiple: true,
            filterConfirm: filterList => {
              const values = filterList
                .filter(x => x.selected)
                .map(x => x.value);
              this.filterData.requester = values;
            },
            filterReset: () => {
              this.filterData.requester = [];
            },
            maxHeight: 500,
          },
        },
        {
          field: "tester",
          key: "tester",
          title: "Tester",
          width: "8%",
          filter: {
            filterList: [],
            isMultiple: true,
            filterConfirm: filterList => {
              const values = filterList
                .filter(x => x.selected)
                .map(x => x.value);
              this.filterData.tester = values;
            },
            filterReset: () => {
              this.filterData.tester = [];
            },
            maxHeight: 500,
          },
        },
        {
          field: "created_at",
          key: "created_at",
          title: "Created",
          width: "8%",
          renderBodyCell: ({ row, column }) => {
            const date = moment(
              row[column.field],
              "YYYY-MM-DD HH:mm:ss",
            ).format("YY-MM-DD HH:mm");
            return <span>{date}</span>;
          },
          sortBy: "",
        },
        {
          field: "updated_at",
          key: "updated_at",
          title: "Updated",
          width: "8%",
          renderBodyCell: ({ row, column }) => {
            const date = moment(
              row[column.field],
              "YYYY-MM-DD HH:mm:ss",
            ).format("YY-MM-DD HH:mm");
            return <span>{date}</span>;
          },
          sortBy: "desc",
        },
        {
          field: "action",
          key: "action",
          title: "Actions",
          width: "8%",
          renderBodyCell: ({ row, rowIndex }) => {
            return (
              <div style="display: flex; justify-content: center;">
                <span>
                  <b-button
                    class="action-btn"
                    style="margin-right: 0.5rem;"
                    size="sm"
                    disabled={
                      row.is_favorite == 1 ||
                      (!this.$store.getters.isBenchmarkKpiManager &&
                        row.requesterKnoxId !==
                          this.$store.state.userStore.knoxId)
                    }
                    on-click={() => this.updateTicket(rowIndex)}>
                    Update
                  </b-button>
                </span>
                <span>
                  <b-button
                    class="action-btn"
                    size="sm"
                    on-click={() => this.copyTicket(rowIndex)}>
                    Copy
                  </b-button>
                </span>
              </div>
            );
          },
        },
      ],
      ticketApi: "/api/tickets?favorite=0",
      isKpiTicket: false,
      searchText: "",
      filterData: {
        favorite: [],
        status: [],
        requester: [],
        tester: [],
      },
    };
  },
  watch: {
    filterData: {
      handler: function () {
        this.filter();
      },
      immediate: true,
      deep: true,
    },
  },
  mounted() {
    this.$http
      .get("/api/tickets/requesters")
      .then(res => {
        this.columns[6].filter.filterList = res.data.map(x => ({
          value: x.knox_id,
          label: x.name,
        }));
        this.columns.push();
      })
      .catch(err => {
        console.log(err);
      });

    this.$http
      .get("/api/tickets/testers")
      .then(res => {
        this.columns[7].filter.filterList = res.data.map(x => ({
          value: x.knox_id,
          label: x.name,
        }));
        this.columns.push();
      })
      .catch(err => {
        console.log(err);
      });
  },
  created() {
    if (this.$route.name === "KpiTicketList" || this.$route.name === "Home") {
      this.title = "KPI Ticket";
      this.ticketApi = "/api/tickets?favorite=1";
      this.isKpiTicket = true;
    } else if (this.$route.name === "MyTicketList") {
      this.title = "My Ticket";
      this.ticketApi = `/api/tickets?requester=${this.$store.state.userStore.userId}&tester=${this.$store.state.userStore.userId}`;
      this.columns[0].filter = {
        filterList: [
          { value: 1, label: "Favorite" },
          { value: 0, label: "UnFavorite" },
        ],
        isMultiple: true,
        filterConfirm: filterList => {
          const values = filterList.filter(x => x.selected).map(x => x.value);
          this.filterData.favorite = values;
        },
        filterReset: () => {
          this.filterData.favorite = [];
        },
      };
    }

    this.getTickets();
  },
  methods: {
    getTickets() {
      this.$http
        .get(this.ticketApi + `&search=${encodeURIComponent(this.searchText)}`)
        .then(res => {
          this.sourceData = res.data;
          this.tableData = this.sourceData.slice(0);
          this.filter();
          this.sortChange({
            updated_at: "desc",
          });
        })
        .catch(err => {
          console.log(err);
        });
    },
    createTicket() {
      this.$router.push({
        name: "CreateTicket",
      });
    },
    copyTicket(index) {
      this.$router.push({
        name: "CopyTicketById",
        params: { id: this.tableData[index].id },
      });
    },
    updateTicket(index) {
      this.$router.push({
        name: "UpdateTicketById",
        params: { id: this.tableData[index].id },
      });
    },
    deleteTicket() {
      if (this.checkboxOption.selectedRowKeys.length === 0) {
        alert("Please select tickets !!");
        return;
      }

      const requesterIdList = this.tableData
        .filter(x => this.checkboxOption.selectedRowKeys.includes(x.id))
        .map(x => x.requesterKnoxId);

      if (
        !this.$store.getters.isBenchmarkKpiManager &&
        requesterIdList.filter(x => x !== this.$store.state.userStore.knoxId)
          .length > 0
      ) {
        alert("You can't delete tickets requested by others.");
        return;
      }

      if (confirm("Are you sure continue to delete ticket?") == false) {
        return;
      }

      this.$http
        .delete(`/api/tickets/${this.checkboxOption.selectedRowKeys.join(",")}`)
        .then(() => {
          for (const id of this.checkboxOption.selectedRowKeys) {
            var idx = this.tableData.findIndex(x => x.id === id);

            if (idx != -1) {
              this.tableData.splice(idx, 1);
            }
          }

          this.checkboxOption.selectedRowKeys = [];
        });
    },
    changeSelectedRowKeys(keys) {
      this.checkboxOption.selectedRowKeys = keys;
    },
    filter() {
      const { favorite, status, requester, tester } = this.filterData;

      this.tableData = this.sourceData.filter(
        x =>
          (favorite.length === 0 || favorite.includes(x.is_favorite)) &&
          (status.length === 0 || status.includes(x.status)) &&
          (requester.length === 0 || requester.includes(x.requesterKnoxId)) &&
          (tester.length === 0 || tester.includes(x.testerKnoxId)),
      );
    },
    sortFunction(sort, a, b) {
      if (sort === "asc") {
        return a.localeCompare(b);
      } else if (sort === "desc") {
        return b.localeCompare(a);
      } else {
        return 0;
      }
    },
    sortChange(params) {
      if (params.created_at) {
        this.tableData.sort((a, b) => {
          return this.sortFunction(
            params.created_at,
            a.created_at,
            b.created_at,
          );
        });
      } else if (params.updated_at) {
        this.tableData.sort((a, b) => {
          return this.sortFunction(
            params.updated_at,
            a.updated_at,
            b.updated_at,
          );
        });
      }
    },
  },
};
</script>

<style scoped>
.favorite {
  color: #ff0000;
  cursor: pointer;
  font-size: 18px;
}

.sub-title-btn-group {
  display: flex;
}

.input-group-append {
  margin-left: -6px;
}

.input-group > .form-control:not(:last-child) {
  width: 200px;
  border-color: rgb(108, 117, 125);
}
</style>

<style>
.ve-dropdown-items-warpper .ve-dropdown-items-multiple .ve-checkbox {
  margin-bottom: 0rem;
}
</style>
