<template>
  <div>
    <vue-instant-loading-spinner ref="Spinner" color="#205081" />
    <div class="sub-title-group">
      <span class="sub-title">Power Viewer</span>
    </div>
    <div>
      <div style="margin-bottom: 10px">
        <div v-show="!hasId" class="custom-file" style="margin-bottom: 10px">
          <input
            type="file"
            class="custom-file-input"
            ref="inputDirectory"
            id="inputDirectory"
            webkitdirectory
            @change="readDirectory" />
          <label class="custom-file-label" for="inputDirectory"
            >Choose directory</label
          >
        </div>
        <table
          class="table table-bordered table-sm"
          style="margin-bottom: 0px; text-align: center">
          <thead>
            <tr>
              <th style="width: 10%">No</th>
              <th v-show="hasId">Test</th>
              <th>Log File</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(file, index) in fileList" :key="index">
              <td>{{ index + 1 }}</td>
              <td v-show="hasId">
                <a :href="'/#/benchmark/score/' + file.testId" target="_blank"
                  >{{ SCORE_PATH }}{{ file.testId }}</a
                >
              </td>
              <td>{{ file.path }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-for="(file, index) in fileList" :key="`power-viewer-${index}`">
        <power-viewer-graph
          @calculator="calculator"
          class="mt-3 mb-3"
          :ref="`power-viewer-graph`"
          :index="index"
          :title="file.name + '-P'"
          :series="file.p_series"
          :pointInterval="pointInterval"
          :yAxis="file.default_yAxis">
        </power-viewer-graph>
        <power-viewer-graph
          @calculator="calculator"
          class="mt-3 mb-3"
          :ref="`power-viewer-graph`"
          :index="index"
          :title="file.name + '-V'"
          :series="file.v_series"
          :pointInterval="pointInterval"
          :yAxis="file.v_yAxis">
        </power-viewer-graph>
        <power-viewer-graph
          @calculator="calculator"
          class="mt-3 mb-3"
          :ref="`power-viewer-graph`"
          :index="index"
          :title="file.name + '-I'"
          :series="file.i_series"
          :pointInterval="pointInterval"
          :yAxis="file.default_yAxis">
        </power-viewer-graph>
      </div>
      <b-modal id="calculator-modal" size="lg" :title="powerAvg.title">
        <div>
          Time : {{ powerAvg.time_min }}s ~ {{ powerAvg.time_max }}s (Length :
          {{ powerAvg.time_length }}s)
        </div>
        <div class="poweraverage">
          <ve-table :columns="powerAvg.columns" :table-data="powerAvg.data" />
        </div>
        <template #modal-footer>
          <b-button @click="copyToClipboard">Copy</b-button>
        </template>
      </b-modal>
    </div>
  </div>
</template>

<script>
import VueInstantLoadingSpinner from "vue-instant-loading-spinner";
import PowerViewerGraph from "../components/PowerViewerGraph.vue";

export default {
  name: "PowerProfiler",
  components: {
    PowerViewerGraph,
    VueInstantLoadingSpinner,
  },
  data() {
    return {
      SCORE_PATH: "http://g2.gta.samsungds.net/#/benchmark/score/",
      fileList: [],
      pointInterval: 100,
      dataFromChild: null,
      powerAvg: {
        title: "",
        time_min: "",
        time_max: "",
        time_length: "",
        columns: [
          {
            field: "Name",
            key: "a1",
            title: "Name",
            align: "center",
          },
          {
            field: "Voltage",
            key: "a2",
            title: "Voltage(V)",
            align: "center",
          },
          {
            field: "Current",
            key: "a3",
            title: "Current(mA)",
            align: "center",
          },
          {
            field: "Power",
            key: "a4",
            title: "Power(mW)",
            align: "center",
          },
        ],
        data: [],
      },
    };
  },
  computed: {
    hasId() {
      return this.$route.params.id;
    },
  },
  async mounted() {
    this.$refs.Spinner.show();

    if (this.hasId) {
      try {
        const idList = this.$route.params.id.split(",");

        for (let i = 0; i < idList.length; i++) {
          const res = await this.$http.get(`/api/testitems/${idList[i]}/power`);

          var names = res.data.fileName.split("\\");
          console.log(res.data);
          var file = {
            testId: res.data.testId,
            path: res.data.fileName,
            name: names[names.length - 1].split(".csv")[0],
            data: res.data.log,
            p_series: [],
            v_series: [],
            i_series: [],
            default_yAxis: [
              {
                min: 0,
                // max: 3500,
                tickInterval: 100,
                startOnTick: false,
                endOnTick: false,
                opposite: false,
                showLastLabel: true,
              },
            ],
            v_yAxis: [
              {
                min: 0,
                max: 5,
                tickInterval: 1,
                startOnTick: false,
                endOnTick: false,
                opposite: false,
                showLastLabel: true,
              },
            ],
          };

          this.parseLog(file);
        }
      } catch (err) {
        console.log(err);
      }
    }
    this.$refs.Spinner.hide();
  },
  methods: {
    calculator(index, min_num, max_num, length_num) {
      const reducer = (accumulator, curr) => accumulator + curr;
      const data = this.fileList[index];
      this.powerAvg.title = data["name"];
      this.powerAvg.time_min = min_num / 10;
      this.powerAvg.time_max = max_num / 10;
      this.powerAvg.time_length = length_num / 10;
      this.powerAvg.data.length = 0;
      for (const rail in data.p_series) {
        var rail_name = data.p_series[rail].name.slice(0, -2);
        var voltage_avg =
          data.v_series[rail].data.slice(min_num, max_num).reduce(reducer) /
          length_num;
        var current_avg =
          data.i_series[rail].data.slice(min_num, max_num).reduce(reducer) /
          length_num;
        var power_avg =
          data.p_series[rail].data.slice(min_num, max_num).reduce(reducer) /
          length_num;
        this.powerAvg.data.push({
          Name: rail_name,
          Voltage: voltage_avg,
          Current: current_avg,
          Power: power_avg,
        });
      }
      this.$bvModal.show("calculator-modal");
    },
    readDirectory() {
      const selectedFiles = this.$refs.inputDirectory.files;

      for (const file of selectedFiles) {
        const reader = new FileReader();
        reader.fileName = file.name.split(".")[0];
        reader.onload = this.readFile;
        reader.readAsText(file, "UTF-8");
      }
    },
    readFile(event) {
      var file = {
        path: event.target.fileName,
        name: event.target.fileName,
        data: event.target.result,
        v_series: [],
        i_series: [],
        p_series: [],
        v_yAxis: [
          {
            min: 0,
            max: 5,
            tickInterval: 1,
            startOnTick: false,
            endOnTick: false,
            opposite: false,
            showLastLabel: true,
          },
        ],
        default_yAxis: [
          {
            min: 0,
            // max: 3500,
            tickInterval: 100,
            startOnTick: false,
            endOnTick: false,
            opposite: false,
            showLastLabel: true,
          },
        ],
      };

      this.parseLog(file);
    },

    parseLog(file) {
      const result = file.data.split("\n").map(x => x.split(","));
      const data = result.slice(1);
      for (let i = 0; i < result[0].length; i++) {
        if (result[0][i].includes("-V")) {
          file.v_series.push({
            name: result[0][i],
            data: data.map(x => parseFloat(x[i])),
          });
        } else if (result[0][i].includes("-I")) {
          file.i_series.push({
            name: result[0][i],
            data: data.map(x => parseFloat(x[i])),
          });
        } else if (result[0][i].includes("-P")) {
          file.p_series.push({
            name: result[0][i],
            data: data.map(x => parseFloat(x[i])),
          });
        }
      }
      this.fileList.push(file);
    },
    copyToClipboard() {
      var selection = window.getSelection();
      var range = document.createRange();
      let test = document.getElementsByClassName("poweraverage");
      range.selectNodeContents(test[0]);
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand("copy");
      selection.removeAllRanges();
    },
  },
};
</script>

<style scoped>
thead {
  background-color: rgb(240, 240, 240);
}
</style>
