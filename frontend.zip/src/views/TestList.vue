<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">{{ title }}</span>
      <div class="sub-title-btn-group">
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Upload result"
          @click="uploadTest">
          <font-awesome-icon icon="plus" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Compare tests"
          @click="compareTests">
          <font-awesome-icon icon="exchange-alt" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Save to comparison"
          @click="showComparisonModal">
          <font-awesome-icon icon="save" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Delete test"
          @click="deleteTests">
          <font-awesome-icon icon="trash-alt" />
        </b-button>
      </div>
    </div>
    <div>
      <ve-table
        :columns="columns"
        :table-data="tableData"
        :cell-selection-option="cellSelectionOption"
        :event-custom-option="eventCustomOption"
        :checkbox-option="checkboxOption"
        row-key-field-name="id"></ve-table>
      <div class="table-pagination">
        <ve-pagination
          :total="totalCount"
          :page-index="pageIndex"
          :page-size="pageSize"
          @on-page-number-change="pageNumberChange"
          @on-page-size-change="pageSizeChange" />
      </div>
    </div>

    <comparison-modal ref="comparisonModal" :type="appType"></comparison-modal>
  </div>
</template>

<script>
import ComparisonModal from "@/components/modal/ComparisonModal.vue";

export default {
  name: "TestList",
  components: {
    ComparisonModal,
  },
  data() {
    return {
      appType: "Game",
      appId: null,
      title: null,
      favorite: false,
      selectedRowKeysCollection: [],
      checkboxOption: {
        selectedRowKeys: [],
        selectedRowChange: ({ row, isSelected }) => {
          this.changeSelectedRowKeys(row, isSelected);
        },
        selectedAllChange: ({ isSelected, selectedRowKeys }) => {
          this.changeSelectAll(isSelected, selectedRowKeys);
        },
      },
      cellSelectionOption: {
        enable: false,
      },
      eventCustomOption: {
        bodyRowEvents: ({ row, rowIndex }) => {
          return {
            click: event => {
              const colKey = event.srcElement.getAttribute("col-key");

              if (
                event.srcElement.className.includes("ve-checkbox-input") ||
                colKey === "is_favorite" ||
                colKey === "checkbox" ||
                colKey === "log"
              ) {
                return;
              } else if (event.srcElement.className.includes("favorite")) {
                this.$http.put(`/api/tests/${row.id}/favorite`).then(() => {
                  this.tableData[rowIndex].is_favorite =
                    !this.tableData[rowIndex].is_favorite;
                });
              } else if (event.srcElement.className.includes("amigo-icon")) {
                window.open(
                  `http://g2.gta.samsungds.net/#/log/${row.testitem_id}`,
                );
              } else if (
                event.srcElement.className.includes("gamebench-icon")
              ) {
                window.open(row.gamebench_url);
              } else if (
                event.srcElement.className.includes("quickperf-icon")
              ) {
                window.open(row.quickperf_url);
              } else {
                this.$router.push({
                  name: "TestScore",
                  params: {
                    id: row.id,
                  },
                });
              }
            },
          };
        },
      },
      columns: [
        {
          field: "is_favorite",
          key: "is_favorite",
          title: "",
          width: "1%",
          renderBodyCell: ({ row, column }) => {
            return (
              <span class="favorite">{row[column.field] == 1 ? "★" : "☆"}</span>
            );
          },
        },
        {
          field: "checkbox",
          key: "checkbox",
          title: "",
          type: "checkbox",
          width: "1%",
        },
        {
          field: "id",
          key: "id",
          title: "ID",
          width: "4%",
        },
        {
          field: "title",
          key: "title",
          title: "Title",
          width: "40%",
          align: "left",
        },
        {
          field: "project",
          key: "project",
          title: "Project",
          width: "4%",
        },
        {
          field: "app",
          key: "app",
          title: "App",
          width: "10%",
        },
        {
          field: "testcase",
          key: "testcase",
          title: "Testcase",
          width: "15%",
        },
        {
          field: "chip",
          key: "chip",
          title: "Chip",
          width: "10%",
        },
        {
          field: "length",
          key: "length",
          title: "Length",
          width: "4%",
        },
        {
          field: "average_fps",
          key: "average_fps",
          title: "FPS or Scores",
          width: "4%",
        },
        {
          field: "power",
          key: "power",
          title: "Power",
          width: "4%",
        },
        {
          field: "date",
          key: "date",
          title: "Date",
          width: "7%",
          renderBodyCell: ({ row, column }) => {
            return <span>{this.dateFormat(row[column.field])}</span>;
          },
        },
        {
          field: "tester",
          key: "tester",
          title: "Tester",
          width: "4%",
        },
        {
          field: "log",
          key: "log",
          title: "",
          width: "4%",
          renderBodyCell: ({ row }) => {
            return (
              <div class="log-field">
                <span v-show={row.amigo_log} class="log-icon amigo-icon">
                  A
                </span>
                <span
                  v-show={row.gamebench_url}
                  class="log-icon gamebench-icon">
                  G
                </span>
                <span
                  v-show={row.quickperf_url}
                  class="log-icon quickperf-icon">
                  Q
                </span>
              </div>
            );
          },
        },
      ],
      pageIndex: 1,
      pageSize: 20,
      totalCount: 0,
      tableData: [],
    };
  },
  created() {
    if (this.$route.name !== "Home") {
      this.appType = this.$route.name
        .replace("List", "")
        .replace("Favorite", "");
    }

    if (this.$route.name.includes("Favorite")) {
      this.favorite = true;
    }

    this.appId = this.$route.query.app ?? "";

    if (this.appId) {
      this.$http.get(`/api/apps/${this.appId}`).then(res => {
        this.title = res.data.name;
      });
    } else {
      this.title = this.appType;
    }

    const fpsOrScores = this.columns.find(x => x.title === "FPS or Scores");
    const title = this.columns.find(x => x.title === "Title");

    if (this.appType === "Game") {
      const colIndex = this.columns.findIndex(x => x.title === "Testcase");
      this.columns.splice(colIndex, 1);

      fpsOrScores.title = "FPS";
    } else if (this.appType === "Benchmark") {
      const colIndex = this.columns.findIndex(x => x.title === "Length");
      this.columns.splice(colIndex, 1);

      fpsOrScores.field = "fps";
      fpsOrScores.width = "7%";
      title.width = "35%";
    }
    this.getTests();
  },
  methods: {
    getTests() {
      this.$http
        .get(
          `/api/tests?type=${this.appType}&app=${this.appId}&favorite=${this.favorite}&page=${this.pageIndex}&perPage=${this.pageSize}`,
        )
        .then(res => {
          this.totalCount = res.data.totalCount;
          this.tableData = res.data.result;
          this.resetSelectedRowKeys();
        });
    },
    pageNumberChange(pageIndex) {
      this.pageIndex = pageIndex;
      this.getTests();
    },
    pageSizeChange(pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
      this.getTests();
    },
    changeSelectedRowKeys(row, isSelected) {
      const rowKey = row.id;

      if (isSelected) {
        this.checkboxOption.selectedRowKeys.push(rowKey);
        this.selectedRowKeysCollection.push(rowKey);
      } else {
        const index = this.checkboxOption.selectedRowKeys.indexOf(rowKey);
        this.checkboxOption.selectedRowKeys.splice(index, 1);
        this.selectedRowKeysCollection.splice(index, 1);
      }
    },
    changeSelectAll(isSelected, selectedRowKeys) {
      this.checkboxOption.selectedRowKeys = selectedRowKeys;

      if (isSelected) {
        this.selectedRowKeysCollection =
          this.selectedRowKeysCollection.concat(selectedRowKeys);
      } else {
        this.tableData.forEach(item => {
          const index = this.selectedRowKeysCollection.indexOf(item.id);
          if (index > -1) {
            this.selectedRowKeysCollection.splice(index, 1);
          }
        });
      }
    },
    resetSelectedRowKeys() {
      this.checkboxOption.selectedRowKeys = [];

      const selectedRowKeysCollection = this.selectedRowKeysCollection;

      if (selectedRowKeysCollection.length) {
        this.tableData.forEach(item => {
          if (selectedRowKeysCollection.indexOf(item.id) > -1) {
            this.checkboxOption.selectedRowKeys.push(item.id);
          }
        });
      }
    },
    uploadTest() {
      this.$router.push({
        name: "UploadTest",
        params: {
          appType: this.appType,
        },
      });
    },
    compareTests() {
      this.$router.push({
        name: "TestScoreComparison",
        query: {
          id: this.selectedRowKeysCollection.join(","),
        },
      });
    },
    showComparisonModal() {
      if (this.selectedRowKeysCollection.length === 0) {
        alert("Select test to save as a comparison.");
        return;
      }

      this.$refs.comparisonModal.reset();
      this.$refs.comparisonModal.testIdList = this.selectedRowKeysCollection;

      this.$bvModal.show("comparisonModal");
    },
    async deleteTests() {
      const count = this.selectedRowKeysCollection.length;

      if (count === 0) {
        alert("Select test to delete.");
        return;
      }

      if (confirm(`Do you want to delete ${count} tests?`) == false) {
        return;
      }

      for (const id of this.selectedRowKeysCollection) {
        await this.$http.delete(`/api/tests/${id}`);
      }

      this.checkboxOption.selectedRowKeys = [];
      this.selectedRowKeysCollection = [];

      this.getTests();
    },
    dateFormat(datetime) {
      if (this.appType === "Benchmark") {
        return datetime.substring(0, 16);
      } else {
        return datetime.substring(0, 10);
      }
    },
  },
};
</script>

<style>
.favorite {
  color: #ffc000;
  cursor: pointer;
  font-size: 18px;
}

.log-field {
  display: flex;
  justify-content: center;
  padding-right: 0.5rem;
}

.log-icon {
  color: white;
  font-weight: bold;
  width: 16px;
  height: 16px;
  line-height: 1;
  cursor: pointer;
}

.amigo-icon {
  background: rgb(0, 112, 192, 0.8);
}

.gamebench-icon {
  background: rgb(255, 122, 18, 0.8);
}

.quickperf-icon {
  background: rgb(99, 198, 71, 0.8);
}

.table-pagination {
  margin-top: 20px;
  text-align: right;
}

.ve-table-body-td label {
  margin-bottom: 0px;
}

.ve-table-header-th label {
  margin-bottom: 0px;
}
</style>
