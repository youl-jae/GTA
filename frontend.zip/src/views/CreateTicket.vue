<template>
  <div class="container" style="padding-top: 0.5rem">
    <div
      id="ticket-information"
      style="display: flex; justify-content: space-between">
      <h5>Ticket Information</h5>
      <b-form-checkbox
        v-model="isFavoriteMode"
        name="favorite-button"
        switch
        v-show="this.$store.getters.isBenchmarkKpiManager">
        KPI Ticket
      </b-form-checkbox>
    </div>
    <hr />
    <b-form-group label="Title *" label-size="sm">
      <b-form-input size="sm" v-model="ticket.title"></b-form-input>
    </b-form-group>
    <div class="row">
      <b-form-group label="Requester *" label-size="sm" class="col-xl-6">
        <b-form-input
          size="sm"
          v-model="requesterText"
          :disabled="true"></b-form-input>
      </b-form-group>
      <b-form-group label="Tester" label-size="sm" class="col-xl-6">
        <b-form-select
          size="sm"
          v-model="ticket.tester"
          :options="users"></b-form-select>
      </b-form-group>
    </div>
    <b-form-group label="Outdata" label-size="sm">
      <b-form-checkbox-group
        size="sm"
        v-model="ticket.outdata"
        :options="outdatas"></b-form-checkbox-group>
    </b-form-group>
    <b-form-group label="Description" label-size="sm">
      <b-form-textarea
        rows="5"
        size="sm"
        v-model="ticket.description"
        placeholder="Purpose
--------------------------------
Base Image: T00000
JIRA Number: GFXAPP-000"></b-form-textarea>
    </b-form-group>
    <div style="display: flex; justify-content: space-between">
      <h5 style="margin-bottom: 0rem">Test List *</h5>
      <div>
        <b-button size="sm" style="margin-right: 0.5rem" @click="clickAddTest"
          ><b-icon icon="plus-lg" scale="0.7" /> Add</b-button
        >
        <b-button
          size="sm"
          style="margin-right: 0.5rem"
          @click="clickUpdateTest"
          ><b-icon icon="pencil" scale="0.7" /> Update</b-button
        >
        <b-button
          size="sm"
          style="margin-right: 0.5rem"
          @click="clickDeleteTest"
          ><b-icon icon="trash" scale="0.7" /> Delete</b-button
        >
        <b-button size="sm" @click="clickCopyTest"
          ><b-icon icon="files" scale="0.7" /> Copy</b-button
        >
      </div>
    </div>
    <hr />
    <ve-table
      style="height: 300px; margin-bottom: 2rem"
      row-key-field-name="no"
      fixed-header
      :max-height="300"
      :columns="columns"
      :table-data="tableData"
      :checkbox-option="checkboxOption"
      :expand-option="expandOption" />
    <hr />
    <div style="display: flex; justify-content: flex-end; margin-bottom: 1rem">
      <b-button size="sm" variant="primary" @click="addTicket"
        ><b-icon icon="check2" />
        {{ isTicketAddMode ? "Add Ticket" : "Update Ticket" }}</b-button
      >
    </div>
    <div id="test-information" v-show="visibleTest">
      <div style="display: flex; justify-content: space-between">
        <h5 style="margin-bottom: 0rem">Test Information</h5>
      </div>
      <hr />
      <div class="row">
        <h6 class="col-xl-2">Group</h6>
        <div class="col-xl-10">
          <b-form-group label="Name" label-size="sm">
            <b-form-input
              size="sm"
              v-model="test.group"
              :disabled="disabled.group"></b-form-input>
          </b-form-group>
        </div>
      </div>
      <hr />
      <div class="row">
        <h6 class="col-xl-2">Chip</h6>
        <div class="col-xl-10">
          <b-form-group label="Project" label-size="sm">
            <b-form-select
              size="sm"
              v-model="test.projectId"
              :options="projects"
              @change="changeProject"
              :disabled="disabled.projectId"></b-form-select>
          </b-form-group>
          <b-form-group label="Revision Number" label-size="sm">
            <b-form-radio-group
              v-model="test.revisionNumber"
              :options="revisionNumbers"
              size="sm"
              :disabled="disabled.revisionNumber"></b-form-radio-group>
          </b-form-group>
          <div style="font-size: 0.875rem; margin-bottom: 0.5rem">
            <div style="padding-bottom: calc(0.25rem + 1px)">
              <span class="col-form-label-sm">Chip ID </span>
              <a class="link-text" style="cursor: pointer" @click="showAddChip"
                >+</a
              >
            </div>
            <b-form-select
              rows="4"
              size="sm"
              v-model="test.chipId"
              :options="chips"
              :disabled="disabled.chipId"></b-form-select>
          </div>
          <b-form-group label="Board Type" label-size="sm">
            <b-form-select
              rows="4"
              size="sm"
              v-model="test.boardType"
              :options="boardTypes"
              :disabled="disabled.boardType"></b-form-select>
          </b-form-group>
        </div>
      </div>
      <hr />
      <div class="row">
        <h6 class="col-xl-2">BSP</h6>
        <div class="col-xl-10">
          <b-form-group
            label="BSP Type"
            label-size="sm"
            style="margin-right: 2rem">
            <b-form-radio-group
              size="sm"
              v-model="test.bspType"
              :options="bspTypes"
              :disabled="disabled.bspType"></b-form-radio-group>
          </b-form-group>
          <div style="font-size: 0.875rem; margin-bottom: 1rem">
            <div
              class="row"
              style="padding-bottom: calc(0.25rem + 1px); margin-left: 0px">
              <span style="margin-right: 1rem">BSP Binary</span>
              <b-form-group label-size="sm" style="margin-bottom: 0px">
                <b-form-radio-group
                  size="sm"
                  v-model="test.binaryType"
                  :options="binaryTypes"
                  :disabled="disabled.binaryType"></b-form-radio-group>
              </b-form-group>
            </div>
            <b-input-group
              id="input-path"
              prepend="Path"
              size="sm"
              style="margin-bottom: 0.5rem">
              <b-form-input
                size="sm"
                v-model="test.binaryPath"
                :disabled="disabled.binaryPath"
                placeholder="file path"></b-form-input>
            </b-input-group>
            <b-input-group prepend="Quickbuild" size="sm">
              <b-form-input
                size="sm"
                v-model="test.binaryQuickbuild"
                :disabled="disabled.binaryQuickbuild"
                placeholder="Quickbuild URL"></b-form-input>
            </b-input-group>
          </div>
          <div style="font-size: 0.875rem; margin-bottom: 0.5rem">
            <div style="padding-bottom: calc(0.25rem + 1px)">
              <span class="col-form-label-sm">Lib </span>
              <a class="link-text" style="cursor: pointer" @click="addLib">+</a>
            </div>
            <b-input-group
              id="lib-path"
              prepend="Path"
              size="sm"
              v-for="(lib, index) in test.libPath"
              :key="index + 'lib'">
              <b-form-input
                placeholder="push.bat"
                v-model="test.libPath[index]"></b-form-input>
              <b-input-group-append>
                <b-button variant="secondary" @click="removeLib(index)"
                  ><b-icon icon="x"
                /></b-button>
              </b-input-group-append>
            </b-input-group>
          </div>
        </div>
      </div>
      <hr />
      <div class="row">
        <h6 class="col-xl-2">ETC</h6>
        <div class="col-xl-10">
          <b-form-group label="Start Temperature" label-size="sm">
            <b-input-group size="sm" append="°C">
              <b-form-input
                size="sm"
                v-model="test.startTemp"
                type="number"
                :disabled="disabled.startTemp"></b-form-input>
            </b-input-group>
          </b-form-group>
          <b-form-group label="Environment" label-size="sm">
            <div style="display: flex">
              <b-form-checkbox
                style="padding-top: 0.3rem; margin-right: 1rem"
                size="sm"
                v-model="test.chamber"
                :disabled="disabled.chamber"
                @change="changeChamber"
                >Chamber</b-form-checkbox
              >
              <b-input-group size="sm" prepend="Temperature" append="°C">
                <b-form-input
                  size="sm"
                  v-model="test.chamberTemp"
                  type="number"
                  :disabled="disabled.chamber || !test.chamber"></b-form-input>
              </b-input-group>
            </div>
          </b-form-group>
        </div>
      </div>
      <hr />
      <div class="row">
        <h6 class="col-xl-2">APP *</h6>
        <b-form-group label-size="sm" class="col-xl-10">
          <b-form-radio-group
            v-model="test.appType"
            :options="appTypes"
            size="sm"
            style="margin-bottom: 0.5rem"
            :disabled="disabled.appId"></b-form-radio-group>
          <treeselect
            :max-height="300"
            :multiple="true"
            :always-open="true"
            :options="apps"
            :disabled="disabled.appId"
            v-model="test.appId"></treeselect>
        </b-form-group>
      </div>
      <hr />
      <div class="row">
        <h6 class="col-xl-2">Condition</h6>
        <div class="col-xl-10">
          <div class="row">
            <div class="col-xl-6">
              <div
                style="
                  display: flex;
                  justify-content: space-between;
                  font-size: 0.875rem;
                  padding-bottom: calc(0.25rem + 1px);
                ">
                <label style="margin-bottom: 0rem">Pre-defined Condition</label>
              </div>
              <b-form-select
                size="sm"
                v-model="selectedPreCondition"
                :options="predefinedConditions"
                :select-size="33"
                :disabled="disabled.preCondition"
                @change="changePredefinedCondition"></b-form-select>
            </div>
            <div class="col-xl-6">
              <b-form-group label="Condition Name" label-size="sm">
                <b-form-input
                  size="sm"
                  v-model="test.conditionName"
                  :disabled="disabled.conditionName"></b-form-input>
              </b-form-group>
              <b-form-group
                v-for="(freq, index) in frequencyList"
                :key="index + 'freq'"
                :label="freq.name"
                label-size="sm"
                class="condition-container">
                <b-input-group
                  prepend="MIN"
                  size="sm"
                  style="margin-right: 0.5rem">
                  <b-form-select
                    v-model="test.commands[freq.name]['min']"
                    :options="freq.values"
                    size="sm"
                    :disabled="
                      disabled.commands[freq.name]['min']
                    "></b-form-select>
                </b-input-group>
                <b-input-group
                  prepend="MAX"
                  size="sm"
                  style="margin-left: 0.5rem">
                  <b-form-select
                    v-model="test.commands[freq.name]['max']"
                    :options="freq.values"
                    size="sm"
                    :disabled="
                      disabled.commands[freq.name]['max']
                    "></b-form-select>
                </b-input-group>
              </b-form-group>
              <div style="margin-bottom: 1rem">
                <div
                  style="
                    display: flex;
                    justify-content: space-between;
                    font-size: 0.875rem;
                  ">
                  <label>Batch file list</label>
                  <a
                    class="link-text"
                    style="cursor: pointer"
                    @click="showBatchModal"
                    >edit</a
                  >
                </div>
                <b-form-select
                  size="sm"
                  :options="test.commands.batch"
                  :select-size="5"
                  :disabled="disabled.commands.batch"></b-form-select>
              </div>
              <b-form-group>
                <b-button
                  size="sm"
                  variant="outline-secondary"
                  style="width: 48%; margin-right: 0.5rem"
                  @click="resetCondition"
                  >Reset</b-button
                >
                <b-button
                  size="sm"
                  style="width: 48%; margin-left: 0.5rem"
                  @click="saveCondition"
                  >{{
                    editConditionMode ? "Update Condition" : "Add Condition"
                  }}</b-button
                >
              </b-form-group>
            </div>
          </div>
        </div>
      </div>
      <hr />
      <div
        style="display: flex; justify-content: flex-end; align-items: center">
        <span style="margin-right: 1rem"
          >Current test count: {{ tableData.length }}</span
        >
        <b-button
          size="sm"
          variant="outline-primary"
          style="margin-right: 0.5rem"
          @click="cancelTest"
          ><b-icon icon="x" /> Cancel</b-button
        >
        <b-button
          size="sm"
          variant="primary"
          @click="isTestAddMode ? addTest() : updateTest()"
          ><b-icon icon="check2" />
          {{ isTestAddMode ? "Add" : "Update" }} Test</b-button
        >
      </div>
    </div>

    <b-modal
      id="batch-modal"
      title="Choose batch file"
      :size="addBatchMode ? 'lg' : 'md'"
      @ok="addBatch">
      <div class="row">
        <div :class="`col-xl-${addBatchMode ? 6 : 12}`">
          <div style="padding-bottom: calc(0.25rem + 1px); height: 26px">
            <span style="font-size: 0.875rem; line-height: 1.5; cursor: pointer"
              >File List (\\10.229.95.71\gta\batch)
            </span>
            <a class="link-text" @click="addBatchFile">+</a>
          </div>
          <b-form-select
            size="sm"
            v-model="selectedBatch"
            :options="batchList"
            multiple
            :select-size="20"></b-form-select>
        </div>
        <div class="col-xl-6" v-show="addBatchMode">
          <b-form-group label="File Name" label-size="sm">
            <b-form-input size="sm" v-model="batch.name"></b-form-input>
          </b-form-group>
          <b-form-group label="Content" label-size="sm">
            <b-textarea
              type="text"
              rows="13"
              size="sm"
              v-model="batch.content" />
          </b-form-group>
          <b-button size="sm" style="float: right" @click="createBatch"
            >Save</b-button
          >
          <b-button
            variant="outline-secondary"
            size="sm"
            style="float: right; margin-right: 0.5rem"
            @click="addBatchMode = false"
            >Cancel</b-button
          >
        </div>
      </div>
    </b-modal>
    <add-chip ref="addChipInTicket" @getData="getChips"></add-chip>
  </div>
</template>

<script>
import AddChip from "@/components/modal/AddChipModal.vue";
import Treeselect from "@riophae/vue-treeselect";
import "@riophae/vue-treeselect/dist/vue-treeselect.css";

export default {
  components: {
    Treeselect,
    AddChip,
  },
  computed: {
    apps() {
      var list = [];

      for (const app of this.allAppList) {
        if (app.type != this.test.appType) {
          continue;
        }

        var item = {
          id: `${app.type}/${app.id}`,
          label: app.name,
        };

        if (app.type == "Benchmark") {
          item.children = [];

          for (const tc of app.testcase) {
            item.children.push({
              id: `${app.type}/${app.id}/${tc.id}`,
              label: tc.name,
            });
          }
        }

        list.push(item);
      }

      return list;
    },
    editConditionMode() {
      return this.selectedPreCondition;
    },
    disabledRequester() {
      return (
        this.$route.name !== "UpdateTicketById" && this.$store.getters.isLogin
      );
    },
    requesterText() {
      return `${this.$store.state.userStore.userName} (${this.$store.state.userStore.knoxId})`;
    },
  },
  data() {
    return {
      outdatas: [
        { value: "FPS", text: "FPS" },
        { value: "Power", text: "Power" },
        { value: "AMIGO Log", text: "AMIGO Log" },
        { value: "SOC Dumper Log", text: "SOC Dumper Log" },
        { value: "Power Raw Data", text: "Power Raw Data" },
        { value: "Gamebench", text: "Gamebench" },
      ],
      revisionNumbers: [
        { value: "EVT0", text: "EVT0" },
        { value: "EVT1", text: "EVT1" },
      ],
      boardTypes: [
        { value: "ERD", text: "ERD" },
        { value: "SMDK", text: "SMDK" },
        { value: "MX Current", text: "MX Current" },
        { value: "MX A-Type", text: "MX A-Type" },
        { value: "MX U-Type", text: "MX U-Type" },
        { value: "MX C-Type", text: "MX C-Type" },
      ],
      bspTypes: [
        { value: "GED", text: "GED" },
        { value: "SEP", text: "SEP" },
      ],
      binaryTypes: [
        { value: "USERDEBUG", text: "USERDEBUG" },
        { value: "ENG", text: "ENG" },
      ],
      appTypes: [
        { value: "Game", text: "Game" },
        { value: "Benchmark", text: "Benchmark" },
      ],
      checkboxOption: {
        selectedRowKeys: [],
        selectedRowChange: ({ selectedRowKeys }) => {
          this.changeSelectedRowKeys(selectedRowKeys);
        },
        selectedAllChange: ({ selectedRowKeys }) => {
          this.changeSelectedRowKeys(selectedRowKeys);
        },
      },
      expandOption: {
        render: ({ row }) => {
          return (
            <div>
              <span
                v-show={row.chamber}>{`Chamber: ${row.chamberTemp}°C`}</span>
              <br v-show={row.chamber} />
              <span>Binary Path: {row.binaryPath}</span>
              <br />
              <span>Binary Quickbuild: {row.binaryQuickbuild}</span>
              <br />
              <span>
                Libs:{" "}
                {row.libPath == null || row.libPath.length === 0
                  ? ""
                  : row.libPath.join("\n")}
              </span>
              <br />
              <span>
                Condition:{" "}
                {Object.keys(row.commands).length === 0
                  ? ""
                  : JSON.stringify(row.commands)}
              </span>
            </div>
          );
        },
      },
      columns: [
        {
          field: "expand",
          key: "expand",
          title: "",
          type: "expand",
          width: "1%",
        },
        {
          field: "checkbox",
          key: "checkbox",
          title: "",
          type: "checkbox",
          width: "1%",
        },
        {
          field: "no",
          key: "no",
          title: "No.",
          width: "1%",
        },
        {
          field: "group",
          key: "group",
          title: "Group",
        },
        {
          field: "project",
          key: "project",
          title: "Project",
        },
        {
          field: "revisionNumber",
          key: "revisionNumber",
          title: "Revision",
        },
        {
          field: "chip",
          key: "chip",
          title: "Chip ID",
        },
        {
          field: "boardType",
          key: "boardType",
          title: "Board",
        },
        {
          field: "bspType",
          key: "bspType",
          title: "BSP",
        },
        {
          field: "app",
          key: "app",
          title: "App",
        },
        {
          field: "testcase",
          key: "testcase",
          title: "Testcase",
        },
        {
          field: "conditionName",
          key: "conditionText",
          title: "Condition",
        },
      ],
      tableData: [],
      users: [],
      adminMails: [],
      projects: [],
      chips: [],
      allAppList: [],
      predefinedConditions: [],
      frequencyList: [],
      batchList: [],
      selectedBatch: [],
      addBatchMode: false,
      visibleTest: false,
      defaultProjectId: null,
      ticketId: null,
      ticket: {
        title: null,
        requester: null,
        tester: null,
        outdata: [
          "FPS",
          "Power",
          "AMIGO Log",
          "SOC Dumper Log",
          "Power Raw Data",
        ],
        description: null,
      },
      test: {
        group: null,
        projectId: null,
        revisionNumber: null,
        chipId: null,
        boardType: null,
        bspType: null,
        binaryPath: null,
        binaryType: "USERDEBUG",
        binaryQuickbuild: null,
        libPath: [],
        startTemp: 30,
        chamber: false,
        chamberTemp: null,
        appType: "Benchmark",
        appId: [],
        commands: {
          batch: [],
        },
        conditionName: null,
      },
      disabled: {
        group: false,
        projectId: false,
        revisionNumber: false,
        chipId: false,
        boardType: false,
        bspType: false,
        binaryPath: false,
        binaryType: false,
        binaryQuickbuild: false,
        libPath: false,
        startTemp: false,
        chamber: false,
        chamberTemp: false,
        appId: false,
        commands: {
          batch: false,
        },
        conditionName: false,
        preCondition: false,
      },
      selectedPreCondition: null,
      isTestAddMode: true,
      isTicketAddMode: true,
      isFavoriteMode: false,
      batch: {
        name: null,
        content: null,
      },
      knoxApiInstance: null,
    };
  },
  async created() {
    if (
      this.$route.name === "UpdateTicketById" ||
      this.$route.name === "CopyTicketById"
    ) {
      this.ticketId = this.$route.params.id;
      this.isTicketAddMode = this.$route.name === "CopyTicketById";

      const title =
        this.$route.name === "CopyTicketById"
          ? ` - copy from ${this.ticketId}`
          : "";

      const res = await this.$http.get(`/api/tickets/${this.ticketId}`);

      this.ticket.title = `${res.data.title}${title}`;
      this.ticket.requester = res.data.requester_id;
      this.ticket.tester = res.data.tester_id;
      this.ticket.outdata = JSON.parse(res.data.outdata);
      this.ticket.description = res.data.description;

      this.$http.get(`/api/tickets/${this.ticketId}/tests`).then(res => {
        for (const data of res.data) {
          this.tableData.push(data);
        }
      });
    }

    this.$http.get("/api/users").then(res => {
      let adminOption = null;
      const benchmarkGroup = [];
      const otherGroup = [];
      for (const user of res.data) {
        if (user.knox_id === "gta.app") {
          adminOption = {
            value: user.id,
            text: `${user.name} (${user.knox_id})`,
          };
        } else if (user.roles === "BENCHMARK_KPI") {
          benchmarkGroup.push({
            value: user.id,
            text: `${user.name} (${user.knox_id})`,
          });
        } else {
          otherGroup.push({
            value: user.id,
            text: `${user.name} (${user.knox_id})`,
          });
        }
      }

      if (adminOption) {
        this.users.push(adminOption);
      }
      if (benchmarkGroup.length) {
        this.users.push({
          label: "BENCHMARK KPI Group",
          options: benchmarkGroup,
        });
      }
      if (otherGroup.length) {
        this.users.push({
          label: "other",
          options: otherGroup,
        });
      }

      if (res.data.length) {
        this.ticket.tester = res.data[0].id;
      }

      if (
        this.$route.name !== "UpdateTicketById" &&
        this.$store.getters.isLogin
      ) {
        this.ticket.requester = this.$store.state.userStore.userId;
      }
    });

    this.$http.get("/api/projects").then(res => {
      for (const project of res.data) {
        this.projects.push({
          value: project.id,
          text: project.name,
        });

        if (project.default) {
          this.defaultProjectId = project.id;
          this.test.projectId = project.id;
        }
      }

      this.changeProject();
    });

    this.$http.get("/api/apps/testcase").then(res => {
      this.allAppList = res.data;
    });
  },
  beforeRouteEnter(to, from, next) {
    if (from.name === "KpiTicketList") {
      next(vm => {
        vm.isFavoriteMode = true;
      });
    } else {
      next();
    }
  },
  methods: {
    async changeProject() {
      await this.getChips();
      await this.getPredefinedConditions();
      await this.getCommands();
    },
    async getChips() {
      var res = await this.$http.get(
        `/api/projects/${this.test.projectId}/chips`,
      );

      this.chips = [];

      for (const chip of res.data) {
        var name = chip.name ? ` (${chip.name})` : "";

        this.chips.push({
          value: chip.id,
          chipId: chip.chip_id,
          text: `${chip.chip_id}${name}`,
        });
      }
    },
    async getPredefinedConditions() {
      var res = await this.$http.get(`/api/conditions/${this.test.projectId}`);

      this.predefinedConditions = [];

      for (const condition of res.data) {
        this.predefinedConditions.push({
          value: condition.id,
          text: condition.name,
          commands: condition.value,
        });
      }
    },
    async getCommands() {
      // get frequency list
      let freqResult = await this.$http.get(
        `/api/frequency/${this.test.projectId}`,
      );

      this.frequencyList = freqResult.data;

      for (const freq of this.frequencyList) {
        this.test.commands[freq.name] = {
          min: "",
          max: "",
        };

        this.disabled.commands[freq.name] = {
          min: false,
          max: false,
        };

        freq.values = freq.values.map(x => ({
          value: x,
          text: x,
        }));
      }

      // get batch list
      let batchResult = await this.$http.get(
        `/api/conditions/batch/${this.test.projectId}`,
      );

      this.batchList = batchResult.data.map(x => ({
        value: x,
        text: x,
      }));

      this.test.commands.batch = [];
      this.disabled.commands.batch = false;
    },
    changePredefinedCondition() {
      var condition = this.predefinedConditions.find(
        x => x.value == this.selectedPreCondition,
      );

      this.test.conditionName = condition.text;

      // 초기화가 필요하기 때문에 test.commands를 loop돌아 값 설정, 없으면 초기화
      for (const key in this.test.commands) {
        if (Array.isArray(this.test.commands[key])) {
          // batch
          this.test.commands[key] = condition.commands.batch ?? [];
        } else {
          // frequency
          this.test.commands[key] = condition.commands[key] ?? {
            min: "",
            max: "",
          };
        }
      }
    },
    resetCommands() {
      for (const key in this.test.commands) {
        if (Array.isArray(this.test.commands[key])) {
          // batch
          this.test.commands[key] = [];
          this.disabled.commands[key] = false;
        } else {
          // frequency
          this.test.commands[key] = { min: "", max: "" };
          this.disabled.commands[key] = { min: false, max: false };
        }
      }
    },
    changeSelectedRowKeys(keys) {
      this.visibleTest = false;
      this.checkboxOption.selectedRowKeys = keys;
    },
    showTestInformation() {
      this.visibleTest = true;
      this.$nextTick(() => {
        document
          .getElementById("test-information")
          .scrollIntoView({ behavior: "smooth" });
      });
    },
    clickAddTest() {
      this.test.group = null;
      this.test.projectId = this.defaultProjectId;
      this.test.revisionNumber = null;
      this.test.chipId = null;
      this.test.boardType = null;
      this.test.bspType = null;
      this.test.binaryPath = null;
      this.test.binaryType = "USERDEBUG";
      this.test.binaryQuickbuild = null;
      this.test.libPath = [];
      this.test.chamber = false;
      this.test.chamberTemp = null;
      this.test.startTemp = 30;
      this.test.appType = "Benchmark";
      this.test.appId = [];
      this.test.conditionName = null;

      this.disabled.projectId = false;
      this.disabled.revisionNumber = false;
      this.disabled.chipId = false;
      this.disabled.boardType = false;
      this.disabled.bspType = false;
      this.disabled.binaryPath = false;
      this.disabled.binaryType = false;
      this.disabled.binaryQuickbuild = false;
      this.disabled.libPath = false;
      this.disabled.chamber = false;
      this.disabled.chamberTemp = false;
      this.disabled.startTemp = false;
      this.disabled.conditionName = false;
      this.disabled.preCondition = false;
      this.selectedPreCondition = null;

      this.resetCommands();

      this.isTestAddMode = true;
      this.showTestInformation();
    },
    async clickUpdateTest() {
      if (this.checkboxOption.selectedRowKeys.length == 0) {
        alert("Please select test to update !!");
        return;
      }

      // 선택된 test만 가져오기
      var selectedTableData = [];

      for (const row of this.checkboxOption.selectedRowKeys) {
        var test = this.tableData.find(x => x.no == row);

        if (test) {
          selectedTableData.push(test);
        }
      }

      // 동일한 project만 선택 가능
      const projectSet = new Set(selectedTableData.map(x => x.projectId));
      const projectArr = [...projectSet];

      if (projectArr.length > 1) {
        alert("Please select tests of the same project !! ");
        return;
      }

      this.test.projectId = projectArr[0];
      await this.changeProject();

      // app은 app, appId, testcase, testcaseId로 나뉘기 때문에 3가지 모두 체크
      const appSet = new Set(
        selectedTableData.map(
          x =>
            `${x.appType}/${x.appId}${
              x.appType === "Benchmark" ? `/${x.testcaseId}` : ""
            }`,
        ),
      );
      const appArr = [...appSet];

      // this.test의 key를 for문으로 돌면서 set을 만들고 값이 같은지 확인(length == 1)
      for (const key in this.test) {
        let set = new Set(selectedTableData.map(x => x[key]));
        let arr = [...set];

        // 같으면 데이터 넣고 활성화, 다르면 빈칸 + 비활성화
        let isSame = arr.length == 1;

        if (key === "appId") {
          this.test.appId = appArr.length == 1 ? appArr : [];
          this.disabled.appId = appArr.length != 1;
        } else if (key === "commands") {
          // pass
        } else if (key === "chamberTemp") {
          this.test[key] = isSame ? arr[0] : "";
          this.disabled[key] = !isSame;

          if (isSame === false) {
            this.test.chamber = false;
            this.disabled.chamber = true;
          }
        } else if (key === "libPath") {
          let set = new Set(selectedTableData.map(x => JSON.stringify(x[key])));
          let arr = [...set];

          this.test[key] = arr.length == 1 && arr[0] ? JSON.parse(arr[0]) : [];
          this.disabled[key] = arr.length != 1;
        } else {
          this.test[key] = isSame ? arr[0] : "";
          this.disabled[key] = !isSame;
        }
      }

      let predefinedDisabled = false;

      for (const key in this.test.commands) {
        if (Array.isArray(this.test.commands[key])) {
          // batch
          let set = new Set(
            selectedTableData.map(x => JSON.stringify(x.commands[key])),
          );
          let arr = [...set];

          this.test.commands[key] =
            arr.length == 1 && arr[0] ? JSON.parse(arr[0]) : [];
          this.disabled.commands[key] = arr.length != 1;

          if (this.disabled.commands[key]) {
            predefinedDisabled = true;
          }
        } else {
          // frequency
          let minSet = new Set(
            selectedTableData.map(x => JSON.stringify(x.commands[key]?.min)),
          );
          let maxSet = new Set(
            selectedTableData.map(x => JSON.stringify(x.commands[key]?.max)),
          );

          let minArr = [...minSet];
          let maxArr = [...maxSet];

          this.test.commands[key] = {
            min: minArr.length == 1 && minArr[0] ? JSON.parse(minArr[0]) : "",
            max: maxArr.length == 1 && maxArr[0] ? JSON.parse(maxArr[0]) : "",
          };

          this.disabled.commands[key] = {
            min: minArr.length != 1,
            max: maxArr.length != 1,
          };

          if (
            this.disabled.commands[key].min ||
            this.disabled.commands[key].max
          ) {
            predefinedDisabled = true;
          }
        }
      }

      // project 수정 불가
      this.disabled.projectId = true;
      this.disabled.preCondition = predefinedDisabled;

      this.selectedPreCondition = null;
      this.isTestAddMode = false;
      this.showTestInformation();
    },
    clickDeleteTest() {
      if (this.checkboxOption.selectedRowKeys.length == 0) {
        alert("Please select test to delete !!");
        return;
      }

      for (const row of this.checkboxOption.selectedRowKeys) {
        var idx = this.tableData.findIndex(x => x.no === row);

        if (idx != -1) {
          this.tableData.splice(idx, 1);
        }
      }

      for (let i = 0; i < this.tableData.length; i++) {
        this.tableData[i].no = i + 1;
      }

      this.checkboxOption.selectedRowKeys = [];
      this.visibleTest = false;
    },
    clickCopyTest() {
      if (this.checkboxOption.selectedRowKeys.length == 0) {
        alert("Please select test to copy !!");
        return;
      }

      let newKeys = [];

      for (const row of this.checkboxOption.selectedRowKeys) {
        var idx = this.tableData.findIndex(x => x.no === row);

        if (idx != -1) {
          var test = JSON.parse(JSON.stringify(this.tableData[idx]));

          test.id = null;
          test.no = this.tableData.length + 1;

          newKeys.push(test.no);
          this.tableData.push(test);
        }
      }

      this.checkboxOption.selectedRowKeys = newKeys;
      this.visibleTest = false;
    },
    cancelTest() {
      this.visibleTest = false;
      this.$nextTick(() => {
        document
          .getElementById("ticket-information")
          .scrollIntoView({ behavior: "smooth" });
      });
    },
    addTest() {
      if (this.test.appId.length === 0) {
        alert("Please select one or more apps !!");
        return;
      }

      var project = this.projects.find(x => x.value == this.test.projectId);
      var chip = this.chips.find(x => x.value == this.test.chipId);

      for (const appInfo of this.test.appId) {
        var appInfoList = appInfo.split("/");

        var app = this.allAppList.find(x => x.id == appInfoList[1]);

        var test = {
          no: this.tableData.length + 1,
          group: this.test.group,
          project: project?.text,
          projectId: project?.value,
          revisionNumber: this.test.revisionNumber,
          chip: chip?.chipId,
          chipId: chip?.value,
          boardType: this.test.boardType,
          bspType: this.test.bspType,
          binaryPath: this.test.binaryPath,
          binaryType: this.test.binaryType,
          binaryQuickbuild: this.test.binaryQuickbuild,
          libPath: this.test.libPath.filter(x => x),
          appId: appInfoList[1],
          app: app?.name,
          appType: app?.type,
          chamber: this.test.chamber,
          chamberTemp: this.test.chamberTemp,
          startTemp: this.test.startTemp,
          conditionName: this.test.conditionName,
          commands: {},
        };

        for (const key in this.test.commands) {
          for (const subkey in this.test.commands[key]) {
            if (this.test.commands[key][subkey]) {
              test.commands[key] = JSON.parse(
                JSON.stringify(this.test.commands[key]),
              );
              break;
            }
          }
        }

        if (appInfoList[0] === "Benchmark") {
          // all testcase 선택
          if (appInfoList.length == 2) {
            for (const tc of app.testcase) {
              test.no = this.tableData.length + 1;
              test.testcaseId = tc.id;
              test.testcase = tc.name;

              this.tableData.push(JSON.parse(JSON.stringify(test)));
            }
          } else {
            var tc = app.testcase.find(x => x.id == appInfoList[2]);

            test.testcaseId = tc?.id;
            test.testcase = tc?.name;

            this.tableData.push(test);
          }
        } else {
          this.tableData.push(test);
        }
      }
    },
    updateTest() {
      const selectedApp = this.test.appId[0];

      if (
        !this.disabled.appId &&
        (this.test.appId.length !== 1 ||
          (selectedApp.startsWith("Benchmark") &&
            selectedApp.split("/").length !== 3))
      ) {
        alert("Please select one app !!");
        return;
      }

      // 선택된 test를 돌면서 수정
      for (const row of this.checkboxOption.selectedRowKeys) {
        var test = this.tableData.find(x => x.no === row);

        // 활성화된 필드들 수정
        for (const key in this.disabled) {
          if (!this.disabled[key]) {
            test[key] = this.test[key];
          }
        }

        if (!this.disabled.chipId) {
          var chip = this.chips.find(x => x.value == this.test.chipId);
          test.chip = chip?.chipId;
        }

        if (!this.disabled.appId) {
          var appInfoList = this.test.appId[0].split("/");
          var app = this.allAppList.find(x => x.id == appInfoList[1]);

          if (app.type === "Benchmark") {
            var tc = app.testcase.find(x => x.id == appInfoList[2]);

            test.testcase = tc.name;
            test.testcaseId = tc.id;
          } else {
            test.testcase = "";
            test.testcaseId = "";
          }

          test.app = app?.name;
          test.appType = app?.type;
          test.appId = appInfoList[1];
        }

        for (const key in this.disabled.commands) {
          if (typeof this.disabled.commands[key] === "object") {
            // frequency
            for (const subkey in this.disabled.commands[key]) {
              if (this.disabled.commands[key][subkey]) {
                continue;
              }

              if (this.test.commands[key][subkey]) {
                if (!(key in test.commands)) {
                  test.commands[key] = { min: "", max: "" };
                }

                test.commands[key][subkey] = this.test.commands[key][subkey];
              } else {
                if (key in test.commands) {
                  delete test.commands[key];
                }
              }
            }
          } else {
            // batch
            if (this.disabled.commands[key]) {
              continue;
            }

            if (this.test.commands[key].length) {
              test.commands[key] = this.test.commands[key];
            } else {
              delete test.commands[key];
            }
          }
        }
      }

      // re-rendering
      this.tableData.push();
      this.checkboxOption.selectedRowKeys = [];
      this.cancelTest();
    },
    saveCondition() {
      if (!this.test.conditionName) {
        alert("Please enter the condition name.");
        return;
      }

      var body = {
        projectId: this.test.projectId,
        name: this.test.conditionName,
        value: {},
      };

      for (const key in this.test.commands) {
        for (const subkey in this.test.commands[key]) {
          if (this.test.commands[key][subkey]) {
            body.value[key] = this.test.commands[key];
            break;
          }
        }
      }

      if (this.editConditionMode) {
        // 기존 condition 수정
        this.$http
          .put(`/api/conditions/${this.selectedPreCondition}`, body)
          .then(() => {
            alert("Success to update !!");

            var condition = this.predefinedConditions.find(
              x => x.value == this.selectedPreCondition,
            );

            condition.text = this.test.conditionName;
            condition.commands = body.value;
          })
          .catch(err => {
            if (err.response.status == 400) {
              alert("Already exist condition name.");
            } else {
              alert(err);
            }
          });
      } else {
        // 새로운 condition 추가
        this.$http
          .post(`/api/conditions`, body)
          .then(res => {
            alert("Success to add !!");

            this.predefinedConditions.push({
              value: res.data,
              text: this.test.conditionName,
              commands: body.value,
            });

            this.selectedPreCondition = res.data;
          })
          .catch(err => {
            if (err.response.status == 400) {
              alert("Already exist condition name.");
            } else {
              alert(err);
            }
          });
      }
    },
    resetCondition() {
      this.selectedPreCondition = "";
      this.disabled.preCondition = false;
      this.test.conditionName = "";
      this.disabled.conditionName = false;

      for (const key in this.test.commands) {
        if (Array.isArray(this.test.commands[key])) {
          this.test.commands[key] = [];
          this.disabled.commands[key] = false;
        } else {
          this.test.commands[key] = { min: "", max: "" };
          this.disabled.commands[key] = { min: false, max: false };
        }
      }
    },
    addTicket() {
      if (!this.ticket.title) {
        alert("Please enter the title !!");
        return;
      }

      if (!this.ticket.requester) {
        alert("Please select the requester !!");
        return;
      }

      if (this.tableData.length === 0) {
        alert("Please add tests.");
        return;
      }

      this.ticket.favorite = this.isFavoriteMode ? 1 : 0;
      this.ticket.tests = this.tableData;

      if (this.isTicketAddMode) {
        this.$http.post(`/api/tickets`, this.ticket).then(res => {
          // this.sendMailToAdmin(res.data, "created");
          alert("Success to add !!");

          this.$router.push({
            name: "TicketInfo",
            params: {
              id: res.data,
            },
          });
        });
      } else {
        this.$http
          .put(`/api/tickets/${this.ticketId}`, this.ticket)
          .then(() => {
            if (!this.$store.getters.isBenchmarkKpiManager) {
              // this.sendMailToAdmin(this.ticketId, "updated");
            }
            alert("Success to update !!");

            this.$router.push({
              name: "TicketInfo",
              params: {
                id: this.ticketId,
              },
            });
          })
          .catch(err => {
            console.log(err);
          });
      }
    },
    sendMailToAdmin(ticketId, action) {
      this.createKnoxApiInstance();

      const link = `${this.$store.state.GTA_LINK}ticket/${ticketId}`;

      let data = {
        subject: `[Request] ${this.ticket.title}`,
        contents: `<p>@${this.$store.state.userStore.knoxId} ${action} a ticket.</p><p>GTA Link: <a href='${link}'>${link}</a></p>`,
        contentType: "HTML",
        docSecuType: "PERSONAL",
        sender: {
          emailAddress: this.$store.state.ADMIN_EMAIL,
        },
        recipients: [
          {
            emailAddress: this.$store.state.ADMIN_EMAIL,
            recipientType: "TO",
          },
        ],
      };

      this.knoxApiInstance
        .post(
          `mail/api/v2.0/mails/send?userId=${this.$store.state.ADMIN_ID}`,
          JSON.stringify(data),
        )
        .then(() => {
          console.log("메일 발신 완료");
        })
        .catch(err => {
          console.log(err.response);
        });
    },
    showBatchModal() {
      this.addBatchMode = false;
      this.selectedBatch = JSON.parse(JSON.stringify(this.test.commands.batch));
      this.$bvModal.show("batch-modal");
    },
    createBatch(e) {
      e.preventDefault();

      if (!this.batch.name) {
        alert("Empty name !!");
        return;
      }

      var project = this.projects.find(x => x.value === this.test.projectId);

      this.$http
        .post(`/api/conditions/${project?.text}/batch`, this.batch)
        .then(res => {
          this.addBatchMode = false;
          this.batchList.push({
            value: res.data,
            text: res.data,
          });
        })
        .catch(err => {
          if (err.response.status === 409) {
            alert("Already exists !!");
            return;
          }

          alert(err);
        });
    },
    addBatch() {
      this.test.commands.batch = JSON.parse(JSON.stringify(this.selectedBatch));
      this.selectedBatch = [];
    },
    addLib() {
      this.test.libPath.push("");
    },
    removeLib(index) {
      this.test.libPath.splice(index, 1);
    },
    changeChamber() {
      this.test.chamberTemp = this.test.chamber ? 45 : null;
    },
    showAddChip() {
      this.$refs.addChipInTicket.reset();
      this.$bvModal.show("add-chip");
    },
    addBatchFile() {
      this.batch.name = "";
      this.batch.content = "";
      this.addBatchMode = true;
    },
    createKnoxApiInstance() {
      if (this.knoxApiInstance) {
        return;
      }

      const headerObject = {
        baseURL: "https://openapi.samsung.net/",
        headers: {
          "Content-type": "application/json",
          "System-ID": "KCC10REST00624",
          "Authorization": "Bearer e0038e74-49d8-32ad-be5b-1a5defc7174a",
        },
      };

      this.knoxApiInstance = this.$http.create(headerObject);
    },
  },
};
</script>

<style scoped>
h5 {
  font-weight: bold;
  margin-bottom: 0rem;
}

#input-path .input-group-text {
  padding-left: 1.7rem;
  padding-right: 1.7rem;
}

#lib-path .input-group-text {
  padding-left: 1.7rem;
  padding-right: 1.7rem;
}

#lib-path {
  margin-bottom: 0.5rem;
}

.btn-group {
  display: flex;
}
</style>

<style>
.custom-switch .custom-control-label {
  font-size: 0.875rem;
  vertical-align: middle;
}

.condition-container div {
  display: flex;
}

.vue-treeselect__menu-container {
  position: static !important;
  overflow: auto !important;
}

.vue-treeselect__menu {
  position: static !important;
  overflow: auto !important;
  font-size: 0.875rem;
  height: 300px;
}

.vue-treeselect--open.vue-treeselect--open-above .vue-treeselect__control {
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}
</style>
