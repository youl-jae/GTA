<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">Test Information</span>
      <div class="sub-title-btn-group">
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Delete"
          @click="clickDeleteBtn">
          <font-awesome-icon icon="trash-alt" />
        </b-button>
      </div>
    </div>

    <table class="table table-sm table-bordered test-table">
      <thead>
        <th style="width: 220px"></th>
        <th style="text-align: left">Test1</th>
      </thead>
      <tbody>
        <tr v-for="(column, index) in testColumns" :key="index + 'tc'">
          <th v-if="column.field === 'etc'">
            ETC
            <font-awesome-icon
              icon="pencil-alt"
              class="text-link"
              @click="showEtcModal" />
          </th>
          <th v-else>{{ column.text }}</th>
          <td v-if="column.field === 'title'">
            <b-link id="titleEditLink">{{ test.title }}</b-link>
            <b-popover
              ref="titlePopover"
              target="titleEditLink"
              triggers="focus">
              <template #title>Enter new title</template>
              <div class="group">
                <b-form-input v-model="newTitle" size="sm"></b-form-input>
                <div class="group">
                  <b-button
                    class="ml-2"
                    variant="outline-primary"
                    size="sm"
                    @click="editTitle"
                    ><font-awesome-icon icon="check"
                  /></b-button>
                  <b-button
                    class="ml-2"
                    variant="outline-secondary"
                    size="sm"
                    @click="closeTitleEditPopup"
                    ><font-awesome-icon icon="times"
                  /></b-button>
                </div>
              </div>
            </b-popover>
          </td>
          <td v-else-if="column.field === 'chip'">
            <span>
              <a
                class="link-text"
                style="cursor: pointer"
                @click="showChipModal(test.chip_id)"
                >{{ test[column.field] }}</a
              >
            </span>
          </td>
          <td v-else>{{ test[column.field] }}</td>
        </tr>
      </tbody>
    </table>

    <div class="sub-title-group">
      <span class="sub-title">Test Score</span>
      <div class="sub-title-btn-group">
        <b-button
          v-show="isBenchmarkKPIManager"
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Move to Another Test"
          @click="showTestModal">
          <font-awesome-icon icon="arrow-right" />
        </b-button>
        <b-button
          v-show="isPPAEngineer"
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Sync PPA Data"
          @click="clickSyncPPAData">
          <font-awesome-icon icon="sync-alt" />
        </b-button>
        <b-button
          v-show="isLogin"
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Delete Testitems"
          @click="clickDeleteTestitemBtn">
          <font-awesome-icon icon="trash-alt" />
        </b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Copy"
          @click="copyToClipboard">
          <font-awesome-icon icon="copy" />
        </b-button>
      </div>
    </div>

    <table id="score-table" class="table table-sm table-bordered test-table">
      <thead>
        <tr v-show="isLogin">
          <th style="width: 220px"></th>
          <th
            v-for="(item, index) in scoreData.items"
            :key="'checkbox-' + index">
            <b-form-checkbox
              v-if="!item.__isAvg"
              size="sm"
              style="font-size: 12px"
              class="col-checkbox"
              v-model="selectedTestItems"
              :value="item.id"></b-form-checkbox>
          </th>
        </tr>
        <tr>
          <th style="width: 220px">{{ test.app }}</th>
          <th v-for="(item, index) in scoreData.items" :key="index + 'i'">
            <template v-if="item.__isAvg">
              <span>Average</span>
            </template>
            <template v-else>
              <span>#{{ index + 1 }}</span>
              <div>
                <b-form-checkbox
                  inline
                  v-model="item.score"
                  @change="checkScoreOrPower(index)"
                  >FPS</b-form-checkbox
                >
                <b-form-checkbox
                  inline
                  v-model="item.power"
                  @change="checkScoreOrPower(index)"
                  >Power</b-form-checkbox
                >
              </div>
            </template>
          </th>
        </tr>
        <tr
          v-for="(column, index) in scoreHeadColumns"
          :key="index + 'sh'"
          v-show="scoreData.items?.filter(x => x[column.field]).length"
          class="score-head">
          <th>{{ column.text }}</th>
          <td
            v-if="!item.__isAvg"
            v-for="(item, index) in scoreData.items"
            :key="index + 'si'">
            <a :href="item[column.field]" target="_blank">{{
              item[column.field]
            }}</a>
          </td>
          <td></td>
        </tr>
      </thead>
      <tbody style="text-align: right">
        <tr v-for="(railName, rIndex) in uniquePowerRails" :key="'p' + rIndex">
          <th>{{ railName }}</th>
          <td v-for="(item, cIndex) in scoreData.items" :key="'pval' + cIndex">
            {{ getPowerValue(item.powers, railName) ?? "-" }}
          </td>
        </tr>

        <!-- Score Columns -->
        <tr
          v-for="(column, sIndex) in scoreBodyColumns"
          :key="'sb' + sIndex"
          v-show="scoreData.items.some(item => item[column.field])">
          <th>{{ column.text }}</th>
          <td v-for="(item, cIndex) in scoreData.items" :key="'sval' + cIndex">
            {{ item[column.field] ?? "-" }}
          </td>
        </tr>

        <tr
          v-for="(column, index) in efficiencyBodyColumns"
          :key="'eff-' + index"
          v-show="
            scoreData.items.some(item => item.efficiency?.[column.field])
          ">
          <th class="ppa-columns">{{ column.text }}</th>
          <td
            v-for="(item, cIndex) in scoreData.items"
            :key="'eff-val-' + index + '-' + cIndex">
            {{
              !item.efficiency?.[column.field]
                ? "-"
                : item.efficiency[column.field]
            }}
          </td>
        </tr>
      </tbody>
    </table>

    <edit-etc-modal ref="editEtcModal" @editEtc="editEtc"></edit-etc-modal>
    <chip-info-modal ref="chipInfoModal"></chip-info-modal>
    <edit-test-id-modal
      ref="editTestIdModal"
      @confirmTestId="handleMove"></edit-test-id-modal>
  </div>
</template>

<script>
import ChipInfoModal from "@/components/modal/ChipInfoModal.vue";
import EditEtcModal from "@/components/modal/EditEtcModal.vue";
import EditTestIdModal from "@/components/modal/EditTestIdModal.vue";

export default {
  name: "TestScore",
  components: {
    EditEtcModal,
    ChipInfoModal,
    EditTestIdModal,
  },
  computed: {
    isLogin() {
      return this.$store.getters.isLogin;
    },
    isPPAEngineer() {
      return this.$store.getters.isPPAEngineer;
    },
    isBenchmarkKPIManager() {
      return this.$store.getters.isBenchmarkKpiManager;
    },
    uniquePowerRails() {
      const rails = new Set();
      this.scoreData.items.forEach(item => {
        item.powers.forEach(p => rails.add(p.rail_name));
      });
      return Array.from(rails);
    },
  },
  data() {
    return {
      testColumns: [
        {
          field: "date",
          text: "Date",
        },
        {
          field: "title",
          text: "Title",
        },
        {
          field: "project",
          text: "Project",
        },
        {
          field: "app",
          text: "App",
        },
        {
          field: "testcase",
          text: "Testcase",
        },
        {
          field: "board_type",
          text: "Board Type",
        },
        {
          field: "chip",
          text: "Chip",
        },
        {
          field: "bsp_type",
          text: "BSP Type",
        },
        {
          field: "binary_path",
          text: "Binary Path",
        },
        {
          field: "binary_type",
          text: "Binary Type",
        },
        {
          field: "binary_quickbuild",
          text: "Binary Quickbuild",
        },
        {
          field: "lib_path",
          text: "Lib Path",
        },
        {
          field: "length",
          text: "Length (min)",
        },
        {
          field: "network",
          text: "Network",
        },
        {
          field: "environment",
          text: "Environment",
        },
        {
          field: "start_temp",
          text: "Start Temperature",
        },
        {
          field: "tester",
          text: "Tester",
        },
        {
          field: "condition_name",
          text: "Condition Name",
        },
        {
          field: "commands",
          text: "Commands",
        },
        {
          field: "etc",
          text: "ETC",
        },
      ],
      testId: null,
      test: {},
      scoreHeadColumns: [
        {
          field: "gamebench_url",
          text: "Gamebench",
        },
        {
          field: "quickperf_url",
          text: "Quickperf",
        },
        {
          field: "amigo_log",
          text: "AMIGO Log",
          link: `${this.$store.state.GTA_LINK}log/`,
        },
        {
          field: "power_rawdata",
          text: "Power Rawdata",
          link: `${this.$store.state.GTA_LINK}log/power/`,
        },
        {
          field: "showfreq_log",
          text: "SOC Dumper Log",
          link: `${this.$store.state.GTA_LINK}log/showfreq/`,
        },
      ],
      scoreBodyColumns: [
        {
          field: "median_fps",
          text: "Median FPS",
        },
        {
          field: "average_fps",
          text: "Average FPS",
        },
        {
          field: "stability",
          text: "Stability",
        },
        {
          field: "stdev",
          text: "STDEV",
        },
        {
          field: "final_temp",
          text: "Average TMU (℃)",
        },
        {
          field: "totalScore",
          text: "FPS or Scores",
        },
        {
          field: "powerPerFps",
          text: "Power/FPS",
        },
        {
          field: "fpsPerPower",
          text: "FPS/Power(W)",
        },
        // {
        //   field: "GPUTotalScore",
        //   text: "GPU Total Score",
        // },
      ],
      efficiencyBodyColumns: [
        { field: "g3d0_voltage", text: "G3D0 Voltage (V)" },
        { field: "g3d1_voltage", text: "G3D1 Voltage (V)" },
        { field: "temperature", text: "G3D remote max Temp" },
        { field: "g3d0_leakage", text: "G3D0 Plkg (mW)" },
        { field: "g3d1_leakage", text: "G3D1 Plkg (mW)" },
        { field: "dyn_e_per_fr_075v", text: "G3D Dyn E/fr @ 0.75V" },
        { field: "dram_total_bw", text: "DRAM traffic (MB/fr)" },
        { field: "cpu_total_bw", text: "CPU traffic (MB/fr)" },
        { field: "gpu_total_bw", text: "GPU traffic (MB/fr)" },
      ],
      scoreData: {
        count: 0,
        items: [],
      },
      newTitle: null,
      etc: null,
      selectedTestItems: [],
    };
  },
  async created() {
    this.testId = this.$route.params.id;
    this.fetchData();
  },
  methods: {
    async fetchData() {
      await this.$http.get(`/api/tests/${this.testId}`).then(res => {
        this.test = res.data;
        this.newTitle = this.test.title;
        this.etc = this.test.etc;
      });

      await this.$http.get(`/api/tests/${this.testId}/testitems`).then(res => {
        this.scoreData = res.data;

        const dynamicColumns = new Set();

        this.scoreData.items.forEach(item => {
          item.score = item.score == 1;
          item.power = item.power == 1;

          if (item.amigo_log) {
            item.amigo_log = `${this.$store.state.GTA_LINK}log/${item.id}`;
          }
          if (item.power_rawdata) {
            item.power_rawdata = `${this.$store.state.GTA_LINK}log/power/${item.id}`;
          }
          if (item.showfreq_log) {
            item.showfreq_log = `${this.$store.state.GTA_LINK}log/showfreq/${item.id}`;
          }

          if (item.scores.length > 1) {
            item.scores.forEach(score => {
              const scoreName = score.name?.toString() ?? "";
              const scoreValue = score.fpsOrScores ?? score.average_fps;
              if (
                scoreName &&
                scoreValue !== null &&
                scoreValue !== undefined
              ) {
                dynamicColumns.add(scoreName);
              }
            });
          }
        });

        // 기본 컬럼 + 동적 컬럼 설정
        this.scoreBodyColumns = [
          ...this.scoreBodyColumns,
          ...Array.from(dynamicColumns).map(name => ({
            field: name,
            text: name,
          })),
        ];
      });
      await this.$http.get(`/api/testitems/avg?id=${this.testId}`).then(res => {
        const avg_scoreData = res.data;
        const avgItem = avg_scoreData.items[0];
        avgItem.__isAvg = true;
        this.scoreData.items.push(avgItem);
      });
    },
    async fetchAvgItem() {
      const res = await this.$http.get(`/api/testitems/avg?id=${this.testId}`);
      const avgItem = res.data.items[0];
      avgItem.__isAvg = true;

      this.scoreData.items = this.scoreData.items.filter(item => !item.__isAvg);

      this.scoreData.items.push(avgItem);
    },
    clickDeleteBtn() {
      if (confirm("Do you want to delete this score?") == false) {
        return;
      }

      this.$http
        .delete(`/api/tests/${this.testId}`)
        .then(() => {
          this.$router.push({
            name: `${this.test.type}List`,
          });
        })
        .catch(err => {
          alert(err.message);
        });
    },
    copyToClipboard() {
      let checkbox_list = document.getElementsByClassName("custom-checkbox");

      for (const checkbox of checkbox_list) {
        checkbox.style.display = "none";
      }

      let containerNode = document.getElementById("score-table");

      var range = document.createRange();
      range.selectNode(containerNode);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);
      document.execCommand("copy");
      window.getSelection().removeAllRanges();

      for (const checkbox of checkbox_list) {
        checkbox.style.display = "";
      }
    },
    checkScoreOrPower(index) {
      var item = this.scoreData.items[index];

      this.$http.put(`/api/testitems/${item.id}`, item).then(() => {
        this.fetchAvgItem();
      });
    },
    clickDeleteTestitemBtn() {
      if (this.selectedTestItems.length === 0) {
        alert("Please select tests.");
        return;
      }

      if (confirm("Do you want to delete these tests?") == false) {
        return;
      }

      const deletePromises = this.selectedTestItems.map(aId => {
        return this.$http.delete(`/api/testitems/${aId}`);
      });
      Promise.all(deletePromises)
        .then(() => {
          alert("삭제가 완료되었습니다.");
          window.location.reload();
        })
        .catch(err => {
          alert(`삭제 중 오류 발생: ${err}`);
          console.error(err);
        });
    },

    editTitle() {
      if (this.newTitle == "") {
        alert("Title is empty!!");
      } else {
        var body = {
          title: this.newTitle,
        };

        this.$http
          .put(`/api/tests/${this.test.id}/title`, body)
          .then(() => {
            this.$root.$emit("bv::hide::popover");
            this.test.title = this.newTitle;
          })
          .catch(err => {
            alert(err);
          });
      }
    },
    closeTitleEditPopup() {
      this.$root.$emit("bv::hide::popover");
    },
    showEtcModal() {
      this.$refs.editEtcModal.etc = this.etc;
      this.$bvModal.show("editEtcModal");
    },
    editEtc(e, etc) {
      var body = {
        etc: etc,
      };

      this.$http
        .put(`/api/tests/${this.test.id}/etc`, body)
        .then(() => {
          this.$root.$emit("bv::hide::popover");
          this.etc = etc;
          this.test.etc = etc;
        })
        .catch(err => {
          alert(err);
        });
    },
    showChipModal(chipId) {
      this.$refs.chipInfoModal.init(chipId);
      this.$bvModal.show("chipInfoModal");
    },
    getPowerValue(powers, railName) {
      const rail = powers.find(p => p.rail_name === railName);
      return rail?.value ?? null;
    },
    async clickSyncPPAData() {
      let targetTestItems = [];

      if (this.selectedTestItems.length === 0) {
        if (!confirm("No tests are selected. Do you want to select all?")) {
          return;
        }
        targetTestItems = this.items
          .filter(item => !item.__isAvg)
          .map(item => item.id);
      } else {
        targetTestItems = this.selectedTestItems;
      }

      const syncPromises = targetTestItems.map(testItemId => {
        return this.$http.post(`/api/ppa/sync/${testItemId}`);
      });

      Promise.all(syncPromises)
        .then(() => {
          alert("✅ Synced successfully.");
          window.location.reload();
        })
        .catch(err => {
          if (err.response) {
            const serverMsg = err.response.data?.message || "Unknown error";
            const details = err.response.data?.missing || null;
            alert(
              `❌ Sync failed: ${serverMsg}\nMissing: ${
                details ? details.join(", ") : "N/A"
              }`,
            );
            console.error(err.response.data);
          } else {
            alert(`❌ Sync error: ${err.message}`);
            console.error(err);
          }
        });
    },
    showTestModal() {
      if (this.selectedTestItems.length === 0) {
        alert("Please select tests.");
        return;
      }
      this.$refs.editTestIdModal.open(this.testId);
    },
    async handleMove(e, newTestId) {
      const itemList = this.selectedTestItems
        .map(id => `- TestItem ID: ${id}`)
        .join("\n");
      const message = `📋 You are about to move the following test items to\n Test ID: ${newTestId}\n${itemList}\n\nDo you want to proceed?`;

      if (confirm(message) == false) {
        return;
      }

      const Promises = this.selectedTestItems.map(testitemId => {
        return this.$http.put(`/api/testitems/changetest/${testitemId}`, {
          test_id: newTestId,
        });
      });
      try {
        await Promise.all(Promises);
        alert("✅ Moved successfully");
      } catch (err) {
        console.error(err);
        alert("❌ Move failed");
      }
      this.fetchData();
    },
  },
};
</script>

<style>
.group {
  display: flex;
  justify-content: space-between;
}

.table {
  table-layout: fixed;
  font-size: 12px;
  word-break: break-all;
  white-space: pre-wrap;
  vertical-align: middle;
}

.test-table th,
.score-head {
  text-align: center;
  background-color: rgb(242, 242, 242);
}

th.ppa-columns {
  background-color: #e6f7f5;
}

.test-table tr th,
.test-table tr td,
.test-table thead tr th {
  vertical-align: middle;
}

.test-table > :not(:last-child) > :not(:last-child) > * {
  border-bottom-color: #dee2e6;
  border-bottom-width: 0.5px;
}

.text-link {
  cursor: pointer;
}

.power-td {
  text-align: right;
}

.total-power-td {
  text-align: right;
  background-color: rgb(242, 242, 242);
}

.total-power-title-td {
  background-color: rgb(235, 235, 235);
}
</style>
