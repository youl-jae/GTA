<template>
  <div>
    <div class="sub-title-group">
      <div>
        <span class="sub-title" style="margin-right: 1rem"
          >Benchmark Releases</span
        >
        <span style="font-size: small"
          >Contact: 김상원(sangwon4.kim) / 이민지(minji99.lee)</span
        >
      </div>
      <div class="row">
        <b-form-select
          size="sm"
          v-model="selectedBenchmark"
          :options="benchmarks"
          @change="changeBenchmark"
          style="margin-right: 0.3rem"></b-form-select>
        <b-input-group size="sm">
          <b-form-input
            v-model="searchText"
            @keyup.enter="search"
            placeholder="Search title"></b-form-input>
          <template #append>
            <b-button
              class="btn-search"
              variant="outline-secondary"
              @click="search"
              ><font-awesome-icon icon="search"
            /></b-button>
          </template>
        </b-input-group>
        <div class="sub-title-btn-group row">
          <b-button
            variant="outline-secondary"
            size="sm"
            v-b-tooltip.hover.bottom
            title="Write"
            @click="showAddPostModal"
            ><font-awesome-icon icon="pencil-alt"
          /></b-button>
          <b-button
            variant="outline-secondary"
            size="sm"
            v-b-tooltip.hover.bottom
            title="Collapse"
            @click="collapseExpand"
            ><b-icon :icon="collapse ? 'chevron-up' : 'chevron-down'"></b-icon
          ></b-button>
        </div>
      </div>
    </div>
    <div>
      <post
        v-for="post in posts"
        :key="post.id"
        :post="post"
        @delete-post="deletePost"
        @edit-post="showEditPostModal" />
      <p v-show="posts.length == 0" class="no-post">There is no post.</p>
    </div>
    <post-modal
      ref="post-modal"
      :benchmark="selectedBenchmark"
      @add-post="addPost"
      @edit-post="editPost"></post-modal>
  </div>
</template>

<script>
import Post from "../components/Post.vue";
import PostModal from "@/components/modal/PostModal.vue";

export default {
  components: {
    Post,
    PostModal,
  },
  computed: {
    collapseTooltip() {
      return this.collapse ? "Collapse All" : "Expand All";
    },
  },
  data() {
    return {
      benchmarks: [
        {
          value: "GFXBench",
          text: "GFXBench",
        },
        {
          value: "3DMark",
          text: "3DMark",
        },
        {
          value: "Antutu",
          text: "Antutu",
        },
        {
          value: "Basemark",
          text: "Basemark",
        },
      ],
      selectedBenchmark: "GFXBench",
      posts: [],
      searchText: "",
      collapse: false,
      SOURCE_CODE_PATH: "\\\\12.36.155.170\\public\\Temp\\Benchmarks",
    };
  },
  created() {
    const benchmark = this.$route.query.benchmark;

    if (benchmark) {
      const filteredProject = this.benchmarks.filter(
        x => x.text.toLowerCase() == benchmark.toLowerCase(),
      );

      if (filteredProject.length > 0) {
        this.selectedBenchmark = filteredProject[0].value;
      }
    }

    this.getPosts();
  },
  methods: {
    getPosts() {
      var api = `/api/bmrelease?benchmark=${this.selectedBenchmark}`;

      if (this.searchText) {
        api += `&search=${this.searchText}`;
      }

      this.$http
        .get(api)
        .then(res => {
          for (const post of res.data) {
            post.collapse = false;
          }

          if (res.data.length > 0) {
            res.data[0].collapse = true;
          }

          this.posts = res.data;
        })
        .catch(err => {
          console.log(err);
        });
    },
    changeBenchmark() {
      this.$router.push({
        name: "BenchmarkRelease",
        query: {
          benchmark: this.selectedBenchmark,
        },
      });
    },
    search(event) {
      if (event.which !== 13) {
        return;
      }

      this.getPosts();
    },
    showAddPostModal() {
      this.$refs["post-modal"].reset();
      this.$bvModal.show("post-modal");
    },
    addPost(body) {
      if (body.title.length < 1) {
        alert("Title is empty !!");
        return;
      }
      this.$http
        .post("/api/bmrelease", body)
        .then(res => {
          body.id = res.data;
          body.collapse = true;

          if (this.selectedBenchmark != body.benchmark) {
            this.selectedBenchmark = body.benchmark;
            this.changeBenchmark();
          } else {
            this.posts.forEach(post => {
              this.$set(post, "collapse", false);
            });

            this.posts.unshift(body);
          }

          this.$bvModal.hide("post-modal");
        })
        .catch(err => {
          console.log(err);
          alert(err);
        });
    },
    showEditPostModal(postId) {
      this.$refs["post-modal"].setData(postId);
      this.$bvModal.show("post-modal");
    },
    editPost(body) {
      if (body.title.length < 1) {
        alert("Title is empty !!");
        return;
      }

      this.$http
        .put(`/api/bmrelease/${body.id}`, body)
        .then(() => {
          if (this.selectedBenchmark != body.benchmark) {
            this.selectedBenchmark = body.benchmark;
            this.changeBenchmark();
          } else {
            const index = this.posts.findIndex(x => x.id == body.id);

            if (index != -1) {
              this.$set(this.posts[index], "title", body.title);
              this.$set(this.posts[index], "content", body.content);
              this.$set(this.posts[index], "updated_at", body.updated_at);
            }
          }

          this.$bvModal.hide("post-modal");
        })
        .catch(err => {
          console.log(err);
          alert(err);
        });
    },
    deletePost(post) {
      var password = prompt("Password: ");

      if (password != "tka123tjd!") {
        alert("Incorrect password.");
        return;
      }

      const idx = this.posts.indexOf(post);

      if (idx > -1) {
        const id = this.posts[idx].id;

        this.$http
          .delete(`/api/bmrelease/${id}`)
          .then(() => {
            this.posts.splice(idx, 1);
          })
          .catch(err => {
            alert(err);
          });
      }
    },
    collapseExpand() {
      this.collapse = !this.collapse;

      for (const post of this.posts) {
        post.collapse = this.collapse;
      }
    },
  },
};
</script>

<style scoped>
.row {
  flex-wrap: inherit;
  margin-right: 0px;
  margin-left: 0px;
}

.btn-outline-secondary {
  border-color: #ced4da;
}

.row > .custom-select {
  width: auto;
  margin-right: 0.3rem;
}

.input-group > .form-control:not(:last-child) {
  width: 250px;
}

.no-post {
  margin-top: 5rem;
  margin-bottom: 5rem;
  font-style: italic;
  text-align: center;
}
</style>
