<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">Comparison / Game</span>
    </div>
    <game-group-table ref="table" :rows="rows"></game-group-table>
  </div>
</template>

<script>
import GameGroupTable from "@/components/GameGroupTable.vue";

export default {
  name: "GameComparisonList",
  components: {
    GameGroupTable,
  },
  data() {
    return {
      rows: [],
    };
  },
  created() {
    this.$http.get(`/api/comparisons?type=game`).then(res => {
      for (const comparison of res.data) {
        this.rows.push({
          mode: "span",
          label: comparison.title,
          id: comparison.id,
          html: false,
          children: comparison.tests,
        });
      }
    });
  },
  methods: {},
};
</script>
