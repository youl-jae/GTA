<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">GTA Weekly</span>
      <div class="row">
        <b-input-group size="sm">
          <b-form-input
            v-model="searchValue"
            @keyup.enter="search"
            placeholder="Search title"></b-form-input>
          <template #append>
            <b-button
              class="btn-search"
              variant="outline-secondary"
              @click="search"
              ><font-awesome-icon icon="search"
            /></b-button>
          </template>
        </b-input-group>
        <div class="sub-title-btn-group">
          <b-button
            variant="outline-secondary"
            size="sm"
            v-b-tooltip.hover.bottom
            title="comparison"
            @click="compareData">
            <font-awesome-icon icon="exchange-alt" />
          </b-button>
        </div>
      </div>
    </div>
    <ve-table
      :columns="columns"
      :table-data="tableData"
      :border-x="true"
      :border-y="true"
      :sort-option="sortOption"
      :event-custom-option="eventCustomOption"
      row-key-field-name="rowKey"
      :checkbox-option="checkboxOption" />
    <!-- <top-game-result-modal ref="topgameModal"></top-game-result-modal> -->
  </div>
</template>

<script>
// import topGameResultModal from "@/components/modal/topGameResultModal.vue";
export default {
  name: "TopGameWeekly",
  components: {
    // topGameResultModal,
  },
  data() {
    return {
      selectedId: "",
      searchValue: "",
      checkboxOption: {
        selectedRowChange: ({ selectedRowKeys }) => {
          this.selectedId = selectedRowKeys;
        },
        selectedAllChange: () => {},
      },
      eventCustomOption: {
        bodyCellEvents: ({ row, column }) => {
          return {
            click: event => {
              // checkbox column 제외
              if (column.field === "checkbox") {
                return event;
              }
              this.changePage(row["id"]);
            },
          };
        },
      },
      sortOption: {
        sortAlways: true,
        sortChange: params => {
          this.sortChange(params);
        },
      },
      columns: [
        {
          field: "checkbox",
          key: "j",
          type: "checkbox",
          title: "",
          align: "center",
          width: 40,
        },
        {
          field: "WEEK",
          key: "j1",
          // type: "checkbox",
          title: "Week",
          align: "center",
          width: 80,
        },
        {
          field: "project",
          key: "a",
          title: "Project",
          align: "center",
          width: 100,
          filter: {
            filterList: [],
            isMultiple: true,
            filterConfirm: filterList => {
              const labels = filterList
                .filter(x => x.selected)
                .map(x => x.label);
              this.searchByProjectField(labels);
            },
          },
          filterReset: () => {
            this.searchByProjectField([]);
          },
        },
        {
          field: "testTitle",
          key: "c2",
          title: "Title",
          align: "center",
        },
        {
          field: "app_list",
          key: "c",
          title: "App List",
          align: "center",
          width: 130,
        },
        {
          field: "test_type",
          key: "c1",
          title: "Test Type",
          align: "center",
          width: 130,
        },
        {
          field: "request_date",
          key: "b1",
          title: "Request Date",
          sortBy: "desc",
          align: "center",
          width: 130,
        },
        {
          field: "end_date",
          key: "b2",
          title: "End Date",
          align: "center",
          width: 130,
        },
        {
          field: "Period",
          key: "b3",
          title: "Period",
          align: "center",
          width: 80,
        },
        {
          field: "total",
          key: "d",
          title: "Total",
          align: "center",
          width: 80,
        },
        {
          field: "pass",
          key: "e",
          title: "PASS",
          align: "center",
          width: 80,
        },
        {
          field: "fail",
          key: "f",
          title: "FAIL",
          align: "center",
          children: [
            {
              field: "NA",
              key: "e1",
              title: "N/A",
              align: "center",
              width: 80,
            },
            {
              field: "NotTest",
              key: "e2",
              title: "NOT TEST",
              align: "center",
              width: 80,
            },
            {
              field: "ANR",
              key: "e3",
              title: "ANR",
              align: "center",
              width: 80,
            },
            {
              field: "CRASH",
              key: "e4",
              title: "CRASH",
              align: "center",
              width: 80,
            },
            {
              field: "RenderingError",
              key: "e41",
              title: "RENDERING ERROR",
              align: "center",
              width: 80,
            },
            {
              field: "NOT_INSTALL",
              key: "e5",
              title: "NOT INSTALL",
              align: "center",
              width: 80,
            },
            {
              field: "ETC",
              key: "e6",
              title: "ETC",
              align: "center",
              width: 80,
            },
          ],
        },
      ],
      tableData: [],
      filteredtableData: [],
      tempPrj: [],
    };
  },
  created() {
    this.$http.get("/api/weekly").then(res => {
      this.tableData = res.data;
      this.filteredtableData = this.tableData;

      // make Project filterList
      for (let idx in res.data) {
        this.tempPrj.push(res.data[idx].project);
      }
      var set = new Set(this.tempPrj);
      var duparr = Array.from(set);
      for (let idx in duparr) {
        this.columns[2].filter.filterList.push({
          value: idx,
          label: duparr[idx],
          selected: false,
        });
      }
      this.columns.push();
    });
  },
  methods: {
    changePage(testId) {
      this.$router.push({
        name: "WeeklyTopGame",
        params: { id: testId },
      });
    },
    searchByProjectField(labels) {
      this.tableData = this.filteredtableData.filter(
        x => labels.length === 0 || labels.includes(x.project),
      );
    },
    search() {
      const searchValue = this.searchValue;
      this.tableData = this.filteredtableData.filter(
        x =>
          !searchValue.length ||
          x.testTitle.toLowerCase().includes(searchValue.toLowerCase()),
      );
    },
    sortChange(params) {
      this.tableData.sort((a, b) => {
        if (params.request_date) {
          if (params.request_date === "asc") {
            return Date.parse(a.request_date) - Date.parse(b.request_date);
          } else if (params.request_date === "desc") {
            return Date.parse(b.request_date) - Date.parse(a.request_date);
          } else {
            return 0;
          }
        }
      });
    },
    compareData() {
      // find selected row's rowKey value in tableData
      var row = [];
      for (let id of this.selectedId) {
        for (let idx in this.tableData) {
          if (this.tableData[idx].rowKey === id) {
            row.push(idx);
          }
        }
      }

      if (this.selectedId.length >= 3) {
        alert("Please compare only 2 result");
      } else if (
        this.tableData[row[0]].app_list !== this.tableData[row[1]].app_list
      ) {
        alert("Please compare same app list");
      } else if (this.selectedId.length < 3) {
        this.$router.push({
          name: "WeeklyTopGame",
          params: { id: this.selectedId.join(",") },
        });
      }
    },
  },
};
</script>

<style scoped>
.row {
  flex-wrap: inherit;
  margin-right: 0px;
  margin-left: 0px;
}

.btn-outline-secondary {
  border-color: #ced4da;
}
</style>

<style>
.ve-table-body-td label {
  margin-bottom: 0px;
}

.ve-table-header-th label {
  margin-bottom: 0px;
}

.ve-checkbox {
  vertical-align: initial;
}

.ve-table
  .ve-table-container
  table.ve-table-content
  tbody.ve-table-body
  .ve-table-body-tr
  .ve-table-body-td
  .ve-table-checkbox-wrapper {
  width: 17px;
}

.ve-table
  .ve-table-container
  table.ve-table-content
  thead.ve-table-header
  .ve-table-header-tr
  .ve-table-header-th
  .ve-table-checkbox-wrapper {
  width: 17px;
}
</style>
