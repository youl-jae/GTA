<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">Top300 Game Test</span>
    </div>
    <vue-good-table
      ref="table"
      :columns="columns"
      :rows="rows"
      :sort-options="{
        enabled: false,
      }"
      :search-options="{
        enabled: true,
        placeholder: 'Filter this table',
        skipDiacritics: true,
      }"
      :pagination-options="{
        enabled: true,
        perPage: 15,
      }"
      @on-row-click="onRowClick"
      styleClass="vgt-table condensed">
    </vue-good-table>
  </div>
</template>

<script>
import "vue-good-table/dist/vue-good-table.css";
import { VueGoodTable } from "vue-good-table";

export default {
  name: "AngleGameList",
  components: {
    VueGoodTable,
  },
  data() {
    return {
      columns: [
        {
          label: "Path",
          field: "name",
        },
      ],
      rows: [],
    };
  },
  created() {
    this.$http.get(`/api/top300Test`).then(res => {
      res.data.forEach(data => {
        this.rows.push({
          name: data,
        });
      });
    });
  },
  methods: {
    onRowClick(params) {
      this.$router.push({
        name: "Top300GameTest",
        params: {
          id: params.row.name,
        },
      });
    },
  },
};
</script>
