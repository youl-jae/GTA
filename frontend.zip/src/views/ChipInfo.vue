<template>
  <div>
    <div class="sub-title-group">
      <div>
        <span class="sub-title">Chip Info</span>
        <span style="margin-left: 0.5rem; font-size: 14px"
          >{{ this.isChecked ? '(Only chips with asv group, ids value, voltage info)' : 'All chips'}}</span
        >
      </div>
      <div style="display: flex; align-items:center;">
        <span style="margin-right: 0.5rem;">ASV/IDS/Volatage</span>
        <b-form-checkbox 
          v-model="isChecked" 
          @change="changeState"
          switch style="display: inline-flex; margin-right:1px;"></b-form-checkbox>
        <b-form-select
          size="sm"
          :options="projects"
          v-model="projectId"
          @change="changeProject"
          style="margin-right: 0.5rem; width: auto"></b-form-select>
        <b-input-group size="sm" style="margin-right: 0.5rem">
          <b-form-input
            v-model="searchValue"
            @keyup.enter="search"
            placeholder="Search chip id"></b-form-input>
          <template #append>
            <b-button
              class="btn-search"
              variant="outline-secondary"
              @click="search"
              ><font-awesome-icon icon="search"
            /></b-button>
          </template>
        </b-input-group>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Add chip"
          @click="showAddChip">
          <font-awesome-icon icon="plus" />
        </b-button>
      </div>
    </div>
    <ve-table
      :max-height="705"
      :fixed-header="true"
      :columns="columns"
      :border-x="true"
      :border-y="true"
      :table-data="tableData"
      :sort-option="sortOption" />
    <chip-info-modal ref="chipInfoModal"></chip-info-modal>
    <add-chip ref="addChip" @getData="changeProject"></add-chip>
  </div>
</template>

<script>
import ChipInfoModal from "@/components/modal/ChipInfoModal.vue";
import AddChip from "@/components/modal/AddChipModal.vue";

export default {
  components: {
    ChipInfoModal,
    AddChip,
  },
  data() {
    return {
      projects: [],
      projectId: "",
      searchValue: "",
      isChecked: true,
      searchApplied: false,
      sortOption: {
        sortChange: params => {
          this.sortChange(params);
        },
      },
      columns: [
        {
          field: "id",
          key: "id",
          title: "id",
          align: "center",
          width: "3%",
        },
        {
          field: "name",
          key: "name",
          title: "Name",
          align: "center",
          width: "20%",
        },
        {
          field: "chip_id",
          key: "chip_id",
          title: "Chip ID",
          align: "center",
          width: "10%",
          renderBodyCell: ({ row, column }) => {
            return (
              <span>
                <a
                  class="link-text"
                  style="cursor: pointer;"
                  on-click={() => this.showModal(row.id)}>
                  {row[column.field]}
                </a>
              </span>
            );
          },
        },
        {
          field: "revision_number",
          key: "revision_number",
          title: "Revision Number",
          align: "center",
          width: "5%",
          renderBodyCell: ({ row, column }) => {
            return <span>EVT{row[column.field]}</span>;
          },
        },
        {
          field: "asv_groups",
          key: "asv_groups",
          title: "ASV Group",
          align: "center",
          children: [],
        },
        {
          field: "ids_values",
          key: "ids_values",
          title: "IDS Value",
          align: "center",
          children: [],
        },
      ],
      originalData: [],
      tableData: [],
      filteredtableData: [],
    };
  },
  async created() {
    const projectResult = await this.$http.get("/api/projects");

    this.projects = projectResult.data.map(x => ({
      value: x.id,
      text: x.name,
    }));
    this.projectId = projectResult.data.filter(x => x.default === 1)[0].id;
  
    await this.changeProject();
    this.changeState();
  },
  methods: {
    search() {
      const term = (this.searchValue || '').trim().toLowerCase()

      if (!term) {
        this.searchResult = this.originalData.slice() 
      } else {
        this.searchResult = this.originalData.filter(item =>
          (item.chip_id || '').toString().toLowerCase().includes(term)
        )
      }

      this.searchApplied = true
      this.applyCheckbox();
    },
    changeState() {
      this.applyCheckbox();
    },
    applyCheckbox() {
      const base = this.searchApplied ? this.searchResult : this.originalData;

      if (this.isChecked) {
        this.tableData = base
          .filter(item => Number(item.chip_info_exists) >= 1)
          .slice();
    } else {
        this.tableData = base.slice();
      }
    },
    async showModal(chipId) {
      this.$refs.chipInfoModal.init(chipId);
      this.$bvModal.show("chipInfoModal");
    },
    sortChange(params) {
      this.tableData.sort((a, b) => {
        if (params.ids_G3D) {
          if (params.ids_G3D === "asc") {
            return a.ids_G3D - b.ids_G3D;
          } else if (params.ids_G3D === "desc") {
            return b.ids_G3D - a.ids_G3D;
          } else {
            return 0;
          }
        } else {
          return a.id - b.id;
        }
      });
    },
    async changeProject() {
      const ipResult = await this.$http.get(
        `/api/projects/${this.projectId}/ip`,
      );

      const asvCol = this.columns.filter(x => x.field === "asv_groups")[0];
      const idsCol = this.columns.filter(x => x.field === "ids_values")[0];

      asvCol.children = [];
      idsCol.children = [];

      for (const ip of ipResult.data) {
        if (ip.name.includes("CP")) {
          continue;
        }

        asvCol.children.push({
          field: `asv_${ip.name}`,
          key: `asv_${ip.name}`,
          title: ip.name,
        });

        let ids = {
          field: `ids_${ip.name}`,
          key: `ids_${ip.name}`,
          title: ip.name,
        };

        if (ip.name === "G3D") {
          ids.sortBy = "";
        }

        idsCol.children.push(ids);
      }

      this.columns.push();

      this.searchApplied = false;
      this.searchValue = "";

      this.$http.get(`/api/chip-info/${this.projectId}`).then(res => {
        this.originalData = res.data;
        this.tableData = this.originalData.slice(); 
        this.changeState();
      });
    },
    showAddChip() {
      this.$refs.addChip.reset();
      this.$bvModal.show("add-chip");
    },
  },
};
</script>

<style scoped>
.btn-outline-secondary {
  border-color: #ced4da;
}
</style>
