<template>
  <div>
    <div class="sub-title-group">
      <div style="display: flex">
        <span class="sub-title">Ticket Information</span>
        <b-form-checkbox
          style="margin-left: 0.5rem"
          v-model="isFavorite"
          switch
          @change="favoriteTicket"
          :disabled="!this.$store.getters.isBenchmarkKpiManager">
          KPI Ticket
        </b-form-checkbox>
      </div>
      <div class="sub-title-btn-group">
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Update"
          v-show="this.$store.getters.isBenchmarkKpiManager || this.isMyTicket"
          :disabled="this.isFavorite"
          @click="updateTicket"
          ><font-awesome-icon icon="pencil-alt"
        /></b-button>
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="Copy"
          @click="copyTicket"
          ><font-awesome-icon icon="copy"
        /></b-button>
      </div>
    </div>
    <table class="table table-sm table-bordered test-table">
      <tbody>
        <tr>
          <th style="width: 220px">Title</th>
          <td>{{ ticket.title }}</td>
        </tr>
        <tr>
          <th>Status</th>
          <td>
            <b-dropdown
              size="sm"
              :text="ticket.status"
              :variant="this.$store.getters.statusColor(ticket.status)"
              v-show="statusPermission">
              <b-dropdown-item
                v-for="(status, index) in statusList"
                :key="index + 'status'"
                class="btn-dropdown-item"
                @click="changeStatus(status)"
                >{{ status }}
              </b-dropdown-item>
            </b-dropdown>
            <b-button
              size="sm"
              v-show="!statusPermission"
              :variant="this.$store.getters.statusColor(ticket.status)"
              >{{ ticket.status }}</b-button
            >
          </td>
        </tr>
        <tr>
          <th>Requester</th>
          <td>{{ ticket.requester }}</td>
        </tr>
        <tr>
          <th>Tester</th>
          <td>{{ ticket.tester }}</td>
        </tr>
        <tr>
          <th>Created</th>
          <td>{{ ticket.created_at }}</td>
        </tr>
        <tr>
          <th>Updated</th>
          <td>{{ ticket.updated_at }}</td>
        </tr>
        <tr>
          <th>Outdata</th>
          <td>{{ ticket.outdata }}</td>
        </tr>
        <tr>
          <th>Description</th>
          <td style="white-space: pre-wrap">{{ ticket.description }}</td>
        </tr>
        <tr>
          <th>Comment</th>
          <td style="white-space: pre-wrap">{{ ticket.comment }}</td>
        </tr>
      </tbody>
    </table>

    <test-score-comparison :ticketId="ticketId"></test-score-comparison>

    <b-modal id="reject-comment-modal" title="Comment" @ok="rejectTicket">
      <b-form-group label="Please enter a rejection comment.">
        <b-form-textarea v-model="comment" rows="5" size="sm"></b-form-textarea>
      </b-form-group>
    </b-modal>
  </div>
</template>

<script>
import TestScoreComparison from "./TestScoreComparison.vue";

export default {
  name: "TicketInfo",
  data() {
    return {
      NEXT_STATUS_LIST: {
        "Request": ["Approve", "Reject"],
        "Approve": ["In progress"],
        "Reject": [],
        "In progress": ["Complete", "Approve"],
        "Complete": [],
      },
      knoxApiInstance: null,
      ticketId: "",
      ticket: {},
      status: "",
      comment: "",
      isFavorite: false,
    };
  },
  components: {
    TestScoreComparison,
  },
  computed: {
    statusList() {
      return this.NEXT_STATUS_LIST[this.ticket.status];
    },
    isMyTicket() {
      return (
        this.ticket.requesterKnoxId === this.$store.state.userStore.knoxId ||
        this.ticket.testerKnoxId === this.$store.state.userStore.knoxId
      );
    },
    statusPermission() {
      const isBenchmarkKpiManager = this.$store.getters.isBenchmarkKpiManager;
      const isTester =
        this.ticket.testerKnoxId === this.$store.state.userStore.knoxId;
      if (this.ticket.status === "Request") {
        return isBenchmarkKpiManager;
      } else if (this.ticket.status === "Approve") {
        return isBenchmarkKpiManager || isTester;
      } else if (this.ticket.status === "In progress") {
        return isBenchmarkKpiManager || isTester;
      } else {
        return false;
      }
    },
  },
  created() {
    this.ticketId = Number(this.$route.params.id);

    this.fetchData();
  },
  methods: {
    fetchData() {
      this.$http.get(`/api/tickets/${this.ticketId}`).then(res => {
        this.ticket = res.data;
        this.isFavorite = this.ticket.is_favorite == 1;
        this.ticket.outdata = JSON.parse(this.ticket.outdata).join(", ");
      });
    },

    createKnoxApiInstance() {
      if (this.knoxApiInstance) {
        return;
      }

      const headerObject = {
        baseURL: "https://openapi.samsung.net/",
        headers: {
          "Content-type": "application/json",
          "System-ID": "KCC10REST00624",
          "Authorization": "Bearer e0038e74-49d8-32ad-be5b-1a5defc7174a",
        },
      };

      this.knoxApiInstance = this.$http.create(headerObject);
    },
    async changeStatus(status) {
      if (status === "Reject") {
        this.comment = "";
        this.$bvModal.show("reject-comment-modal");
        return;
      } else if (status === "Close") {
        return;
      }

      var body = {
        status: status,
        userId: this.$store.state.userStore.userId,
      };

      this.$http
        .put(`/api/tickets/${this.ticketId}/status`, body)
        .then(() => {
          this.ticket.status = status;
          this.sendMail();
          this.fetchData();
        })
        .catch(err => {
          alert(err);
        });
    },
    rejectTicket(e) {
      e.preventDefault();

      if (!this.comment) {
        alert("Please enter a comment.");
      } else {
        var body = {
          status: "Reject",
          comment: this.comment,
        };

        this.$http
          .put(`/api/tickets/${this.ticketId}/status`, body)
          .then(() => {
            this.ticket.status = "Reject";
            this.ticket.comment = this.comment;
            this.sendMail();
            this.$bvModal.hide("reject-comment-modal");
          })
          .catch(err => {
            alert(err);
          });
      }
    },
    updateTicket() {
      this.$router.push({
        name: "UpdateTicketById",
        params: { id: this.ticketId },
      });
    },
    copyTicket() {
      this.$router.push({
        name: "CopyTicketById",
        params: { id: this.ticketId },
      });
    },
    favoriteTicket() {
      this.$http.put(`/api/tickets/${this.ticketId}/favorite`).then(() => {
        this.ticket.is_favorite = !this.ticket.is_favorite;
      });
    },
    getMailDataByStatus() {
      let data = {
        recipient: null,
        contents: null,
      };

      if (this.ticket.status === "Approve") {
        data.recipient = this.ticket.testerKnoxId;
      } else {
        data.recipient = this.ticket.requesterKnoxId;
      }

      if (this.ticket.status === "Approve") {
        data.contents = "Admin approved a ticket.";
      } else if (this.ticket.status === "Reject") {
        data.contents = "Admin rejected a ticket.";
      } else if (this.ticket.status === "In progress") {
        data.contents = `Ticket #${this.ticket.id} has been started.`;
      } else if (this.ticket.status === "Complete") {
        data.contents = `Ticket #${this.ticket.id} has been completed.`;
      }

      const link = `${this.$store.state.GTA_LINK}ticket/${this.ticket.id}`;

      data.contents = `<p>${data.contents}</p><p>GTA Link: <a href='${link}'>${link}</a></p>`;

      return data;
    },
    sendMail() {
      const data = this.getMailDataByStatus();

      if (data.recipient === null) {
        return;
      }

      this.createKnoxApiInstance();

      let body = {
        subject: `[${this.ticket.status}] ${this.ticket.title}`,
        contents: data.contents,
        contentType: "HTML",
        docSecuType: "PERSONAL",
        sender: {
          emailAddress: this.$store.state.ADMIN_EMAIL,
        },
        recipients: [
          {
            emailAddress: `${data.recipient}@samsung.com`,
            recipientType: "TO",
          },
        ],
      };

      this.knoxApiInstance
        .post(
          `mail/api/v2.0/mails/send?userId=${this.$store.state.ADMIN_ID}`,
          JSON.stringify(body),
        )
        .then(() => {
          console.log("메일 발신 완료");
        })
        .catch(err => {
          console.log(err.message);
        });
    },
  },
};
</script>

<style scoped>
.btn-dropdown-item {
  font-size: 0.875rem;
}
</style>
