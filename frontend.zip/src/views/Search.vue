<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">Search</span>
    </div>
    <hr />
    <div style="display: flex;">
      <div class="col-xl-6">
        <b-form-group label="Date" label-cols="2" label-size="sm">
          <div class="d-flex align-items-center">
            <b-form-input size="sm" type="date" v-model="startDate"></b-form-input>
            <label class="col search-label">~</label>
            <b-form-input size="sm" type="date" v-model="endDate"></b-form-input>
          </div>
        </b-form-group>
        <b-form-group label="Project" label-cols="2" label-size="sm">
          <b-form-select size="sm" v-model="projectId" :options="projects"></b-form-select>
        </b-form-group>
        <b-form-group label-size="sm" label-cols="2">
          <template #label>
            <div class="d-flex">
              <span class="mr-2">Title</span>
              <b-form-checkbox size="sm" v-model="useRegex" style="align-content: center; margin-right: 0.5rem;">Regex</b-form-checkbox>
              <span v-b-popover.hover.html :title="popoverContent" style="font-size: 1rem;">
                <b-icon icon="question-circle-fill" />
              </span>
            </div>
          </template>
          <b-form-input size="sm" v-model="title"></b-form-input>
        </b-form-group>
        <b-form-group label="Chip" label-cols="2" label-size="sm">
          <b-form-input size="sm" v-model="chip"></b-form-input>
        </b-form-group>
        <b-form-group label="Outdata" label-cols="2" label-size="sm">
          <b-form-checkbox-group size="sm" class="pt-1" v-model="selectedData" :options="dataOptions"></b-form-checkbox-group>
        </b-form-group>
        <b-form-group label="Length (min)" label-cols="2" label-size="sm">
          <div class="d-flex align-items-center">
            <b-form-input size="sm" type="number" min="0" v-model="startLength"></b-form-input>
            <label class="col search-label">~</label>
            <b-form-input size="sm" type="number" min="0" v-model="endLength"></b-form-input>
          </div>
        </b-form-group>
        <b-form-group label="FPS" label-cols="2" label-size="sm">
          <div class="d-flex align-items-center">
            <b-form-input size="sm" type="number" min="0" v-model="startFps"></b-form-input>
            <label class="col search-label">~</label>
            <b-form-input size="sm" type="number" min="0" v-model="endFps"></b-form-input>
          </div>
        </b-form-group>
        <b-form-group label="Power" label-cols="2" label-size="sm">
          <div class="d-flex align-items-center">
            <b-form-input size="sm" type="number" min="0" v-model="startPower"></b-form-input>
            <label class="col search-label">~</label>
            <b-form-input size="sm" type="number" min="0" v-model="endPower"></b-form-input>
          </div>
        </b-form-group>
      </div>
      <div class="col-xl-6" style="padding-bottom: 0.5rem;">
        <b-form-group label="App" label-cols="2" label-size="sm">
          <b-form-radio-group size="sm" class="pt-1 mb-1" v-model="selectedAppOption" :options="appOptions"></b-form-radio-group>
          <treeselect
            :max-height="295"
            :multiple="true"
            :always-open="true"
            :options="appList"
            v-model="selectedApp"></treeselect>
        </b-form-group>
      </div>
    </div>
    <div class="search-div-button">
      <b-button class="col-xl-12" @click="search" :disabled="isSearching"><b-spinner small class="mr-2" v-show="isSearching"></b-spinner>{{ isSearching ? "Searching..." : "Search" }}</b-button>
    </div>
    <div class="sub-title-group">
      <span class="sub-title">Result</span>
      <div class="sub-title-btn-group">
        <b-button
          variant="outline-secondary"
          size="sm"
          v-b-tooltip.hover.bottom
          title="comparison"
          @click="compare">
          <font-awesome-icon icon="exchange-alt" />
        </b-button>
      </div>
    </div>
    <test-table ref="table" :rows="rows"></test-table>
  </div>
</template>

<script>
import TestTable from "@/components/TestTable.vue";
import Treeselect from "@riophae/vue-treeselect";
import "@riophae/vue-treeselect/dist/vue-treeselect.css";

export default {
  name: "GameSearch",
  components: {
    TestTable,
    Treeselect,
  },
  data() {        
    return {
      projects: [],
      projectId: 1,
      selectedAppOption: "All",
      appOptions: [
        { text: "All", value: "All" },
        { text: "Game", value: "Game" },
        { text: "Benchmark", value: "Benchmark" },
      ],
      dataOptions: [
        { text: "Gamebench", value: "gamebench_url" },
        { text: "AMIGO Log", value: "amigo_log" },
        { text: "SOC Dumper Log", value: "showfreq_log" },
        { text: "Power Raw Data", value: "power_rawdata" },
      ],
      apps: [],
      selectedApp: [],
      selectedData: [],
      startDate: null,
      endDate: null,
      startLength: null,
      endLength: null,
      startFps: null,
      endFps: null,
      startPower: null,
      endPower: null,
      title: null,
      chip: null,
      rows: [],
      useRegex: false,
      isSearching: false,
      popoverContent: `
        <div style="min-width: 250px; max-width: 400px; font-size: 12px; line-height: 1.8;">
          <strong>정규식 기본 문법</strong><br>
          - <code>.</code> : 임의의 문자 1개<br>
          - <code>|</code> : OR<br>
          - <code>^</code> : 시작 위치<br>
          - <code>$</code> : 끝 위치<br>
          - <code>[]</code> : 문자 집합 중 1개<br>
          - <code>()</code> : 그룹<br><br>

          <strong>반복 수량자</strong><br>
          - <code>?</code> : 0회 또는 1회<br>
          - <code>*</code> : 0회 이상<br>
          - <code>+</code> : 1회 이상<br>
          - <code>{m,n}</code> : m~n회 반복<br><br>

          <strong>예시</strong><br>
          - <code>^Thetis</code> : Thetis로 시작<br>
          - <code>SMDK$</code> : SMDK로 끝남<br>
          - <code>T93446</code> : T93446 포함<br>
          - <code>AMIGO(Enable| On)</code><br>&nbsp;&nbsp;: AMIGOEnable 또는 AMIGO On 포함<br>
          - <code>GPU[0-9]+_MIF[0-9]+</code><br>&nbsp;&nbsp;: GPU숫자+_MIF숫자+ 포함<br>&nbsp;&nbsp;&nbsp;(예: GPU452_MIF2028)<br>
        </div>
      `,
      isAllEmpty: false,
    };    
  },
  computed: {
    gameApps() {
      return this.apps.filter(x => x.type == "Game");
    },
    benchmarkApps() {
      return this.apps.filter(x => x.type == "Benchmark");
    },
    appList() {
      if (this.selectedAppOption === "All") {
        return this.apps;
      } else if (this.selectedAppOption === "Game") {
        return this.apps.filter(x => x.type === "Game");
      } else if (this.selectedAppOption === "Benchmark") {
        return this.apps.filter(x => x.type === "Benchmark");
      }
    },
  },
  created() {
    this.$http.get("/api/projects").then(res => {
      for (const project of res.data) {
        this.projects.push({
          value: project.id,
          text: project.name,
        });
        if (project.default) {
          this.projectId = project.id;
        }
      }
    });

    this.$http.get("/api/apps").then(res => {
      for (const app of res.data) {
        var item = {
          id: `Parent/${app.type}/${app.id}/${app.name}`,
          label: app.name,
          type: app.type,
        };

        if (app.type == "Benchmark") {
          item.children = [];

          for (const testcase of app.testcase) {
            item.children.push({
              id: `Child/${app.type}/${app.id}/${testcase.id}`,
              label: testcase.name,
              type: app.type,
            });
          }
        }

        this.apps.push(item);
      }
    });
  },
  methods: {
    compare() {
      var typeArr = this.$refs.table.selectedRows.map(x => x.type);
      var typeSet = new Set(typeArr);

      typeArr = [...typeSet];

      if (typeArr.length > 1) {
        alert("Game과 Benchmark 테스트를 같이 비교할 수 없습니다.");
        return;
      }

      const routeData = this.$router.resolve({
        name: "TestScoreComparison",
        query: {
          id: this.$refs.table.selectedRows.map(x => x.id).join(","),
        },
      });

      window.open(routeData.href, "_blank");
    },
    search() {
      this.isSearching = true;

      var searchData = {
        apps: [],
        project: this.projectId,
        title: this.title,
        useRegex: this.useRegex,
        chip: this.chip,
        data: this.selectedData,
        startDate: this.startDate,
        endDate: this.endDate,
        startLength: this.startLength,
        endLength: this.endLength,
        startFps: this.startFps,
        endFps: this.endFps,
        startPower: this.startPower,
        endPower: this.endPower,
      };

      for (const appInfo of this.selectedApp) {
        var appInfoList = appInfo.split("/");
        var appId = appInfoList[2];
        var appName = null;
        var testcaseId = null;

        if (appInfoList[0] === "Parent") {
          appName = appInfoList[3];
        } else {
          testcaseId = appInfoList[3];
        }
        
        searchData.apps.push({ "appId": appId, "appName": appName, "testcaseId": testcaseId });
      }

      this.isAllEmpty = Object.entries(searchData)
        .filter(([key]) => key !== "project")                // except for project
        .filter(([key]) => key !== "useRegex")                // except for IsRegex
        .every(([, value]) => {
          if (Array.isArray(value)) {
            return value.length === 0;                // isEmpty
          }
          return value === null || value === false || value === '';
        });
      
      if(this.isAllEmpty){
        var today = new Date();

        var formatDate = (date) => {
          return date.toISOString().split("T")[0];
        };

        var startDateObj = new Date(today);
        startDateObj.setMonth(startDateObj.getMonth() - 3);
                
        searchData.startDate = this.startDate = formatDate(startDateObj);
        searchData.endDate = this.endDate = formatDate(today);
      }

      this.$http.post("/api/tests/search", searchData).then(res => {
        this.$refs.table.resetTable();
        this.rows = res.data;
        this.isSearching = false;
      });
    },
  },
};
</script>

<style>
.search-div {
  padding-bottom: 1.5rem;
  align-items: center;
}

.search-div-button {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 1rem;
}

.search-label {
  margin-bottom: 0px;
}

.vue-treeselect--open-below .vue-treeselect__menu {
  height: 295px;
}
</style>

<style scoped>
hr {
  margin-top: 0rem;
  margin-bottom: 1.5rem;
}

.vue-treeselect__control {
  height: calc(1.5em + 0.5rem + 2px);
  font-size: 0.875rem;
  line-height: 1.5;
  border-radius: 0.2rem;
}
</style>
