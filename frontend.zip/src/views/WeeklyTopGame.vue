<template>
  <div style="display: flex; justify-content: center; padding-left: 10px">
    <top-game-result-graph
      v-for="(id, idx) in id_list"
      :key="idx"
      :pieChartData="returnPieChartData[id]"
      :issueDatas="issueListData[id][0]"
      :dateTitle="dateTitle[id][0]"
      :gpulibver="gpulibver[id][0]"
      :summary="returnSummary[id]"
      :iscompare="compare"
      :index="idx"></top-game-result-graph>
  </div>
</template>

<script>
import topGameResultGraph from "@/components/topGameResultGraph.vue";

export default {
  name: "WeeklyTopGame",
  components: {
    topGameResultGraph,
  },
  data() {
    return {
      testId: "",
      // done: "",
      res: "",
      pieChartData: [],
      issueListData: [],
      summary: [],
      compare: false,
      result: [],
      test: [],
      date: [],
      title: [],
      piechart: [],
      dateTitle: [],
      gpulibver: [],
      dateTitle_compare: [],
      resultGraph: true,
      id_list: [],
      id: "",
    };
  },
  methods: {
    // isCompare() {
    //   this.compare = true;
    //   return this.compare;
    // },
  },
  computed: {
    returnPieChartData() {
      return this.pieChartData;
    },
    returnSummary() {
      return this.summary;
    },
  },
  async created() {
    this.testId = this.$route.params.id;
    var res = await this.$http.get(`/api/weekly/${this.testId}`);
    if (this.testId.length >= 3) {
      this.compare = true;
      this.id_list = this.testId.split(",");
    } else {
      this.id_list = [this.testId];
    }

    // loop
    for (var testId of this.id_list) {
      this.summary[testId] = [];
      this.pieChartData[testId] = [];
      this.dateTitle[testId] = [];
      this.issueListData[testId] = [];
      this.gpulibver[testId] = [];

      this.issueListData[testId].push(res.data[testId].issueList);

      this.piechart = Object.keys(res.data[testId].piechart[0]);
      for (let result of this.piechart) {
        this.pieChartData[testId].push({
          name: result,
          y: res.data[testId].piechart[0][result],
        });
      }

      this.result = Object.keys(res.data[testId].summary[0]);
      let idx = 0;
      for (let result of this.result) {
        this.summary[testId].push({
          name: result,
          y: res.data[testId].summary[0][result],
          rowKey: idx,
        });
        idx += 1;

        // this.issueListData = res.data[testId].issueList;
      }

      this.dateTitle[testId].push({
        title: res.data[testId].testTitle,
        date: res.data[testId].request_date,
      });

      this.gpulibver[testId].push({
        angle: res.data[testId].angle_version,
        svk: res.data[testId].svk_version,
      });
    }
    // this.$refs.resultVue.tmp.push(this.summary);
  },
  mounted() {},
};
</script>
