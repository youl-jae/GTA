<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title">Excel Data</span>
      <div class="sub-title-btn-group">
        <b-button size="sm" @click="showAddChip">Add Chip</b-button>
        <b-button size="sm" @click="showExample">Example</b-button>
      </div>
    </div>
    <b-form-group size="sm">
      <b-textarea
        size="sm"
        v-model="originalData"
        @keyup="handler"
        placeholder="Excel에서 복사한 데이터를 붙여넣으세요."
        rows="5"></b-textarea>
    </b-form-group>
    <div class="sub-title-group">
      <span class="sub-title">Result Table</span>
      <div
        class="sub-title-btn-group"
        style="display: flex; justify-content: space-between">
        <b-form-radio-group
          size="sm"
          :options="appTypes"
          v-model="appType"
          style="padding-top: 0.1rem"></b-form-radio-group>
        <b-button size="sm" variant="primary" @click="uploadResult"
          >Upload</b-button
        >
      </div>
    </div>
    <table class="table table-sm table-bordered test-table">
      <tbody>
        <tr v-for="(row, index) in tableData" :key="index + 'td'">
          <td v-for="(item, index) in row" :key="index + 'r'">{{ item }}</td>
        </tr>
      </tbody>
    </table>

    <b-modal id="upload-excel-format" title="Example" size="xl">
      <div class="row">
        <div class="col-xl-4">
          <div
            class="sub-title-group"
            style="height: 39px; margin-bottom: 15px">
            <span>Excel Format</span>
            <div class="sub-title-btn-group">
              <b-button size="sm" @click="copyExcelFormat(true)"
                >Copy required</b-button
              >
              <b-button size="sm" @click="copyExcelFormat(false)"
                >Copy all</b-button
              >
            </div>
          </div>
          <table
            id="excel-format"
            class="table table-sm table-bordered excel-table test-table">
            <tr
              v-for="(row, index) in excelFormat"
              :key="index + 'ef'"
              :class="row.required ? '' : 'no-required-row'">
              <td :class="row.required ? 'required-field' : ''">
                {{ row.field }} {{ row.required ? "*" : " " }}
              </td>
              <td>{{ row.data }}</td>
            </tr>
          </table>
        </div>
        <div class="col-xl-8">
          <b-tabs small content-class="mt-3">
            <b-tab
              v-for="(tab, index) in tabs"
              :title="tab.title"
              :key="index + 'tab'">
              <div v-if="tab.title === 'App'">
                <b-form-group label-cols="2" label="Type" label-size="sm">
                  <b-form-select
                    size="sm"
                    :options="tab.filterOptions"
                    v-model="tab.filterModel"
                    @change="changeAppType"></b-form-select>
                </b-form-group>
              </div>
              <div v-else-if="tab.title === 'Testcase'">
                <b-form-group label-cols="2" label="App" label-size="sm">
                  <b-form-select
                    size="sm"
                    :options="tab.filterOptions"
                    v-model="tab.filterModel"
                    @change="changeTestcaseApp"></b-form-select>
                </b-form-group>
              </div>
              <div v-else-if="tab.title === 'Chip'">
                <b-form-group label-cols="2" label="Project" label-size="sm">
                  <b-form-select
                    size="sm"
                    :options="tab.filterOptions"
                    v-model="tab.filterModel"
                    @change="changeChipProject"></b-form-select>
                </b-form-group>
              </div>
              <div v-else-if="tab.title === 'Power Rail'">
                <b-form-group label-cols="2" label="Project" label-size="sm">
                  <b-form-select
                    size="sm"
                    :options="tab.filterOptions"
                    v-model="tab.filterModel"
                    @change="changePowerRailProject"></b-form-select>
                </b-form-group>
              </div>
              <b-table
                small
                outlined
                sticky-header
                head-variant="light"
                :items="tab.items"
                :fields="tab.fields"
                :class="tab.title === 'Others' ? 'excel-table' : ''"
                :bordered="tab.title === 'Others'"></b-table>
            </b-tab>
          </b-tabs>
        </div>
      </div>
    </b-modal>
    <add-chip ref="addChip"></add-chip>
  </div>
</template>

<script>
import AddChip from "@/components/modal/AddChipModal.vue";

export default {
  name: "UploadTest",
  components: {
    AddChip,
  },
  data() {
    return {
      originalData: "",
      tableData: [],
      excelFormat: [
        {
          field: "Test ID",
          data: "{ test id }",
        },
        {
          field: "Project",
          data: "{ name }",
          required: true,
        },
        {
          field: "App",
          data: "{ name }",
          required: true,
        },
        {
          field: "Testcase",
          data: "{ name }",
        },
        {
          field: "Board Type",
          data: "{ type }",
        },
        {
          field: "Chip",
          data: "{ chip id }",
          required: true,
        },
        {
          field: "Title",
          data: "{ title }",
          required: true,
        },
        {
          field: "Date",
          data: "{ yyyy-mm-dd }",
          required: true,
        },
        {
          field: "Tester",
          data: "{ knox id }",
          required: true,
        },
        {
          field: "Length (min)",
          data: "{ minute }",
        },
        {
          field: "Gamebench",
          data: "{ url }",
        },
        {
          field: "AMIGO Log",
          data: "{ path }",
        },
        {
          field: "SOC Dumper Log",
          data: "{ path }",
        },
        {
          field: "{ power rail name }",
          data: "{ value }",
        },
        {
          field: "Average FPS",
          data: "{ last 20m average }",
        },
        {
          field: "Average Stability",
          data: "{ last 20m average }",
        },
        {
          field: "Average TMU",
          data: "{ last 20m average }",
        },
        {
          field: "FPS or Scores",
          data: "{ value }",
        },
      ],
      tabs: [
        {
          title: "Project",
          fields: [
            {
              key: "id",
              label: "ID",
            },
            {
              key: "name",
              label: "Name",
            },
          ],
          items: [],
        },
        {
          title: "App",
          fields: [
            {
              key: "id",
              label: "ID",
            },
            {
              key: "name",
              label: "Name",
            },
          ],
          items: [],
          filterOptions: [
            {
              value: "Game",
              text: "Game",
            },
            {
              value: "Benchmark",
              text: "Benchmark",
            },
          ],
          filterModel: "Game",
          data: [],
        },
        {
          title: "Testcase",
          fields: [
            {
              key: "id",
              label: "ID",
            },
            {
              key: "name",
              label: "Name",
            },
          ],
          items: [],
          filterOptions: [],
          filterModel: "",
          data: [],
        },
        {
          title: "Board Type",
          fields: [
            {
              key: "index",
              label: "Index",
            },
            {
              key: "type",
              label: "Type",
            },
          ],
          items: [
            { index: 1, type: "ERD" },
            { index: 2, type: "SMDK" },
            { index: 3, type: "MX Current" },
            { index: 4, type: "MX A-Type" },
            { index: 5, type: "MX U-Type" },
            { index: 6, type: "MX C-Type" },
          ],
        },
        {
          title: "Chip",
          fields: [
            {
              key: "id",
              label: "ID",
            },
            {
              key: "name",
              label: "Name",
            },
            {
              key: "chip_id",
              label: "Chip ID",
            },
            {
              key: "serial_number",
              label: "Board Serial Number",
            },
          ],
          items: [],
          filterOptions: [],
          filterModel: "",
          data: [],
        },
        {
          title: "Power Rail",
          fields: [
            {
              key: "id",
              label: "ID",
            },
            {
              key: "name",
              label: "Name",
            },
          ],
          items: [],
          filterOptions: [],
          filterModel: "",
          data: [],
        },
        {
          title: "Others",
          fields: [
            {
              key: "field",
              label: "Field",
            },
            {
              key: "data",
              label: "Value",
            },
          ],
          items: [
            {
              field: "Network",
              data: "Wifi / Airplane",
            },
            {
              field: "Environment",
              data: "Room / Chamber({ temperature })",
            },
            {
              field: "Start Temperature",
              data: "{ temperature }",
            },
            {
              field: "BSP Type",
              data: "GED / SEP",
            },
            {
              field: "Binary Path",
              data: "{ 10.229.95.71 server path }",
            },
            {
              field: "Binary Type",
              data: "USERDEBUG / ENG",
            },
            {
              field: "Binary Quickbuild",
              data: "{ image download url }",
            },
            {
              field: "Lib Path",
              data: "{ 10.229.95.71 server path }\n(separate multiple libs with ; symbol)",
            },
          ],
        },
      ],
      appTypes: [
        {
          value: "Game",
          text: "Game",
        },
        {
          value: "Benchmark",
          text: "Benchmark",
        },
      ],
      appType: "Game",
    };
  },
  created() {
    if (this.$route.params.appType) {
      this.appType = this.$route.params.appType;
    }

    this.$http.get(`/api/projects`).then(res => {
      let tab = this.tabs.find(x => x.title === "Project");
      tab.items = res.data;

      let projectOptions = res.data.map(x => ({
        value: x.name,
        text: x.name,
      }));
      let projectModel = res.data.filter(x => x.default === 1)[0].name;

      let chipTab = this.tabs.find(x => x.title === "Chip");
      chipTab.filterOptions = projectOptions;
      chipTab.filterModel = projectModel;

      let powerRailTab = this.tabs.find(x => x.title === "Power Rail");
      powerRailTab.filterOptions = projectOptions;
      powerRailTab.filterModel = projectModel;
    });

    this.$http.get(`/api/apps`).then(res => {
      let tab = this.tabs.find(x => x.title === "App");
      tab.data = res.data;
      this.changeAppType();
    });

    this.$http.get(`/api/apps/testcase`).then(res => {
      let tab = this.tabs.find(x => x.title === "Testcase");
      tab.data = res.data.filter(x => x.testcase);
      tab.filterOptions = tab.data.map(x => ({
        value: x.name,
        text: x.name,
      }));
      tab.filterModel = tab.filterOptions[0].value;
      this.changeTestcaseApp();
    });

    this.$http.get(`/api/chips`).then(res => {
      let tab = this.tabs.find(x => x.title === "Chip");
      tab.data = res.data;
      this.changeChipProject();
    });

    this.$http.get(`/api/power-rails`).then(res => {
      let tab = this.tabs.find(x => x.title === "Power Rail");
      tab.data = res.data;
      this.changePowerRailProject();
    });
  },
  methods: {
    changeAppType() {
      let tab = this.tabs.find(x => x.title === "App");
      tab.items = tab.data.filter(x => x.type === tab.filterModel);
    },
    changeTestcaseApp() {
      let tab = this.tabs.find(x => x.title === "Testcase");
      tab.items = tab.data.filter(x => x.name === tab.filterModel)[0].testcase;
    },
    changeChipProject() {
      let tab = this.tabs.find(x => x.title === "Chip");
      tab.items = tab.data.filter(x => x.project === tab.filterModel);
    },
    changePowerRailProject() {
      let tab = this.tabs.find(x => x.title === "Power Rail");
      tab.items = tab.data.filter(x => x.project === tab.filterModel);
      tab.items.sort((a, b) => {
        return a.order - b.order;
      });
    },
    handler() {
      this.tableData = [];

      if (this.originalData === "") {
        return;
      }

      this.convertToTable();
    },
    convertToTable() {
      for (const row of this.originalData.split("\n")) {
        const convRow = row.split("\t");

        if (row.length === 0) {
          return;
        }

        this.tableData.push(convRow);
      }
    },
    showAddChip() {
      this.$refs.addChip.reset();
      this.$bvModal.show("add-chip");
    },
    showExample() {
      this.$bvModal.show("upload-excel-format");
    },
    copyExcelFormat(required) {
      let noRequiredRows = document.getElementsByClassName("no-required-row");
      let requiredField = document.getElementsByClassName("required-field");

      if (required) {
        for (const row of noRequiredRows) {
          row.style.display = "none";
        }
      }

      for (const field of requiredField) {
        field.innerHTML = field.innerHTML.replace(" *", "");
      }

      let excelFormat = document.getElementById("excel-format");

      var range = document.createRange();
      range.selectNode(excelFormat);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);
      document.execCommand("copy");
      window.getSelection().removeAllRanges();

      if (required) {
        for (const row of noRequiredRows) {
          row.style.display = "";
        }
      }

      for (const field of requiredField) {
        field.innerHTML = `${field.innerHTML} *`;
      }
    },
    uploadResult() {
      if (this.tableData.length < 1) {
        alert("No data entered.");
        return;
      }

      const keys = this.tableData.map(x => x[0]);
      const testCount = this.tableData[0].length - 1;

      const fieldNames = [
        "test id",
        "project",
        "project_id",
        "app",
        "app_id",
        "testcase",
        "app_testcase_id",
        "app_name",
        "board type",
        "chip",
        "chip_id",
        "title",
        "date",
        "tester",
        "length (min)",
        "gamebench",
        "quickperf",
        "amigo log",
        "soc dumper log",
        "power rawdata",
        "average fps",
        "average stability",
        "average tmu",
        "stdev",
        "median fps",
        "fps or scores",
        "network",
        "environment",
        "start temperature",
        "bsp type",
        "binary path",
        "binary type",
        "binary quickbuild",
        "lib path",
      ];
      let results = [];

      for (let i = 1; i < testCount + 1; i++) {
        let test = {};
        for (let j = 0; j < keys.length; j++) {
          let key = keys[j].toLowerCase();

          if (fieldNames.includes(key) === false) {
            key = keys[j];
          }

          if (key === "environment") {
            test[key] = this.parseEnvironment(this.tableData[j][i]);
          } else if (key === "start temperature") {
            test[key] = this.parseStartTemperature(this.tableData[j][i]);
          } else if (key === "lib path") {
            test[key] = this.parseLibPath(this.tableData[j][i]);
          } else {
            test[key] = this.tableData[j][i]?.trim();
          }
        }
        results.push(test);
      }

      if (results.length === 0) {
        alert("No test.");
        return;
      }

      const enteredKey = Object.keys(results[0]);

      if (!enteredKey.includes("project")) {
        alert("Please enter project");
      } else if (!enteredKey.includes("app")) {
        alert("Please enter app");
      } else if (!enteredKey.includes("chip")) {
        alert("Please enter chip");
      } else if (!enteredKey.includes("title")) {
        alert("Please enter title");
      } else if (!enteredKey.includes("date")) {
        alert("Please enter date");
      } else if (!enteredKey.includes("tester")) {
        alert("Please enter tester");
      } else {
        const body = {
          appType: this.appType,
          tests: results,
        };

        this.$http
          .post(`/api/tests`, body)
          .then(res => {
            const idList = [...new Set(res.data)];

            if (idList.length === 1) {
              this.$router.push({
                name: "TestScore",
                params: { id: idList[0] },
              });
            } else {
              this.$router.push({
                name: "TestScoreComparison",
                query: { id: idList.join(",") },
              });
            }
          })
          .catch(err => {
            alert(err.response.data);
          });
      }
    },
    parseEnvironment(value) {
      const environment = value.match(/[\w]*/g).filter(x => x);

      if (environment.length) {
        const location = environment[0] === "Chamber";
        const temperature = Number(environment[1]) || null;

        return [location, temperature];
      } else {
        return null;
      }
    },
    parseStartTemperature(value) {
      const temperature = value.match(/[0-9]*/g).filter(x => x);

      if (temperature.length === 1) {
        return Number(temperature[0]);
      } else {
        return null;
      }
    },
    parseLibPath(value) {
      return value.split(";");
    },
  },
};
</script>

<style scoped>
.test-table {
  text-align: center;
}

.test-table td:nth-child(1) {
  min-width: 200px;
  width: 200px;
  background-color: rgb(242, 242, 242);
  font-weight: bold;
}

.b-table-sticky-header {
  max-height: 468px;
}

.excel-table td:nth-child(1),
.excel-table th:nth-child(1) {
  width: 130px;
  background-color: rgb(242, 242, 242);
  font-weight: bold;
  text-align: left;
  vertical-align: middle;
}

.excel-table td {
  white-space: pre;
}
</style>

<style>
.b-table,
.b-table td {
  vertical-align: middle;
  text-align: center;
}
.b-table .thead-light th {
  background-color: rgb(242, 242, 242);
}
</style>
