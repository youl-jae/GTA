<template>
  <div>
    <div class="sub-title-group">
      <span class="sub-title" style="font-size: x-large"
        >Top300 Game Test - {{ name }}</span
      >
      <div class="sub-title-btn-group">
        <b-button @click="click">Size</b-button>
      </div>
    </div>

    <div
      v-for="(game, index) in games"
      :key="index"
      style="margin-bottom: 10px">
      <span class="sub-title">{{ index + 1 }}. {{ game.name }}</span>

      <div class="row">
        <image-component
          v-for="(image, index) in game.images"
          :key="index"
          :url="image"
          class="col-xl-4"
          style="margin-bottom: 30px"></image-component>
        <!--<img v-for="(image, index) in game.images" :key="index" :src="image" class="col-xl-4" style="margin-bottom: 30px;"></img>-->
      </div>
    </div>
  </div>
</template>

<script>
import ImageComponent from "@/components/ImageComponent.vue";

export default {
  name: "AngleGameTest",
  components: {
    ImageComponent,
  },
  data() {
    return {
      name: null,
      games: [],
    };
  },
  created() {
    this.name = this.$route.params.id;

    this.$http.get(`/api/top300Test/${this.name}`).then(res => {
      for (const key in res.data) {
        this.games.push({
          name: key,
          images: res.data[key].map(
            x => `/api/top300Test/${this.name}/${x.replaceAll(" ", "+")}`,
          ),
        });
      }
    });
  },
  methods: {
    click() {
      const images = document.getElementsByTagName("img");

      for (const image of images) {
        if (image.height > image.width) {
          image.className = "col-xl-2";
        }
      }
    },
  },
};
</script>
