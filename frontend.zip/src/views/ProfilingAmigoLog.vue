<template>
  <div>
    <vue-instant-loading-spinner ref="Spinner" color="#205081" />
    <div class="sub-title-group">
      <span class="sub-title">AMIGO Log</span>
    </div>
    <div style="margin-bottom: 10px">
      <div v-show="!hasId" class="custom-file" style="margin-bottom: 10px">
        <input
          type="file"
          class="custom-file-input"
          ref="inputDirectory"
          id="inputDirectory"
          webkitdirectory
          @change="readDirectory" />
        <label class="custom-file-label" for="inputDirectory"
          >Choose directory (*.log or *.txt)</label
        >
      </div>
      <table
        class="table table-bordered table-sm"
        style="margin-bottom: 0px; text-align: center">
        <thead>
          <tr>
            <th style="width: 10%">No</th>
            <th v-show="hasId">Test</th>
            <th style="width: 10%" v-show="hasVersion">version</th>
            <th style="width: 10%" v-show="hasVersion">Project</th>
            <th>Log File</th>
            <th style="width: 10%">Download</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(file, index) in logData" :key="index">
            <td>{{ index + 1 }}</td>
            <td v-show="hasId">
              <a :href="'/#/game/score/' + file.testId" target="_blank"
                >{{ SCORE_PATH }}{{ file.testId }}</a
              >
            </td>
            <td v-show="hasVersion">
              {{
                file.version
                  ?.slice(0, 3)
                  .filter(v => v !== undefined && v !== null)
                  .join(".") || ""
              }}
            </td>
            <td v-show="hasVersion">{{ file.version?.[3] }}</td>
            <td>{{ file.fileName }}</td>
            <td>
              <b-button
                size="sm"
                variant="outline-dark"
                class="rounded px-3"
                v-b-tooltip.hover.bottom
                title="Download CSV"
                @click="downloadRawData(index)">
                CSV
              </b-button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div
      v-for="(item, index) in chartItems"
      :key="`chart-box-${index}`"
      :class="{ 'info-box': true, 'sticky': index == 'FPS' && fpsFixed }"
      v-show="item.visible"
      :id="`chart-box-${index}`">
      <div
        class="between-group"
        :class="{
          'between-mode': index === 'FPS',
          'left-mode': index === 'Est.Power',
        }">
        <span :id="index" class="between-title">{{ index }}</span>

        <b-form-checkbox
          v-if="index === 'FPS'"
          v-model="fpsFixed"
          class="between-checkbox">
          Fixed
        </b-form-checkbox>

        <b-button
          v-else-if="index === 'Est.Power'"
          @click="handleCalcPowerML"
          class="p-0 border-0 shadow-none power-button">
          <img src="/AI_gen_power.png" alt="icon" style="height: 30px" />
        </b-button>
      </div>

      <div v-for="(series, i) in item.series" :key="`log${i}`">
        <amigo-log-graph
          :ref="`chart-${index}-${i}`"
          :title="`#${i + 1}`"
          :chartType="item.chartType"
          :height="item.height"
          :yAxis="item.yAxis"
          :series="series"
          :pointInterval="logData[i].pointInterval">
        </amigo-log-graph>
      </div>
    </div>
    <div class="info-box" v-show="false">
      <div class="rawdata-title-group">
        <h4 id="rawData">RawData</h4>
        <b-button
          size="sm"
          variant="outline-seconary"
          v-b-tooltip.hover.bottom
          title="Download CSV"
          @click="downloadRawData"
          ><b-icon icon="download"></b-icon
        ></b-button>
      </div>
      <div v-for="(data, index) in logData" :key="`log-${index}`" class="wrap">
        <amigo-log-table
          :ref="`rawdata-${index}`"
          :series="data.series"
          :fileName="data.fileName">
        </amigo-log-table>
      </div>
    </div>
    <footer class="footer">
      <div class="footer-content">
        <a
          v-for="(item, index) in chartItems"
          :key="`footer-${index}`"
          v-show="item.visible"
          class="menu-link"
          @click="scrollFixed(index)">
          {{ index }}
        </a>
        <span class="pointer-cursor" @click="showCustomizeMenu"
          ><font-awesome-icon icon="pencil-alt"
        /></span>
        <!-- <span class="calculator" @click="showCalculator"
          ><font-awesome-icon icon="calculator"
        /></span> -->
      </div>
    </footer>

    <b-modal id="menu-modal" title="Menu" @ok="customizeMenu">
      <div>
        <draggable
          v-model="menuItems"
          @start="drag = true"
          @end="drag = false"
          class="list-group list-group-flush">
          <li
            v-for="(item, index) in menuItems"
            :key="`menu-${index}`"
            class="list-group-item">
            <b-form-checkbox v-model="item.visible">{{
              item.title
            }}</b-form-checkbox>
          </li>
        </draggable>
      </div>

      <template #modal-footer>
        <b-button @click="hideMenu">Cancel</b-button>
        <b-button @click="resetMenu">Reset</b-button>
        <b-button variant="primary" @click="customizeMenu">Ok</b-button>
      </template>
    </b-modal>
  </div>
</template>

<script>
import VueInstantLoadingSpinner from "vue-instant-loading-spinner";
import draggable from "vuedraggable";
import AmigoLogGraph from "../components/AmigoLogGraph.vue";
import AmigoLogTable from "../components/AmigoLogTable.vue";

export default {
  name: "ProfileAmigoLog",
  components: {
    AmigoLogGraph,
    AmigoLogTable,
    draggable,
    VueInstantLoadingSpinner,
  },
  data() {
    const palette = [
      "#A0A0A0", // Gray
      "#FF0000", // Red
      "#D2A7E8", // Light Purple (Lavender)
      "#0070C0", // Medium Blue (Azure)
      "#70AD47", // Green (Olive Green)
      "#ED7C31", // Orange (Burnt Orange)
      "#FFD700", // Gold
      "#FF69B4", // Hot Pink
      "#8B4513", // Saddle Brown
      "#40E0D0", // Turquoise
      "#6A5ACD", // Slate Blue
      "#228B22", // Forest Green
      "#FF8C00", // Dark Orange
      "#C71585", // Medium Violet Red
      "#4682B4", // Steel Blue
      "#9ACD32", // Yellow Green
      "#8B0000", // Dark Red
      "#00CED1", // Dark Turquoise
      "#9932CC", // Dark Orchid
      "#B8860B", // Dark Goldenrod
    ];
    return {
      SCORE_PATH: "http://g2.gta.samsungds.net/#/game/score/",
      idList: [],
      logData: [],
      fpsFixed: false,
      colors: palette,
      chartItems: {
        "FPS": {
          height: 450,
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "FPS",
              },
              min: 0,
              tickInterval: 10,
              height: "40%",
              top: "0%",
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
            {
              title: {
                text: "v-sync",
              },
              min: 0,
              tickInterval: 5,
              height: "20%",
              top: "50%",
              offset: 0,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
            {
              title: {
                text: "Mode",
              },
              min: 0,
              max: 2,
              tickInterval: 1,
              height: "20%",
              top: "80%",
              offset: 0,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "Temp": {
          height: 450,
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "Temp(℃)",
              },
              min: 20,
              tickInterval: 5,
              height: "60%",
              top: "0%",
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
            {
              title: {
                text: "GOS_Temp(℃)",
              },
              min: 15,
              max: 50,
              tickInterval: 5,
              height: "30%",
              top: "70%",
              offset: 0,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "Frequency": {
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "Frequency (MHz)",
              },
              min: 0,
              tickInterval: 500,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "Margin": {
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "Margin (%)",
              },
              tickInterval: 5,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "Active Ratio": {
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "Active Ratio (%)",
              },
              min: 0,
              max: 100,
              tickInterval: 20,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "BW": {
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "BW",
              },
              min: 0,
              tickInterval: 2,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "MIF Latency": {
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "MIF Latency (cycles)",
              },
              min: 0,
              tickInterval: 50,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "Est.Power": {
          visible: true,
          chartType: "area",
          yAxis: [
            {
              title: {
                text: "Est.Power (mW)",
              },
              min: 0,
              tickInterval: 1000,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
              visible: false,
            },
            {
              title: {
                text: "Est.Power (mW)",
              },
              min: 0,
              tickInterval: 1000,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "Est.Power.ML": {
          visible: false,
          chartType: "area",
          yAxis: [
            {
              title: {
                text: "Est.Power.ML (mW)",
              },
              min: 0,
              tickInterval: 1000,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
              visible: false,
            },
            {
              title: {
                text: "Est.Power.ML (mW)",
              },
              min: 0,
              tickInterval: 1000,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "Times": {
          height: 450,
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "PreTime (ms)",
              },
              min: 0,
              max: 40,
              tickInterval: 10,
              height: "30%",
              top: "0%",
              opposite: false,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
            {
              title: {
                text: "CPUTime (ms)",
              },
              min: 0,
              max: 40,
              tickInterval: 10,
              height: "30%",
              top: "35%",
              offset: 0,
              opposite: false,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
            {
              title: {
                text: "GPUTime (ms)",
              },
              min: 0,
              max: 40,
              tickInterval: 10,
              height: "30%",
              top: "70%",
              offset: 0,
              opposite: false,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "LLC": {
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "current (bit)",
              },
              min: 0,
              max: 8,
              tickInterval: 1,
              height: "45%",
              top: "0%",
              opposite: false,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
            {
              title: {
                text: "target (bit)",
              },
              min: 0,
              max: 8,
              tickInterval: 1,
              height: "45%",
              top: "55%",
              offset: 0,
              opposite: false,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
        "MO": {
          visible: true,
          chartType: "line",
          yAxis: [
            {
              title: {
                text: "GPU MO(Amigo Request)",
              },
              min: 0,
              max: 64,
              tickInterval: 8,
              opposite: false,
              showLastLabel: true,
              lineWidth: 1,
              lineColor: "#e6e6e6",
            },
          ],
          series: [],
        },
      },
      menuItems: [
        {
          title: "FPS",
          visible: true,
        },
        {
          title: "Temp",
          visible: true,
        },
        {
          title: "Frequency",
          visible: true,
        },
        {
          title: "Margin",
          visible: true,
        },
        {
          title: "Active Ratio",
          visible: true,
        },
        {
          title: "BW",
          visible: true,
        },
        {
          title: "MIF Latency",
          visible: true,
        },
        {
          title: "Est.Power",
          visible: true,
        },
        {
          title: "Est.Power.ML",
          visible: true,
        },
        {
          title: "Times",
          visible: true,
        },
      ],
      logInfo: {
        maxVer: 2,
        maxModes: 16,
        maxFPSs: 6,
        maxDomains: 8,
        maxRenderTimes: 8,
        maxTraffics: 12,
        maxFrameInfo: 10,
        maxSafeMode: 4,
        maxLLCinfo: 4,
        maxGFXinfo: 16,
        maxAverage: 10,
        maxMo: 1,

        maxClusters: 5,
        domain3Name: ["LIT", "GPU", "MIF"],
        domain4Name: ["LIT", "BIG", "GPU", "MIF"],
        domain5Name: ["LIT", "MID", "BIG", "GPU", "MIF"],
        domain6Name: ["LIT", "MID-LF", "MID-HF", "BIG", "GPU", "MIF"],
        domain6Name_DSU: ["LIT", "MID", "BIG", "GPU", "MIF", "DSU"],
        domain7Name: ["LIT", "MID-LF", "MID-HF", "BIG", "GPU", "MIF", "DSU"],
        domain8Name: [
          "LIT",
          "MID-LF",
          "MID-HF",
          "BIG",
          "SUPER",
          "GPU",
          "MIF",
          "DSU",
        ],

        rtimeAvg: [
          "RenderTimePRE",
          "RenderTimeCPU",
          "RenderTimeV2S",
          "RenderTimeGPU",
          "RenderTimeV2F",
        ],
        rtimeMax: [
          "RenderTimePREpeak",
          "RenderTimeCPUpeak",
          "RenderTimeV2Speak",
          "RenderTimeGPUpeak",
          "RenderTimeV2Fpeak",
        ],
        mif_traffic: [
          "SYS_BW_kbpc",
          "SYS_BW_Gbps",
          "SYS_Lat_cyc",
          "SYS_Lat_ns",
          "CPU_BW_Gbps",
          "CPU_Lat_cyc",
          "CPU_Lat_ns",
          "GPU_BW_Gbps",
          "GPU_Lat_cyc",
          "GPU_Lat_ns",
        ],
        mode: [
          "m_GPERF/HPmode(under v3)",
          "m_nGFLOW/LPmode(under v3)",
          "m_nDYNMO",
          "m_Hyperboost",
          "m_Htaskboost",
          "m_safeMode",
          "m_isGame",
          "m_ELP",
          "m_OOR",
          "M_OOELP",
          "m_HyperG",
        ],
      },
      logInfo2: {
        maxModes: 16,
        maxFPSs: 6,
        maxDomains: 8,
        maxRenderTimes: 8,
        maxTraffics: 12,
        maxFrameInfo: 10,
        maxSafeMode: 4,
        maxLLCinfo: 2,
        maxGFXinfo: 16,
        maxAverage: 10,
        maxMo: 1,
        maxPADID: 1,
        maxCATID: 5,
        maxDP: 3,
        maxRDR: 1,
        maxRQ_MIFMIN: 1,
        maxDISP: 6,
        maxUSER: 5,
        maxSTATE: 4,
        maxARB: 2,
        maxAIO: 3,

        maxClusters: 5,
        domain3Name: ["LIT", "GPU", "MIF"],
        domain4Name: ["LIT", "BIG", "GPU", "MIF"],
        domain5Name: ["LIT", "MID", "BIG", "GPU", "MIF"],
        domain6Name: ["LIT", "MID-LF", "MID-HF", "BIG", "GPU", "MIF"],
        domain6Name_DSU: ["LIT", "MID", "BIG", "GPU", "MIF", "DSU"],
        domain7Name: ["LIT", "MID-LF", "MID-HF", "BIG", "GPU", "MIF", "DSU"],
        domain8Name: [
          "LIT",
          "MID-LF",
          "MID-HF",
          "BIG",
          "SUPER",
          "GPU",
          "MIF",
          "DSU",
        ],

        rtimeAvg: [
          "RenderTimePRE",
          "RenderTimeCPU",
          "RenderTimeV2S",
          "RenderTimeGPU",
          "RenderTimeV2F",
        ],
        rtimeMax: [
          "RenderTimePREpeak",
          "RenderTimeCPUpeak",
          "RenderTimeV2Speak",
          "RenderTimeGPUpeak",
          "RenderTimeV2Fpeak",
        ],
        mif_traffic: [
          "SYS_BW_kbpc",
          "SYS_BW_Gbps",
          "SYS_Lat_cyc",
          "SYS_Lat_ns",
          "CPU_BW_Gbps",
          "CPU_Lat_cyc",
          "CPU_Lat_ns",
          "GPU_BW_Gbps",
          "GPU_Lat_cyc",
          "GPU_Lat_ns",
        ],
        mode: [
          "m_GPERF/HPmode(under v3)",
          "m_nGFLOW/LPmode(under v3)",
          "m_nDYNMO",
          "m_Hyperboost",
          "m_Htaskboost",
          "m_safeMode",
          "m_isGame",
          "m_ELP",
          "m_OOR",
          "M_OOELP",
          "m_HyperG",
        ],
      },
      qFPS: [],
      lastTargetFPS: 0,
      sumFPS: 0,
      qLengthFPS: 10,
      no_domains: 0,
      MIF_BTL_THR: 48,
      LAT_BTL_THR: 210,
      volume: false,
    };
  },
  async mounted() {
    this.$refs.Spinner.show();

    if (this.hasId) {
      try {
        const idList = this.$route.params.id.split(",");

        for (let i = 0; i < idList.length; i++) {
          const id = idList[i];

          const res = await this.$http.get(`/api/testitems/${id}/log`);

          this.logData.splice(i, 1, res.data);

          if (res.data.log) {
            this.convertLog(i);
          }
        }
      } catch (err) {
        console.log(err);
      }
    }

    const menu = JSON.parse(localStorage.getItem("menuItems"));

    if (menu) {
      if (
        menu.length == this.menuItems.length &&
        menu.findIndex(x => x.title == "Temp") != -1
      ) {
        this.menuItems = menu;
        this.sortChartItems();
      } else {
        localStorage.removeItem("menuItems");
      }
    }

    this.$refs.Spinner.hide();
  },
  computed: {
    hasId() {
      return this.$route.params.id;
    },
    hasVersion() {
      return this.logData.some(item => item.version); // 하나라도 version이 있으면 true
    },
  },
  methods: {
    readDirectory() {
      const selectedFiles = this.$refs.inputDirectory.files;

      var count = 0;
      this.logData = [];

      for (const key in this.chartItems) {
        this.chartItems[key].series = [];
      }

      for (const file of selectedFiles) {
        if (
          !(
            file.name.split(".").pop() == "log" ||
            file.name.split(".").pop() == "txt"
          )
        ) {
          continue;
        }

        count++;

        if (count > 2) {
          alert("최대 두개의 로그만 가져올 수 있습니다.");
          return;
        }

        const reader = new FileReader();
        reader.fileName = file.name;
        reader.onload = this.readFile;
        reader.readAsText(file, "UTF-8");
      }
    },
    readFile(event) {
      this.logData.push({
        log: event.target.result,
        fileName: event.target.fileName,
      });

      this.convertLog(this.logData.length - 1);
    },
    convertLog(index) {
      const amigoLog = this.logData[index];
      const logInfo = this.logInfo;

      const lines = amigoLog.log.split("\n");

      if (lines.length < 1) return;

      let version = 0;

      // Get Version
      for (let i = 0; i < lines.length; i++) {
        const aline = lines[i];
        if (aline.includes("FPS(t/c/r)=") || aline.includes("MIGOV")) {
          const tokens = aline.split(/[\s|]+/);
          let tmp;
          for (let i = 0; i < tokens.length; ) {
            if (tokens[i] == "VP=") {
              i++;
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              version = this.parserVP(tmp);
            } else i++;
            if (version) break;
          }
          break;
        }
      }
      var cData = {};
      // Check Version
      if (version) {
        const logInfo = this.logInfo2;
        // New Parser
        cData = {
          noItems: [],
          no_domains: 0,
          xValue: [],
          sLog: [],
          timeinterval: 100,
          volume: false,

          version: [], // 0: Major, 1: Minor
          mode: [],
          fps: [],
          freq: [],
          fmin: [],
          fmax: [],
          active: [],
          margin: [],
          pbmargin: [],
          pbn: [],
          temp: [],
          leakage: [],
          dynamic: [],
          rtimeAvg: [],
          rtimeMax: [],
          traffic: [],
          safemode: [],
          llc: [],
          frameinfo: [],
          average:
            [] /* 0: FPS, 1: Temp, 2:TotalPower, 3:TargetFrameTime, 4:GPU_BW_ratio(%), 5:MIF_UPPER_THR, 6:MIF_LOWER_THR, 7:Latancy_UPPER_THR, 8:Latancy_LOWER_THR,*/,
          gfxinfo: [],
          mo: [],
          padid: [],
          catid: [],
          dp: [],
          rdr: [],
          rq_mifmin: [],
          disp: [],
          user: [],
          state: [],
          arb: [],
          aio: [],
        };
        for (let i = 0; i < logInfo.maxModes; i++) cData.mode.push([]);
        for (let i = 0; i < logInfo.maxFPSs; i++) cData.fps.push([]);
        for (let i = 0; i < logInfo.maxTraffics; i++) cData.traffic.push([]);
        for (let i = 0; i < logInfo.maxFrameInfo; i++) cData.frameinfo.push([]);
        for (let i = 0; i < logInfo.maxDomains; i++) {
          cData.freq.push([]);
          cData.fmin.push([]);
          cData.fmax.push([]);
          cData.active.push([]);
          cData.margin.push([]);
          cData.pbmargin.push([]);
          cData.pbn.push([]);
          cData.leakage.push([]);
          cData.dynamic.push([]);
          cData.temp.push([]);
        }
        for (let i = 0; i < logInfo.maxRenderTimes; i++) {
          cData.rtimeAvg.push([]);
          cData.rtimeMax.push([]);
        }
        for (let i = 0; i < logInfo.maxSafeMode; i++) cData.safemode.push([]);
        for (let i = 0; i < logInfo.maxLLCinfo; i++) cData.llc.push([]);
        for (let i = 0; i < logInfo.maxGFXinfo; i++) cData.gfxinfo.push([]);
        for (let i = 0; i < logInfo.maxAverage; i++) cData.average.push([]);
        for (let i = 0; i < logInfo.maxMo; i++) cData.mo.push([]);
        for (let i = 0; i < logInfo.maxPADID; i++) cData.padid.push([]);
        for (let i = 0; i < logInfo.maxCATID; i++) cData.catid.push([]);
        for (let i = 0; i < logInfo.maxDP; i++) cData.dp.push([]);
        for (let i = 0; i < logInfo.maxRDR; i++) cData.rdr.push([]);
        for (let i = 0; i < logInfo.maxRQ_MIFMIN; i++) cData.rq_mifmin.push([]);
        for (let i = 0; i < logInfo.maxDISP; i++) cData.disp.push([]);
        for (let i = 0; i < logInfo.maxUSER; i++) cData.user.push([]);
        for (let i = 0; i < logInfo.maxSTATE; i++) cData.state.push([]);
        for (let i = 0; i < logInfo.maxARB; i++) cData.arb.push([]);
        for (let i = 0; i < logInfo.maxAIO; i++) cData.aio.push([]);

        for (let i = 0; i < lines.length; i++) {
          const alog = this.parser2(lines[i]);
          if (alog != null) {
            if (alog.noItems == 0) {
              continue;
            }
            cData.version = version;
            for (let i = 0; i < logInfo.maxModes; i++)
              cData.mode[i].push(alog.mode[i]);
            for (let i = 0; i < logInfo.maxFPSs; i++)
              cData.fps[i].push(alog.fps[i]);
            for (let i = 0; i < logInfo.maxTraffics; i++)
              cData.traffic[i].push(alog.traffic[i]);
            for (let i = 0; i < logInfo.maxFrameInfo; i++)
              cData.frameinfo[i].push(alog.frameinfo[i]);
            for (let i = 0; i < logInfo.maxDomains; i++) {
              cData.freq[i].push(alog.freq[i]);
              cData.fmin[i].push(alog.fmin[i]);
              cData.fmax[i].push(alog.fmax[i]);
              cData.active[i].push(alog.active[i]);
              cData.margin[i].push(alog.margin[i]);
              cData.pbmargin[i].push(alog.pbmargin[i]);
              cData.pbn[i].push(alog.pbn[i]);
              cData.leakage[i].push(alog.leakage[i]);
              cData.dynamic[i].push(alog.dynamic[i]);
              cData.temp[i].push(alog.temp[i]);
            }
            for (let i = 0; i < logInfo.maxRenderTimes; i++) {
              cData.rtimeAvg[i].push(alog.rtimeAvg[i]);
              cData.rtimeMax[i].push(alog.rtimeMax[i]);
            }
            for (let i = 0; i < logInfo.maxSafeMode; i++)
              cData.safemode[i].push(alog.safemode[i]);
            for (let i = 0; i < logInfo.maxLLCinfo; i++)
              cData.llc[i].push(alog.llc[i]);
            for (let i = 0; i < logInfo.maxGFXinfo; i++)
              cData.gfxinfo[i].push(alog.gfxinfo[i]);
            for (let i = 0; i < logInfo.maxAverage; i++)
              cData.average[i].push(alog.average[i]);
            for (let i = 0; i < logInfo.maxMo; i++)
              cData.mo[i].push(alog.mo[i]);
            //
            for (let i = 0; i < logInfo.maxPADID; i++)
              cData.padid[i].push(alog.padid[i]);
            for (let i = 0; i < logInfo.maxCATID; i++)
              cData.catid[i].push(alog.catid[i]);
            for (let i = 0; i < logInfo.maxDP; i++)
              cData.dp[i].push(alog.dp[i]);
            for (let i = 0; i < logInfo.maxRDR; i++)
              cData.rdr[i].push(alog.rdr[i]);
            for (let i = 0; i < logInfo.maxRQ_MIFMIN; i++)
              cData.rq_mifmin[i].push(alog.rq_mifmin[i]);
            for (let i = 0; i < logInfo.maxDISP; i++)
              cData.disp[i].push(alog.disp[i]);
            for (let i = 0; i < logInfo.maxUSER; i++)
              cData.user[i].push(alog.user[i]);
            for (let i = 0; i < logInfo.maxSTATE; i++)
              cData.state[i].push(alog.state[i]);
            for (let i = 0; i < logInfo.maxARB; i++)
              cData.arb[i].push(alog.arb[i]);
            for (let i = 0; i < logInfo.maxAIO; i++)
              cData.aio[i].push(alog.aio[i]);

            cData.noItems.push(alog.noItems);
            cData.sLog.push(alog.sLog);
            cData.xValue.push(alog.xValue);
          }
        }
      } else {
        // Old Parser
        cData = {
          noItems: [],
          no_domains: 0,
          xValue: [],
          sLog: [],
          timeinterval: 100,
          volume: false,

          mode: [],
          fps: [],
          freq: [],
          fmin: [],
          fmax: [],
          active: [],
          margin: [],
          pbmargin: [],
          pbn: [],
          temp: [],
          leakage: [],
          dynamic: [],
          rtimeAvg: [],
          rtimeMax: [],
          traffic: [],
          safemode: [],
          llc: [],
          frameinfo: [],
          average:
            [] /* 0: FPS, 1: Temp, 2:TotalPower, 3:TargetFrameTime, 4:GPU_BW_ratio(%), 5:MIF_UPPER_THR, 6:MIF_LOWER_THR, 7:Latancy_UPPER_THR, 8:Latancy_LOWER_THR,*/,
          gfxinfo: [],
          mo: [],
        };
        for (let i = 0; i < logInfo.maxModes; i++) cData.mode.push([]);
        for (let i = 0; i < logInfo.maxFPSs; i++) cData.fps.push([]);
        for (let i = 0; i < logInfo.maxTraffics; i++) cData.traffic.push([]);
        for (let i = 0; i < logInfo.maxFrameInfo; i++) cData.frameinfo.push([]);
        for (let i = 0; i < logInfo.maxDomains; i++) {
          cData.freq.push([]);
          cData.fmin.push([]);
          cData.fmax.push([]);
          cData.active.push([]);
          cData.margin.push([]);
          cData.pbmargin.push([]);
          cData.pbn.push([]);
          cData.leakage.push([]);
          cData.dynamic.push([]);
          cData.temp.push([]);
        }
        for (let i = 0; i < logInfo.maxRenderTimes; i++) {
          cData.rtimeAvg.push([]);
          cData.rtimeMax.push([]);
        }
        for (let i = 0; i < logInfo.maxSafeMode; i++) cData.safemode.push([]);
        for (let i = 0; i < logInfo.maxLLCinfo; i++) cData.llc.push([]);
        for (let i = 0; i < logInfo.maxGFXinfo; i++) cData.gfxinfo.push([]);
        for (let i = 0; i < logInfo.maxAverage; i++) cData.average.push([]);
        cData.mo.push([]);

        for (let i = 0; i < lines.length; i++) {
          const alog = this.parser(lines[i]);
          if (alog != null) {
            if (alog.noItems == 0) {
              continue;
            }
            for (let i = 0; i < logInfo.maxModes; i++)
              cData.mode[i].push(alog.mode[i]);
            for (let i = 0; i < logInfo.maxFPSs; i++)
              cData.fps[i].push(alog.fps[i]);
            for (let i = 0; i < logInfo.maxTraffics; i++)
              cData.traffic[i].push(alog.traffic[i]);
            for (let i = 0; i < logInfo.maxFrameInfo; i++)
              cData.frameinfo[i].push(alog.frameinfo[i]);
            for (let i = 0; i < logInfo.maxDomains; i++) {
              cData.freq[i].push(alog.freq[i]);
              cData.fmin[i].push(alog.fmin[i]);
              cData.fmax[i].push(alog.fmax[i]);
              cData.active[i].push(alog.active[i]);
              cData.margin[i].push(alog.margin[i]);
              cData.pbmargin[i].push(alog.pbmargin[i]);
              cData.pbn[i].push(alog.pbn[i]);
              cData.leakage[i].push(alog.leakage[i]);
              cData.dynamic[i].push(alog.dynamic[i]);
              cData.temp[i].push(alog.temp[i]);
            }
            for (let i = 0; i < logInfo.maxRenderTimes; i++) {
              cData.rtimeAvg[i].push(alog.rtimeAvg[i]);
              cData.rtimeMax[i].push(alog.rtimeMax[i]);
            }
            for (let i = 0; i < logInfo.maxSafeMode; i++)
              cData.safemode[i].push(alog.safemode[i]);
            for (let i = 0; i < logInfo.maxLLCinfo; i++)
              cData.llc[i].push(alog.llc[i]);
            for (let i = 0; i < logInfo.maxGFXinfo; i++)
              cData.gfxinfo[i].push(alog.gfxinfo[i]);
            for (let i = 0; i < logInfo.maxAverage; i++)
              cData.average[i].push(alog.average[i]);
            for (let i = 0; i < logInfo.maxMo; i++)
              cData.mo[i].push(alog.mo[i]);
            cData.noItems.push(alog.noItems);
            cData.sLog.push(alog.sLog);
            cData.xValue.push(alog.xValue);
          }
        }
      }

      cData.no_domains = this.no_domains;
      cData.volume = this.volume;
      this.MIF_BTL_THR = 48;
      this.LAT_BTL_THR = 210;
      this.qFPS.length = 0;
      this.sumFPS = 0;
      this.lastTargetFPS = 0;
      this.no_domains = 0;
      this.volume = false;

      //Timeinterval
      if (cData.xValue.length) {
        this.logData[index].pointInterval = this.getAverageTimeinterval(
          cData.xValue,
        );
      } else {
        this.logData[index].pointInterval = cData.timeinterval;
      }

      if (cData.no_domains) {
        this.addItemFromLog(index, cData);
      }
    },
    parser(aline) {
      const logInfo = this.logInfo;

      let alog = {
        noItems: 0,
        xValue: null,
        sLog: null,

        mode: [],
        fps: [],
        freq: [],
        fmin: [],
        fmax: [],
        active: [],
        margin: [],
        pbmargin: [],
        pbn: [],
        temp: [],
        leakage: [],
        dynamic: [],
        rtimeAvg: [],
        rtimeMax: [],
        traffic: [],
        safemode: [],
        llc: [],
        frameinfo: [],
        average: [],
        gfxinfo: [],
        mo: [],
      };

      alog.mode = new Array(logInfo.maxModes).fill(0);
      alog.fps = new Array(logInfo.maxFPSs).fill(0);
      alog.freq = new Array(logInfo.maxDomains).fill(0);
      alog.fmin = new Array(logInfo.maxDomains).fill(0);
      alog.fmax = new Array(logInfo.maxDomains).fill(0);
      alog.active = new Array(logInfo.maxDomains).fill(0);
      alog.margin = new Array(logInfo.maxDomains).fill(0);
      alog.pbmargin = new Array(logInfo.maxDomains).fill(0);
      alog.pbn = new Array(logInfo.maxDomains).fill(0);
      alog.temp = new Array(logInfo.maxDomains).fill(0);
      alog.leakage = new Array(logInfo.maxDomains).fill(0);
      alog.dynamic = new Array(logInfo.maxDomains).fill(0);
      alog.rtimeAvg = new Array(logInfo.maxRenderTimes).fill(0);
      alog.rtimeMax = new Array(logInfo.maxRenderTimes).fill(0);
      alog.traffic = new Array(logInfo.maxTraffics).fill(0);
      alog.safemode = new Array(logInfo.maxSafeMode).fill(0);
      alog.llc = new Array(logInfo.maxLLCinfo).fill(0);
      alog.frameinfo = new Array(logInfo.maxFrameInfo).fill(0);
      alog.average = new Array(logInfo.maxAverage).fill(0);
      alog.gfxinfo = new Array(logInfo.maxGFXinfo).fill(0);
      alog.mo = new Array(logInfo.maxMo).fill(0);

      if (aline.includes("mif_btl_thr")) {
        const mifbtlThr = aline.match(/mif_btl_thr=(.\d+)/);
        this.MIF_BTL_THR = mifbtlThr ? mifbtlThr[1] / 100 : 48;
      } else if (aline.includes("lat_btl_thr")) {
        const latBtlThr = aline.match(/lat_btl_thr=(.\d+)/);
        this.LAT_BTL_THR = latBtlThr ? latBtlThr[1] : 210;
      } else if (aline.includes("GPERF") || aline.includes("MIGOV")) {
        let nocategory = 0;
        const tokens = aline.split(/[\s|]+/);
        let tmp, tmp2;

        for (let i = 0; i < tokens.length; ) {
          if (tokens[i] == "MODE=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxModes; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.mode[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "FPS(t/c/r)=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxModes; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              tmp /= 10;
              alog.fps[idx] = tmp;
              if (idx == 0) {
                if (this.lastTargetFPS == 0) {
                  alog.average[9] = 0;
                } else {
                  alog.average[9] = 1000 / this.lastTargetFPS;
                }
                this.lastTargetFPS = tmp;
              } else if (idx == 1) {
                this.addFPSq(tmp);
                alog.average[0] = this.getAverageFPS();
                if (alog.fps[0] > 0) alog.average[3] = 1000 / alog.fps[0];
              }

              i++;
            }
          } else if (tokens[i] == "M=") {
            let noDomains = 0;

            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              noDomains++;
              alog.margin[idx] =
                tmp < -1000 ? -100 : tmp > 1000 ? 100 : tmp / 10;
              i++;
            }

            if (this.no_domains < noDomains) this.no_domains = noDomains;

            let mif_idx = 0;
            if (this.no_domains) {
              if (this.no_domains < 7) mif_idx = this.no_domains - 1;
              else mif_idx = this.no_domains - 2;
            }
            const mifMargin_percent = 1 - alog.margin[mif_idx] / 100;
            alog.average[5] = (this.MIF_BTL_THR * mifMargin_percent) / 10;
            alog.average[6] = alog.average[5] / 0.8;
            alog.average[7] = (this.LAT_BTL_THR * mifMargin_percent) / 10;
            alog.average[8] = alog.average[7] / 0.8;
          } else if (tokens[i] == "PBNo=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.pbn[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "F=") {
            let noDomains = 0;

            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              noDomains++;
              alog.freq[idx] = tmp;
              i++;
            }
            if (this.no_domains < noDomains) this.no_domains = noDomains;
          } else if (tokens[i] == "l/h=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              tmp2 = parseInt(tokens[i + 1], 10);
              if (isNaN(tmp2)) break;
              alog.fmin[idx] = tmp;
              alog.fmax[idx] = tmp2;
              i += 2;
            }
          } else if (
            tokens[i] == "A(%)=" ||
            tokens[i] == "A(pct)=" ||
            tokens[i] == "A()="
          ) {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.active[idx] = tmp < 0 ? 0 : tmp > 100 ? 100 : tmp;
              i++;
            }
          } else if (tokens[i] == "AP/SP=") {
            let sumPower = 0;
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              tmp2 = parseInt(tokens[i + 1], 10);
              if (isNaN(tmp2)) break;
              alog.leakage[idx] = tmp;
              alog.dynamic[idx] = tmp2;
              sumPower += tmp + tmp2;
              i += 2;
            }
            alog.average[2] = sumPower;
          } else if (tokens[i] == "FRAME=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxFrameInfo; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              if (idx == 3) {
                alog.frameinfo[idx] = tmp / 10;
              } else {
                alog.frameinfo[idx] = tmp;
              }

              i++;
            }
          } else if (tokens[i] == "T=") {
            let noValid = 0;
            let sumTemp = 0;

            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.temp[idx] = tmp;
              if (tmp > 0) {
                noValid++;
                sumTemp += tmp;
              }
              i++;
            }
            if (noValid > 0) alog.average[1] = sumTemp / noValid;
            if (alog.temp[4] == 0 && alog.temp[5] == 0) this.volume = true;
          } else if (tokens[i] == "Time=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxRenderTimes; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              tmp2 = parseInt(tokens[i + 1], 10);
              if (isNaN(tmp2)) break;
              alog.rtimeAvg[idx] = tmp / 1000;
              alog.rtimeMax[idx] = tmp2 / 1000;
              i += 2;
            }
          } else if (tokens[i] == "BC/BS/LT=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxTraffics; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              if (tmp > 9999999) tmp = 9999999;
              tmp /= 1000;

              alog.traffic[idx] = tmp;
              i++;
            }
            if (alog.traffic[4] > 0)
              alog.average[4] =
                (alog.traffic[7] / (alog.traffic[4] + alog.traffic[7])) * 100;
          } else if (tokens[i] == "SafeMode=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxSafeMode; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.safemode[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "BSO/LLC=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxLLCinfo; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.llc[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "GFX=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxGFXinfo; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.gfxinfo[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "MO=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxMo; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.mo[idx] = tmp;
              i++;
            }
          } else i++;
        }

        alog.sLog = aline;

        if (nocategory >= 3) {
          alog.noItems = nocategory;
          alog.xValue = aline.substring(0, 18);
        } else alog.noItems = 0;

        return alog;
      }
      return null;
    },
    parser2(aline) {
      const logInfo = this.logInfo2;

      let alog = {
        noItems: 0,
        xValue: null,
        sLog: null,

        mode: [],
        fps: [],
        freq: [],
        fmin: [],
        fmax: [],
        active: [],
        margin: [],
        pbmargin: [],
        pbn: [],
        temp: [],
        leakage: [],
        dynamic: [],
        rtimeAvg: [],
        rtimeMax: [],
        traffic: [],
        safemode: [],
        llc: [],
        frameinfo: [],
        average: [],
        gfxinfo: [],
        mo: [],
        padid: [],
        catid: [],
        dp: [],
        rdr: [],
        rq_mifmin: [],
        disp: [],
        user: [],
        state: [],
        arb: [],
        aio: [],
      };

      alog.version = new Array(logInfo.maxVer).fill(0);
      alog.mode = new Array(logInfo.maxModes).fill(0);
      alog.fps = new Array(logInfo.maxFPSs).fill(0);
      alog.freq = new Array(logInfo.maxDomains).fill(0);
      alog.fmin = new Array(logInfo.maxDomains).fill(0);
      alog.fmax = new Array(logInfo.maxDomains).fill(0);
      alog.active = new Array(logInfo.maxDomains).fill(0);
      alog.margin = new Array(logInfo.maxDomains).fill(0);
      alog.pbmargin = new Array(logInfo.maxDomains).fill(0);
      alog.pbn = new Array(logInfo.maxDomains).fill(0);
      alog.temp = new Array(logInfo.maxDomains).fill(0);
      alog.leakage = new Array(logInfo.maxDomains).fill(0);
      alog.dynamic = new Array(logInfo.maxDomains).fill(0);
      alog.rtimeAvg = new Array(logInfo.maxRenderTimes).fill(0);
      alog.rtimeMax = new Array(logInfo.maxRenderTimes).fill(0);
      alog.traffic = new Array(logInfo.maxTraffics).fill(0);
      alog.safemode = new Array(logInfo.maxSafeMode).fill(0);
      alog.llc = new Array(logInfo.maxLLCinfo).fill(0);
      alog.frameinfo = new Array(logInfo.maxFrameInfo).fill(0);
      alog.average = new Array(logInfo.maxAverage).fill(0);
      alog.gfxinfo = new Array(logInfo.maxGFXinfo).fill(0);
      alog.mo = new Array(logInfo.maxMo).fill(0);
      alog.padid = new Array(logInfo.maxPADID).fill(0);
      alog.catid = new Array(logInfo.maxCATID).fill(0);
      alog.dp = new Array(logInfo.maxDP).fill(0);
      alog.rdr = new Array(logInfo.maxRDR).fill(0);
      alog.rq_mifmin = new Array(logInfo.maxRQ_MIFMIN).fill(0);
      alog.disp = new Array(logInfo.maxDISP).fill(0);
      alog.user = new Array(logInfo.maxUSER).fill(0);
      alog.state = new Array(logInfo.maxSTATE).fill(0);
      alog.arb = new Array(logInfo.maxARB).fill(0);
      alog.aio = new Array(logInfo.maxAIO).fill(0);

      if (aline.includes("mif_btl_thr")) {
        const mifbtlThr = aline.match(/mif_btl_thr=(.\d+)/);
        this.MIF_BTL_THR = mifbtlThr ? mifbtlThr[1] / 100 : 48;
      } else if (aline.includes("lat_btl_thr")) {
        const latBtlThr = aline.match(/lat_btl_thr=(.\d+)/);
        this.LAT_BTL_THR = latBtlThr ? latBtlThr[1] : 210;
      } else if (aline.includes("GPERF") || aline.includes("MIGOV")) {
        let nocategory = 0;
        const tokens = aline.split(/[\s|]+/);
        let tmp, tmp2;

        for (let i = 0; i < tokens.length; ) {
          if (tokens[i] == "FPS(t/c/r)=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxModes; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              tmp /= 10;
              alog.fps[idx] = tmp;
              if (idx == 0) {
                if (this.lastTargetFPS == 0) {
                  alog.average[9] = 0;
                } else {
                  alog.average[9] = 1000 / this.lastTargetFPS;
                }
                this.lastTargetFPS = tmp;
              } else if (idx == 1) {
                this.addFPSq(tmp);
                alog.average[0] = this.getAverageFPS();
                if (alog.fps[0] > 0) alog.average[3] = 1000 / alog.fps[0];
              }

              i++;
            }
          } else if (tokens[i] == "MODE=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxModes; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.mode[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "F=") {
            let noDomains = 0;

            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              noDomains++;
              alog.freq[idx] = tmp;
              i++;
            }
            if (this.no_domains < noDomains) this.no_domains = noDomains;
          } else if (tokens[i] == "AP/SP=") {
            let sumPower = 0;
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              tmp2 = parseInt(tokens[i + 1], 10);
              if (isNaN(tmp2)) break;
              alog.leakage[idx] = tmp;
              alog.dynamic[idx] = tmp2;
              sumPower += tmp + tmp2;
              i += 2;
            }
            alog.average[2] = sumPower;
          } else if (tokens[i] == "M=") {
            let noDomains = 0;

            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              noDomains++;
              alog.margin[idx] =
                tmp < -1000 ? -100 : tmp > 1000 ? 100 : tmp / 10;
              i++;
            }

            if (this.no_domains < noDomains) this.no_domains = noDomains;

            let mif_idx = 0;
            if (this.no_domains) {
              if (this.no_domains < 7) mif_idx = this.no_domains - 1;
              else mif_idx = this.no_domains - 2;
            }
            const mifMargin_percent = 1 - alog.margin[mif_idx] / 100;
            alog.average[5] = (this.MIF_BTL_THR * mifMargin_percent) / 10;
            alog.average[6] = alog.average[5] / 0.8;
            alog.average[7] = (this.LAT_BTL_THR * mifMargin_percent) / 10;
            alog.average[8] = alog.average[7] / 0.8;
          } else if (tokens[i] == "PBM=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.pbmargin[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "T=") {
            let noValid = 0;
            let sumTemp = 0;

            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.temp[idx] = tmp;
              if (tmp > 0) {
                noValid++;
                sumTemp += tmp;
              }
              i++;
            }
            if (noValid > 0) alog.average[1] = sumTemp / noValid;
            if (alog.temp[4] == 0 && alog.temp[5] == 0) this.volume = true;
          } else if (tokens[i] == "FRAME=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxFrameInfo; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              if (idx == 3) {
                alog.frameinfo[idx] = tmp / 10;
              } else {
                alog.frameinfo[idx] = tmp;
              }

              i++;
            }
          } else if (tokens[i] == "BC/BS/LT=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxTraffics; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              if (tmp > 9999999) tmp = 9999999;
              tmp /= 1000;

              alog.traffic[idx] = tmp;
              i++;
            }
            if (alog.traffic[4] > 0)
              alog.average[4] =
                (alog.traffic[7] / (alog.traffic[4] + alog.traffic[7])) * 100;
          } else if (tokens[i] == "GFX=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxGFXinfo; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.gfxinfo[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "SAFE=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxSafeMode; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.safemode[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "AR=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.active[idx] = tmp < 0 ? 0 : tmp > 100 ? 100 : tmp;
              i++;
            }
          } else if (tokens[i] == "PBNO=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.pbn[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "L/H=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDomains; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              tmp2 = parseInt(tokens[i + 1], 10);
              if (isNaN(tmp2)) break;
              alog.fmin[idx] = tmp;
              alog.fmax[idx] = tmp2;
              i += 2;
            }
          } else if (tokens[i] == "RTIME=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxRenderTimes; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              tmp2 = parseInt(tokens[i + 1], 10);
              if (isNaN(tmp2)) break;
              alog.rtimeAvg[idx] = tmp / 1000;
              alog.rtimeMax[idx] = tmp2 / 1000;
              i += 2;
            }
          } else if (tokens[i] == "PADID=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxPADID; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.padid[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "CATID=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxCATID; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.catid[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "DP=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDP; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.dp[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "RDR=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxRDR; idx++) {
              tmp = tokens[i];
              if (isNaN(tmp)) break;
              alog.rdr[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "RQ_MIFMIN=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxRQ_MIFMIN; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.rq_mifmin[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "DISP=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxDISP; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.disp[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "MO=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxMo; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.mo[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "LLC=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxLLCinfo; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.llc[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "USER=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxUSER; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.user[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "STATE=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxSTATE; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.state[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "ARB=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxARB; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.arb[idx] = tmp;
              i++;
            }
          } else if (tokens[i] == "AIO=") {
            i++;
            nocategory++;
            for (let idx = 0; idx < logInfo.maxAIO; idx++) {
              tmp = parseInt(tokens[i], 10);
              if (isNaN(tmp)) break;
              alog.aio[idx] = tmp;
              i++;
            }
          } else i++;
        }

        alog.sLog = aline;

        if (nocategory >= 3) {
          alog.noItems = nocategory;
          alog.xValue = aline.substring(0, 18);
        } else alog.noItems = 0;

        return alog;
      }
      return null;
    },
    parserVP(vp) {
      const arch_ver = (vp >> 26) & 0xf;
      const major_ver = (vp >> 22) & 0xf;
      const minor_ver = (vp >> 16) & 0x3f;
      const board = vp & 0x3fff;
      return [arch_ver, major_ver, minor_ver, board];
    },
    addItemFromLog(index, cData) {
      const Clusters = this.getClusterName(cData.no_domains, cData.volume);
      const temp_pass_Clusters = ["LIT", "MIF", "DSU"];
      const power_pass_Clusters = ["DSU"];
      const Colors = this.colors;

      var series = {
        "FPS": [
          {
            name: "target",
            data: [...cData.fps[0]],
            average: true,
          },
          {
            name: "average",
            data: [...cData.average[0]],
          },
          {
            name: "current",
            data: [...cData.fps[1]],
            dashStyle: "ShortDot",
            average: true,
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "v_max",
            data: [...cData.frameinfo[3]],
            dashStyle: "ShortDot",
            yAxis: 1,
          },
          {
            name: "vsync_cnt",
            data: [...cData.frameinfo[4]],
            dashStyle: "ShortDot",
            yAxis: 1,
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
        ],
        "Temp": [
          {
            name: "temp.avg",
            data: [...cData.average[1]],
            average: true,
          },
        ],
        "Frequency": [],
        "Margin": [],
        "Active Ratio": [],
        "BW": [
          {
            name: "BW (GBps)",
            data: [...cData.traffic[1]],
            average: true,
          },
          {
            name: "BW (Bpc)",
            data: [...cData.traffic[0]],
            average: true,
          },
          {
            name: "Upper limit",
            data: [...cData.average[5]],
          },
          {
            name: "Lower limit",
            data: [...cData.average[6]],
          },
        ],
        "MIF Latency": [
          {
            name: "MIF Latency",
            data: [...cData.traffic[2]],
            average: true,
          },
          {
            name: "Upper limit",
            data: [...cData.average[7]],
            color: "#0070C0",
            average: true,
          },
          {
            name: "Lower limit",
            data: [...cData.average[8]],
            color: "#70AD47",
            average: true,
          },
        ],
        "Est.Power": [
          {
            name: "Power.Total",
            data: [...cData.average[2]],
            average: true,
          },
        ],
        "Times": [
          {
            name: "current",
            data: [...cData.rtimeAvg[0]],
            color: "#000000",
          },
          {
            name: "max",
            data: [...cData.rtimeMax[0]],
            color: "#C8C8C8",
          },
          {
            name: "target",
            data: [...cData.average[9]],
            color: "#0070C0",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "current",
            data: [...cData.rtimeAvg[1]],
            yAxis: 1,
            color: "#FF0000",
          },
          {
            name: "max",
            data: [...cData.rtimeMax[1]],
            yAxis: 1,
            color: "#FFB3B3",
          },
          {
            name: "target",
            data: [...cData.average[9]],
            yAxis: 1,
            color: "#0070C0",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "current",
            data: [...cData.rtimeAvg[3]],
            yAxis: 2,
            color: "#70AD47",
          },
          {
            name: "max",
            data: [...cData.rtimeMax[3]],
            yAxis: 2,
            color: "#D2E7C3",
          },
          {
            name: "target",
            data: [...cData.average[9]],
            yAxis: 2,
            color: "#0070C0",
          },
        ],
        "MO": [
          {
            name: "GPU MO(Amigo Request)",
            data: [...cData.mo[0]],
          },
        ],
        "LLC": [
          {
            name: "current (bit)",
            data: [...(cData.version ? cData.llc[0] : cData.llc[1])],
            color: "#FF0000",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "",
            data: [],
            color: "white",
          },
          {
            name: "target (bit)",
            data: [...(cData.version ? cData.llc[1] : cData.llc[2])],
            yAxis: 1,
            color: "#0070C0",
          },
        ],
        "raw": [
          {
            name: "xValue",
            data: [...cData.xValue],
          },
          {
            name: "sLog",
            data: [...cData.sLog],
          },
        ],
      };

      // Add cluster chart
      for (let i = 0; i < Clusters.length; i++) {
        if (!this.chartItems[Clusters[i]]) {
          this.chartItems[Clusters[i]] = {
            visible: true,
            chartType: "line",
            yAxis: [
              {
                title: {
                  text: "(MHz)",
                },
                min: 0,
                tickInterval: 500,
                height: "60%",
                top: "0%",
                opposite: false,
                lineWidth: 1,
                lineColor: "#e6e6e6",
              },
              {
                title: {
                  text: "(%)",
                },
                tickInterval: 50,
                height: "30%",
                top: "70%",
                offset: 0,
                opposite: false,
                lineWidth: 1,
                lineColor: "#e6e6e6",
              },
            ],
            series: [],
          };
        }
        series[Clusters[i]] = [
          {
            name: "frequency",
            data: [...cData.freq[i]],
            average: true,
            color: Colors[0],
          },
          {
            name: "min",
            data: [...cData.fmin[i]],
            dashStyle: "ShortDot",
            average: true,
            color: Colors[1],
          },
          {
            name: "max",
            data: [...cData.fmax[i]],
            dashStyle: "ShortDot",
            average: true,
            color: Colors[2],
          },
          {
            name: "",
            color: "white",
          },
          {
            name: "",
            color: "white",
          },
          {
            name: "",
            color: "white",
          },
          {
            name: "",
            color: "white",
          },
          {
            name: "",
            color: "white",
          },
          {
            name: "",
            color: "white",
          },
          {
            name: "active ratio",
            data: [...cData.active[i]],
            yAxis: 1,
            average: true,
            color: Colors[4],
          },
          {
            name: "margin",
            data: [...cData.margin[i]],
            yAxis: 1,
            average: true,
            color: Colors[5],
          },
        ];
        if (!temp_pass_Clusters.includes(Clusters[i])) {
          series["Temp"].push({
            name: `temp.${Clusters[i]}`,
            data: [...cData.temp[i]],
            average: true,
            color: Colors[i + 1],
          });
        }
        series["Frequency"].push({
          name: `${Clusters[i]}`,
          data: [...cData.freq[i]],
          average: true,
          color: Colors[i],
        });
        series["Margin"].push({
          name: `${Clusters[i]}`,
          data: [...cData.margin[i]],
          average: true,
          color: Colors[i],
        });
        series["Active Ratio"].push({
          name: `${Clusters[i]}`,
          data: [...cData.active[i]],
          average: true,
          color: Colors[i],
        });
        if (!power_pass_Clusters.includes(Clusters[i])) {
          series["Est.Power"].push({
            name: `D.${Clusters[i]}`,
            data: [...cData.dynamic[i]],
            average: true,
            color: Colors[i + 1],
            yAxis: 1,
          });
          series["Est.Power"].push({
            name: `L.${Clusters[i]}`,
            data: [...cData.leakage[i]],
            average: true,
            color: Colors[i + 1],
            yAxis: 1,
          });
        }
      }
      // Add GOS temp
      let limit_temp = 1;
      if (Clusters.length > 6) limit_temp = 2;
      for (let i = Clusters.length - limit_temp; i <= 10; i++) {
        series["Temp"].push({
          name: "",
          color: "white",
        });
      }
      const gos_temp = [
        ["GOS target", "#A0A0A0"],
        ["GOS current", "#FF0000"],
      ];
      for (let i = 0; i < 2; i++) {
        series["Temp"].push({
          name: gos_temp[i][0],
          data: [...cData.safemode[i]],
          yAxis: 1,
          color: gos_temp[i][1],
        });
      }
      // Add mode
      for (let i = 0; i < this.logInfo.mode.length; i++) {
        if (
          cData.mode[i].reduce((sum, num) => sum + num, 0) /
          cData.mode[i].length
        ) {
          series["FPS"].push({
            name: this.logInfo.mode[i],
            data: [...cData.mode[i]],
            yAxis: 2,
            color: Colors[i],
          });
        }
      }
      this.logData[index].series = series;
      this.logData[index].version = cData.version ? cData.version : [];

      for (const key in this.chartItems) {
        if (key !== "Est.Power.ML") {
          const newSeries = JSON.parse(JSON.stringify(series[key]));
          this.chartItems[key].series.push(
            JSON.parse(JSON.stringify(newSeries)),
          );
        }
      }
    },
    getClusterName(num_domain, volume) {
      switch (num_domain) {
        case 4:
          return this.logInfo.domain4Name;
        case 5:
          return this.logInfo.domain5Name;
        case 6:
          if (volume) return this.logInfo.domain6Name_DSU;
          return this.logInfo.domain6Name;
        case 7:
          return this.logInfo.domain7Name;
        default:
          return this.logInfo.domain3Name;
      }
    },
    addFPSq(fps) {
      this.qFPS.push(fps);
      this.sumFPS += fps;
      if (this.qFPS.length >= this.qLengthFPS) {
        this.sumFPS -= this.qFPS.shift();
      }
    },
    getAverageFPS() {
      if (this.qFPS.length > 0) return this.sumFPS / this.qFPS.length;
      return 0;
    },
    getAverageTimeinterval(arr) {
      let diffArr = [];
      for (let i = 1; i < arr.length - 1; i++) {
        diffArr.push(new Date(arr[i + 1]) - new Date(arr[i]));
      }
      return diffArr.reduce((a, b) => a + b, 0) / diffArr.length;
    },
    round(number) {
      return Math.round(number * 10) / 10;
    },
    showCustomizeMenu() {
      var items = [];

      for (const key in this.chartItems) {
        items.push({
          title: key,
          visible: this.chartItems[key].visible,
        });
      }

      this.menuItems = items;

      this.$bvModal.show("menu-modal");
    },
    hideMenu() {
      this.$nextTick(() => {
        this.$bvModal.hide("menu-modal");
      });
    },
    resetMenu() {
      for (let i = 0; i < Object.keys(this.menuItems).length; i++) {
        this.menuItems[i]["visible"] = true;
      }
    },
    customizeMenu() {
      localStorage.setItem("menuItems", JSON.stringify(this.menuItems));

      this.sortChartItems();

      this.$nextTick(() => {
        this.$bvModal.hide("menu-modal");
      });
    },
    sortChartItems() {
      for (const item of this.menuItems) {
        this.chartItems[item.title].visible = item.visible;
      }

      const order = this.menuItems.map(x => x.title);

      var sortedItems = [];
      for (const key in this.chartItems) {
        sortedItems.push([key, this.chartItems[key]]);
      }

      const result = sortedItems.sort(
        (a, b) => order.indexOf(a[0]) - order.indexOf(b[0]),
      );
      var items = {};

      for (const item of result) {
        items[item[0]] = item[1];
      }

      this.chartItems = items;
    },
    scrollFixed(href) {
      const target = document.getElementById(`chart-box-${href}`);

      if (this.fpsFixed) {
        const fpsGraphHeight =
          document.getElementById("chart-box-FPS").offsetHeight;
        const position = target.offsetTop - fpsGraphHeight;

        window.scrollTo({ top: position, behavior: "smooth" });
      } else {
        window.scrollTo({ top: target.offsetTop, behavior: "smooth" });
      }
    },
    downloadRawData(index) {
      this.$refs[`rawdata-${index}`][0].downloadCsv();
    },
    showCalculator() {
      const id = this.$route.params.id.split(",")[0];
      const chart_xaxis_min = Math.floor(
        this.$refs["chart-FPS-0"][0].chart.xAxis[0].min / 100,
      );
      const chart_xaxis_max = Math.floor(
        this.$refs["chart-FPS-0"][0].chart.xAxis[0].max / 100,
      );
      let routeUrl = this.$router.resolve({
        path: "/amigoanalyzer",
        query: {
          id: id,
          min: chart_xaxis_min,
          max: chart_xaxis_max,
        },
      });
      // window.open(routeUrl.href, "_blank", "width=700, height=1000");
      window.open(routeUrl.href, "_blank");
    },
    async handleCalcPowerML() {
      this.$refs.Spinner.show();

      if (this.hasId) {
        try {
          const idList = this.$route.params.id.split(",");

          for (let i = 0; i < idList.length; i++) {
            const id = idList[i];
            const res = await this.$http.get(`/api/powerml/${id}`);
            if (!res.data.success) {
              alert(res.data.message);
            } else {
              const powerData = res.data.data;
              const result = Object.entries(powerData).map(
                ([key, value], index) => ({
                  average: true,
                  data: value,
                  name: key,
                  color: this.colors[index + 1],
                  yAxis: 1,
                }),
              );

              const keys = Object.keys(powerData);
              const length = powerData[keys[0]].length;

              const totalData = Array.from({ length }, (_, i) =>
                keys.reduce((sum, key) => sum + powerData[key][i], 0),
              );
              result.unshift({
                average: true,
                data: totalData,
                name: "Power.Total",
              });
              this.chartItems["Est.Power.ML"].series.push(result);
            }
          }
          this.chartItems["Est.Power.ML"].visible = true;
        } catch (err) {
          console.log(err);
        }
      } else {
        alert("power ML only works with logs uploaded to the server.");
      }
      this.$refs.Spinner.hide();
    },
  },
};
</script>

<style>
.info-box {
  background-color: white;
  padding: 10px;
  border: 1px solid rgb(230, 230, 230);
  margin-bottom: 10px;
}
</style>

<style scoped>
.between-group {
  display: flex;
  align-items: center;
}

.between-mode {
  justify-content: space-between;
}

.left-mode {
  justify-content: flex-start;
}

.between-title {
  margin-bottom: 0;
  font-size: large;
}

.between-checkbox {
  margin-right: 10px;
}

.power-button {
  margin-left: 10px;
}

.item-title {
  font-size: large;
}

.sticky {
  position: -webkit-sticky;
  position: sticky;
  top: 0;
  background-color: white;
  z-index: 1002;
}

.rawdata-title-group {
  display: flex;
  justify-content: flex-start;
}

.rawdata-title-group h4 {
  margin-bottom: 0rem;
  margin-right: 0.5rem;
}

.footer {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  /* height: 7%; */
  /* padding-top: 8px; */
  color: white;
}

.footer-content {
  background-color: rgb(25, 56, 87);
  margin-left: 10px;
  margin-right: 10px;
  /* padding */
  padding: 10px;
  height: 100%;
  /* vertical-align: middle; */
  align-items: center;
  /* display: inline-flex; */
  justify-content: flex-start;
}

.footer-content a {
  color: white;
  margin-right: 30px;
}

.pointer-cursor {
  cursor: pointer;
  margin-right: 30px;
}

.calculator {
  cursor: pointer;
  margin-right: 30px;
}

.list-group-item {
  padding: 0.4rem 1.25rem;
  user-select: none;
}

.wrap {
  width: 100%;
  /* height: 700px; */
  /* max-height: 800px; */
  overflow: auto;
  margin-top: 10px;
  margin-bottom: 20px;
}

.ini-spinner-mask {
  background-color: rgba(255, 255, 255, 0.7);
}

h4 {
  font-weight: normal;
}

table {
  margin-bottom: 0px;
}

.table td {
  vertical-align: middle;
}

thead {
  background-color: rgb(240, 240, 240);
}

a {
  color: black;
}

.menu-link:hover {
  cursor: pointer;
}
</style>
