import Vue from "vue";
import VueRouter from "vue-router";
import TestList from "../views/TestList.vue";
import TestScore from "../views/TestScore.vue";
import TestScoreComparison from "../views/TestScoreComparison.vue";
import GameListComparison from "../views/GameListComparison.vue";
import BenchmarkListComparison from "../views/BenchmarkListComparison.vue";
import ProfilingAmigoLog from "../views/ProfilingAmigoLog.vue";
import ProfilingShowFreqLog from "../views/ProfilingShowFreqLog.vue";
import Top300TestList from "../views/Top300TestList.vue";
import Top300Test from "../views/Top300Test.vue";
import AmigoAnalyzer from "../views/AmigoAnalyzer.vue";
import WeeklyTopGame from "../views/WeeklyTopGame.vue";
import TicketList from "../views/TicketList.vue";
import TicketInfo from "../views/TicketInfo.vue";
import CreateTicket from "../views/CreateTicket.vue";
import store from "../store/index";
import ProfilingPower from "../views/ProfilingPower.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Home",
    component: TicketList,
    //component: () => import(/* webpackChunkName: "home" */ "../views/Home.vue"),
  },
  {
    path: "/search",
    name: "Search",
    component: () =>
      import(/* webpackChunkName: "search" */ "../views/Search.vue"),
  },
  {
    path: "/upload",
    name: "UploadTest",
    component: () =>
      import(/* webpackChunkName: "uploadTest" */ "../views/UploadTest.vue"),
  },
  {
    path: "/download",
    name: "Download",
    component: () =>
      import(/* webpackChunkName: "download" */ "../views/Download.vue"),
  },
  {
    path: "/bmrelease",
    name: "BenchmarkRelease",
    component: () =>
      import(
        /* webpackChunkName: "bmrelease" */ "../views/BenchmarkRelease.vue"
      ),
  },
  {
    path: "/chip-info",
    name: "ChipInfo",
    component: () =>
      import(/* webpackChunkName: "chipInfo" */ "../views/ChipInfo.vue"),
  },
  {
    path: "/issue",
    name: "IssueList",
    component: () =>
      import(/* webpackChunkName: "issuelist" */ "../views/IssueList.vue"),
  },
  {
    path: "/weekly",
    name: "Weekly",
    component: () =>
      import(/* webpackChunkName: "weekly" */ "../views/Weekly.vue"),
  },
  {
    path: "/login",
    name: "Login",
    component: () =>
      import(/* webpackChunkName: "login" */ "../views/Login.vue"),
  },
  {
    path: "/admin",
    name: "AdminPage",
    component: () =>
      import(/* webpackChunkName: "admin" */ "../views/AdminPage.vue"),
  },
  {
    path: "/game",
    name: "GameList",
    component: TestList,
  },
  {
    path: "/game/comparison",
    name: "GameListComparison",
    component: GameListComparison,
  },
  {
    path: "/game/group",
    name: "GameListGroup",
    component: GameListComparison,
  },
  {
    path: "/game/favorite",
    name: "GameListFavorite",
    component: TestList,
  },
  {
    path: "/test/score/comparison",
    name: "TestScoreComparison",
    component: TestScoreComparison,
  },
  {
    path: "/test/score/comparison/:id",
    name: "TestScoreComparisonById",
    component: TestScoreComparison,
  },
  {
    path: "/test/score/:id",
    name: "TestScore",
    component: TestScore,
  },
  {
    path: "/benchmark",
    name: "BenchmarkList",
    component: TestList,
  },
  {
    path: "/benchmark/comparison",
    name: "BenchmarkListComparison",
    component: BenchmarkListComparison,
  },
  {
    path: "/benchmark/group",
    name: "BenchmarkListGroup",
    component: BenchmarkListComparison,
  },
  {
    path: "/benchmark/favorite",
    name: "BenchmarkListFavorite",
    component: TestList,
  },
  {
    path: "/log",
    name: "ProfilingAmigoLog",
    component: ProfilingAmigoLog,
  },
  {
    path: "/log/power",
    name: "ProfilingPower",
    component: ProfilingPower,
  },
  {
    path: "/log/power/:id",
    name: "ProfilingPowerById",
    component: ProfilingPower,
  },
  {
    path: "/log/showfreq",
    name: "ProfilingShowFreqLog",
    component: ProfilingShowFreqLog,
  },
  {
    path: "/log/showfreq/:id",
    name: "ProfilingShowFreqLogById",
    component: ProfilingShowFreqLog,
  },
  {
    path: "/log/:id",
    name: "ProfilingAmigoLogById",
    component: ProfilingAmigoLog,
  },
  {
    path: "/top300game",
    name: "Top300GameList",
    component: Top300TestList,
  },
  {
    path: "/top300game/:id",
    name: "Top300GameTest",
    component: Top300Test,
  },
  {
    path: "/amigoanalyzer",
    name: "AmigoAnalyzer",
    component: AmigoAnalyzer,
  },
  {
    path: "/weekly/result/:id",
    name: "WeeklyTopGame",
    component: WeeklyTopGame,
  },
  {
    path: "/ticket",
    name: "TicketList",
    component: TicketList,
  },
  {
    path: "/ticket/my",
    name: "MyTicketList",
    component: TicketList,
    meta: {
      authRequired: true,
    },
  },
  {
    path: "/ticket/kpi",
    name: "KpiTicketList",
    component: TicketList,
  },
  {
    path: "/ticket/create",
    name: "CreateTicket",
    component: CreateTicket,
    meta: {
      authRequired: true,
    },
  },
  {
    path: "/ticket/:id",
    name: "TicketInfo",
    component: TicketInfo,
  },
  {
    path: "/ticket/:id/copy",
    name: "CopyTicketById",
    component: CreateTicket,
    meta: {
      authRequired: true,
    },
  },
  {
    path: "/ticket/:id/update",
    name: "UpdateTicketById",
    component: CreateTicket,
    meta: {
      authRequired: true,
    },
  },
  {
    path: "/game/score/comparison",
    redirect: { name: "TestScoreComparison" },
  },
  {
    path: "/game/score/comparison/:id",
    redirect: { name: "TestScoreComparisonById" },
  },
  {
    path: "/game/score/:id",
    redirect: { name: "TestScore" },
  },
  {
    path: "/benchmark/score/comparison",
    redirect: { name: "TestScoreComparison" },
  },
  {
    path: "/benchmark/score/comparison/:id",
    redirect: { name: "TestScoreComparisonById" },
  },
  {
    path: "/benchmark/score/:id",
    redirect: { name: "TestScore" },
  },
];

const router = new VueRouter({
  // mode: 'history',
  // eslint-disable-next-line no-undef
  base: process.env.BASE_URL,
  routes,
});

router.beforeEach((to, from, next) => {
  next();

  if (
    to.matched.some(record => record.meta.authRequired) &&
    !store.getters.isLogin
  ) {
    alert("Login please!");
    next("/login");
  }
});

export default router;
