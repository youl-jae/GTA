import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import axios from "axios";
import VueCookies from "vue-cookies";
import { BootstrapVue, IconsPlugin } from "bootstrap-vue";
import HighchartsVue from "highcharts-vue";
import VueSlimScroll from "vue-slimscroll";
import VueEasytable from "vue-easytable";

import "bootstrap/dist/css/bootstrap.css";
import "bootstrap-vue/dist/bootstrap-vue.css";
import "./assets/fontAwesomeIcon.js";
import "vue-easytable/libs/theme-default/index.css"; // import style

Vue.use(VueCookies);
Vue.use(BootstrapVue);
Vue.use(IconsPlugin);
Vue.use(HighchartsVue);
Vue.use(VueSlimScroll);
Vue.use(VueEasytable);

Vue.config.productionTip = false;
Vue.prototype.$http = axios;
Vue.$cookies.config("1d");

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount("#app");
