module.exports = {
  lintOnSave: false,
  runtimeCompiler: true,
  devServer: {
    proxy: {
      "/api": {
        target: "http://localhost:3000",
      },
      "/quickperf": {
        target: "http://12.36.155.123",
        pathRewrite: { "^/quickperf": "" },
      },
    },
  },
  outputDir: "../backend/front",
};
